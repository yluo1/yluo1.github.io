#ifndef HRIR_H
#define HRIR_H

#include "FIR_T.h"

template <class T>
class HRIR : public FIR_T<T>{
public:
	float theta, phi;	//spherical coordinates in radians
	HRIR(){
		theta = 0;
		phi = 0;
	}

	HRIR(int Nin, T *datIn, int FSin, float thetaIn, float phiIn)  : FIR_T(Nin, datIn, FSin) {
		theta = thetaIn;
		phi = phiIn;
	}
	


};

#endif