#ifndef FIR_H
#define FIR_H

class FIR{
public:
	int N;	//size of filter
	int FS;	//samples per second
	
	//M-length linear convolve: out[0:M-1] = in[0:(M-N)] * dat, 
	virtual void convolve(float * in, float * out, int M){
	}


};

#endif
