#ifndef FIR_F_H
#define FIR_F_H

#include "Complex.h"
#include "FFT.h"
#include "FIR.h"
#include "macros.h"


//Finite impulse response, frequency-domain
template <class T>
class FIR_F : public FIR{
public:
	Complex<T> *dat;
	int Np;	//number of elements in dat with padding

	FIR_F(){
		N = 0;
		Np = 0;
		FS = 0;
	}

	FIR_F(int Nin, int Npin, T *datIn, int FSin){
		N = Nin;
		Np = Npin;
		dat = new Complex<T>[Np];
		T* tmp = new T[Np];
		FS = FSin;

		for(int i = 0 ; i < Np; ++i){
			if(i < N)
				tmp[i] = datIn[i];
			else
				tmp[i] = 0;
		}
		FFT_r2<T>(tmp, dat, Np);
	}


	//linear convolution, in size must be Np
	void convolve(T * in, T * out){
		static Complex<T> * TMP = new Complex<T>[Np];
		FFT_r2<T>(in, TMP, Np);

		//Hadamard product
		for(int i = 0; i < Np; ++i)
			TMP[i] = TMP[i]*dat[i];		
		iFFT_r2<T>(out, TMP, Np);
	}

	//linear convolution with cyclic in
	void convolve_c(T * in, T * out, int start, int inN){
		static T* tmp = new T[Np];
		static Complex<T> * TMP = new Complex<T>[Np];

		for(int i = 0 ; i < Np; ++i){
			int idx = start + i;
			tmp[i] = in[MOD(idx, inN)];
		}
		FFT_r2<T>(tmp, TMP, Np);

		//Hadamard product
		for(int i = 0; i < Np; ++i)
			TMP[i] = TMP[i]*dat[i];
		
		iFFT_r2<T>(out, TMP, Np);
	}

	
};

#endif