#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "winmm.lib")

#include <windows.h>
#include <iostream>
#include <fstream>
#include <dsound.h>

#include "FIR_T.h"
#include "HRIR.h"
#include "HRTF.h"
#include "macros.h"

using namespace std;



//Windows handler
HWND hwnd;
//Direct sound buffers
IDirectSound8* m_DirectSound;
IDirectSoundBuffer* m_primaryBuffer;
IDirectSoundBuffer8 *m_secondaryBuffer;
//int FS = 44100;//sampling rate
int FS = 40960;

int wgnDataN = FS;

DWORD lockSize = FS/1000.0f*100.0f*2;	//100ms worth for 2 channels
//DWORD lockSize = 4096*2;

const char g_szClassName[] = "myWindowClass";
HBITMAP hImage;
BITMAP  bitmapInfo;

int H_ndims, H_ndirs;
float *H_theta, *H_phi, *H_L, *H_R;
HRIR<float> **HRIR_L = NULL, **HRIR_R = NULL;
HRTF<float> **HRTF_L = NULL, **HRTF_R = NULL;

int dirNear = 0;

void P2ThetaPhi(POINT p, float* theta, float* phi){
	RECT rect;
	if(GetClientRect(hwnd, &rect))
	{
		int width = rect.right - rect.left;
		int height = rect.bottom - rect.top;
		*theta = p.y/(float)(height)*PI;
		*phi = (p.x-width/2.0f)/(width/2.0f)*PI;
	}
}

void ThetaPhi2P(POINT *p, float theta, float phi){
	RECT rect;
	if(GetClientRect(hwnd, &rect))
	{
		int width = rect.right - rect.left;
		int height = rect.bottom - rect.top;
		p->y = theta * (float)(height)/PI;
		p->x = phi/PI * (width/2.0f) + width/2.0f;
	}
}


bool initDirectsound(){

	HRESULT result;
	DSBUFFERDESC bufferDesc;
	WAVEFORMATEX waveFormat;


	// Initialize the direct sound interface pointer for the default sound device.
	result = DirectSoundCreate8(NULL, &m_DirectSound, NULL);
	if(FAILED(result))
	{
		return false;
	}

	// Set the cooperative level to priority so the format of the primary sound buffer can be modified.
	result = m_DirectSound->SetCooperativeLevel(hwnd, DSSCL_PRIORITY);
	if(FAILED(result))
	{
		return false;
	}

	// Setup the primary buffer description.
	bufferDesc.dwSize = sizeof(DSBUFFERDESC);
	bufferDesc.dwFlags = DSBCAPS_PRIMARYBUFFER | DSBCAPS_CTRLVOLUME;
	bufferDesc.dwBufferBytes = 0;
	bufferDesc.dwReserved = 0;
	bufferDesc.lpwfxFormat = NULL;
	bufferDesc.guid3DAlgorithm = GUID_NULL;

	// Get control of the primary sound buffer on the default sound device.
	result = m_DirectSound->CreateSoundBuffer(&bufferDesc, &m_primaryBuffer, NULL);
	if(FAILED(result))
	{
		return false;
	}

	// Setup the format of the primary sound bufffer.
	// In this case it is a .WAV file recorded at 44,100 samples per second in 16-bit stereo (cd audio format).
	waveFormat.wFormatTag = WAVE_FORMAT_PCM;
	waveFormat.nSamplesPerSec = FS;
	waveFormat.wBitsPerSample = 16;
	waveFormat.nChannels = 2;
	waveFormat.nBlockAlign = (waveFormat.wBitsPerSample / 8) * waveFormat.nChannels;	//size of block
	waveFormat.nAvgBytesPerSec = waveFormat.nSamplesPerSec * waveFormat.nBlockAlign;
	waveFormat.cbSize = 0;

	// Set the primary buffer to be the wave format specified.
	result = m_primaryBuffer->SetFormat(&waveFormat);
	if(FAILED(result))
	{
		return false;
	}


	//Create secondary buffer
	DSBUFFERDESC dsbdesc; 
	LPDIRECTSOUNDBUFFER pDsb = NULL;
	HRESULT hr; 

	// Set up DSBUFFERDESC structure. 

	memset(&dsbdesc, 0, sizeof(DSBUFFERDESC)); 
	dsbdesc.dwSize = sizeof(DSBUFFERDESC); 
	dsbdesc.dwFlags = 
		DSBCAPS_CTRLPAN | DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLFREQUENCY
		| DSBCAPS_GLOBALFOCUS; 
	//dsbdesc.dwBufferBytes = 2 * 4 * 2* FS;	//4 seconds for 2 channels and 2 bytes per sample
	dsbdesc.dwBufferBytes = DSBSIZE_MAX;
	dsbdesc.lpwfxFormat = &waveFormat; 

	// Create buffer. 
	hr = m_DirectSound->CreateSoundBuffer(&dsbdesc, &pDsb, NULL); 
	if (SUCCEEDED(hr)) 
	{ 
		hr = pDsb->QueryInterface(IID_IDirectSoundBuffer8, (LPVOID*) &m_secondaryBuffer);
		if (FAILED(hr)) {
			return false;
		}
		pDsb->Release();
	} 

	// Set position at the beginning of the sound buffer.
	result = (m_secondaryBuffer)->SetCurrentPosition(0);
	if(FAILED(result))
	{
		return false;
	}

	// Set volume of the buffer to 100%.
	result = (m_secondaryBuffer)->SetVolume(DSBVOLUME_MAX);
	if(FAILED(result))
	{
		return false;
	}

	// Play the contents of the secondary sound buffer.
	result = (m_secondaryBuffer)->Play(0, 0, DSBPLAY_LOOPING );
	if(FAILED(result))
	{
		return false;
	}

	return true;
}


DWORD WINAPI ThreadUpdateBuffer(void* data) {

	//Generate wavedata			
	float* wgnData =  (float*)malloc(sizeof(float)*wgnDataN);
	//randn(wgnData, FS);
	//puretone(wgnData, FS, FS, 238);
	handel(&wgnData, &wgnDataN);

	short* waveData = (short*)malloc(sizeof(short)*lockSize);
	float* waveDataF = (float*)malloc(sizeof(float)*lockSize);
	float* waveDataF2 = (float*)malloc(sizeof(float)*lockSize);

	initDirectsound();


	POINT p;
	while(true){
		if (GetCursorPos(&p) && ScreenToClient(hwnd, &p))
		{
			//cursor position now in p.x and p.y
			char s[100];
			float theta, phi;
			P2ThetaPhi(p, &theta, &phi);
			sprintf_s(s, "HRTF Viewer: theta = %f, phi = %f, nearDir = %d", theta, phi, dirNear);
			SetWindowTextA(hwnd, s);
			Sleep(1); //milliseconds

			//Find nearest direction
			float d = 999;
			for(int i = 0 ; i < H_ndirs; ++i){
				float tmp = gcdist(theta, phi, HRIR_L[i]->theta, HRIR_L[i]->phi);
				if( tmp < d){
					d = tmp;
					dirNear = i;
				}
			}


			//Write sound to buffer
			unsigned char *bufferPtr, *bufferPtr2;
			DWORD bufferSize, bufferSize2;
			// Lock the secondary buffer to write wave data into it.

			HRESULT result = (m_secondaryBuffer)->Lock(0, lockSize, (void**)&bufferPtr, (DWORD*)&bufferSize, (void**)&bufferPtr2, (DWORD*)&bufferSize2, DSBLOCK_FROMWRITECURSOR );
			if(FAILED(result))
			{
				return false;
			}

			//Perform convolution and convert to output format
			DWORD idx = (((DWORD)bufferPtr) / 4) % wgnDataN;


			HRIR_L[dirNear]->convolve_c(wgnData, waveDataF2,				idx, wgnDataN, lockSize/2);
			HRIR_R[dirNear]->convolve_c(wgnData, waveDataF2+lockSize/2,	idx, wgnDataN, lockSize/2);


			//HRTF_R[dirNear]->convolve_c(wgnData, waveDataF2,				idx, FS);
			//HRTF_L[dirNear]->convolve_c(wgnData, waveDataF2+lockSize/2,	idx, FS);


			for(int i = 0; i < lockSize; ++i){
				if(i % 2 == 0)
					waveData[i] = waveDataF2[i/2]*(32767/40);
				else
					waveData[i] = waveDataF2[lockSize/2 + i/2]*(32767/40);
			}



			// Copy the wave data into the buffer.
			// Write to pointers. 

			memcpy(bufferPtr, waveData, bufferSize); 
			if (bufferPtr2 != NULL){ 
				memcpy(bufferPtr2, waveData+bufferSize/sizeof(unsigned short), bufferSize2); 
			} 


			// Unlock the secondary buffer after the data has been written to it.
			result = (m_secondaryBuffer)->Unlock((void*)bufferPtr, bufferSize, (void*)bufferPtr2, bufferSize2);
			if(FAILED(result))
			{
				return false;
			}

		}
	}
	return 0;
}



void loadFile(){
	OPENFILENAME ofn;
	char szFileName[MAX_PATH] = "./";

	ZeroMemory(&ofn, sizeof(ofn));

	ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
	ofn.hwndOwner = hwnd;
	ofn.lpstrFilter = "Binary Files (*.bin)\0*.bin\0All Files (*.*)\0*.*\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = ".bin";


	// Do something usefull with the filename stored in szFileName 

	//Load HRIRs:
	//int H_ndims: Taps in HRIR
	//int H_ndirs: Number of HRIR directions
	//float H_theta[H_ndirs]: Polor coordinate theta, radians, [0, PI] => top of head, bot of head in elevation
	//float H_phi[H_ndirs]: Polor coordinate phi, radians [-PI, 0, PI] => back of head from left side, center of nose, back of head from right side
	//float H_L[H_ndims][H_ndirs]: Left-ear HRIRs
	//float H_R[H_ndims][H_ndirs]: Right-ear HRIRs

	ifstream myfile;
	if(GetOpenFileName(&ofn)){
		myfile.open(szFileName, ios::in | ios::binary); 
	}else{
		myfile.open("CIPIC_32.bin", ios::in | ios::binary); 
	}

	myfile.read((char*)&H_ndims, sizeof(int));
	myfile.read((char*)&H_ndirs, sizeof(int));

	if(HRIR_L != NULL){
		free(H_theta);
		free(H_phi);
		free(H_L);
		free(H_R);
	}

	H_theta = (float*)malloc(sizeof(float) * H_ndirs);
	H_phi = (float*)malloc(sizeof(float) * H_ndirs);
	H_L = (float*)malloc(sizeof(float) * H_ndims*H_ndirs);
	H_R = (float*)malloc(sizeof(float) * H_ndims*H_ndirs);

	myfile.read((char*)H_theta, sizeof(float)*H_ndirs);
	myfile.read((char*)H_phi, sizeof(float)*H_ndirs);
	myfile.read((char*)H_L, sizeof(float)* H_ndims*H_ndirs);
	myfile.read((char*)H_R, sizeof(float)* H_ndims*H_ndirs);
	myfile.close();

}


// Step 4: the Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT Ps;
	HDC         hDC;
	HDC hdcMem;
	RECT rect;
	HPEN hPenR;
	hPenR = CreatePen(PS_SOLID,1,RGB(255,0,0));

	switch(msg)
	{
	case WM_LBUTTONDOWN:
		break;
	case WM_RBUTTONDOWN:
		break;
	case WM_PAINT:
		GetClientRect(hwnd, &rect);
		hDC = BeginPaint(hwnd, &Ps);
		hdcMem = CreateCompatibleDC(hDC); // hDC is a DC structure supplied by Win32API
		SelectObject(hdcMem, hImage);

		StretchBlt(
			hDC,         // destination DC
			0,        // x upper left
			0,         // y upper left
			rect.right-rect.left,       // destination width
			rect.bottom-rect.top,      // destination height
			hdcMem,	     // you just created this above
			0,
			0,			// x and y upper left
			bitmapInfo.bmWidth,			// source bitmap width
			bitmapInfo.bmHeight,			// source bitmap height
			SRCCOPY);	// raster operation

		SelectObject(hDC, hPenR);
		for(int i = 0 ; i < H_ndirs; ++i){
			POINT p;
			ThetaPhi2P(&p,  HRIR_L[i]->theta, HRIR_L[i]->phi);
			Ellipse(hDC, p.x-4, p.y-4, p.x+4, p.y+4);
		}

		DeleteDC(hdcMem);
		EndPaint(hwnd, &Ps);
		break;

	case WM_CLOSE:
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASSEX wc;
	MSG Msg;

	//Step 1: Registering the Window Class
	wc.cbSize        = sizeof(WNDCLASSEX);
	wc.style         = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName  = NULL;
	wc.lpszClassName = g_szClassName;
	wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

	if(!RegisterClassEx(&wc))
	{
		MessageBox(NULL, "Window Registration Failed!", "Error!",
			MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Step 2: Creating the Window
	hwnd = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		g_szClassName,
		"HRTF Viewer",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 1024/2, 768/2,
		NULL, NULL, hInstance, NULL);

	if(hwnd == NULL)
	{
		MessageBox(NULL, "Window Creation Failed!", "Error!",
			MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	//Load image
	LPCSTR texpath = "tex1.bmp";
	hImage = (HBITMAP)LoadImage(NULL, (LPCSTR)texpath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
	GetObject(hImage, sizeof( BITMAP ), &bitmapInfo );

	loadFile();

	//Setup HRIRs
	HRIR_L = (HRIR<float>**)malloc(sizeof(HRIR<float>*) * H_ndirs);
	HRIR_R = (HRIR<float>**)malloc(sizeof(HRIR<float>*) * H_ndirs);
	for(int i = 0 ; i < H_ndirs; ++i){
		HRIR_L[i] = new HRIR<float>(H_ndims, &H_L[i*H_ndims], FS, H_theta[i], H_phi[i]);
		HRIR_R[i] = new HRIR<float>(H_ndims, &H_R[i*H_ndims], FS, H_theta[i], H_phi[i]);
	}

	//setup HRTFs
	/*HRTF_L = (HRTF<float>**)malloc(sizeof(HRTF<float>*) * H_ndirs);
	HRTF_R = (HRTF<float>**)malloc(sizeof(HRTF<float>*) * H_ndirs);
	for(int i = 0 ; i < H_ndirs; ++i){
	HRTF_L[i] = new HRTF<float>(H_ndims, lockSize/2, &H_L[i*H_ndims], FS, H_theta[i], H_phi[i]);
	HRTF_R[i] = new HRTF<float>(H_ndims, lockSize/2, &H_R[i*H_ndims], FS, H_theta[i], H_phi[i]);
	}
	*/

	//Draw windows
	ShowWindow(hwnd, SW_MAXIMIZE);
	UpdateWindow(hwnd);

	//Create thread for updating sound buffer
	HANDLE thread = CreateThread(NULL, 0, ThreadUpdateBuffer, NULL, 0, NULL);


	// Step 3: The Message Loop
	while(GetMessage(&Msg, NULL, 0, 0) > 0)
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	return Msg.wParam;
}

