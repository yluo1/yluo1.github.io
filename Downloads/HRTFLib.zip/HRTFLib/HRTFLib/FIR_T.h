#ifndef FIR_T_H
#define FIR_T_H

#include "FIR.h"
#include "macros.h"

//Finite impulse response, time-domain
template <class T>
class FIR_T : public FIR{
public:
	T *dat;

	FIR_T(){
		N = 0;
		FS = 0;
	}

	FIR_T(int Nin, T *datIn, int FSin){
		N = Nin;
		dat = (T*) malloc(Nin*sizeof(T));
		memcpy(dat, datIn, Nin*sizeof(T));
		FS = FSin;
	}

	//linear convolution
	void convolve(T * in, T * out, int M){
		memset(out, 0, sizeof(T)*(M));
		for(int i = 0; i < M; ++i){
			for(int j = 0; j < N; ++j){
				int idx = i-j;
				if(idx >= 0)
					out[i] += dat[j] * in[idx];
			}
		}
	}

	//linear convolution with cyclic in
	void convolve_c(T * in, T * out, int start, int inN, int M){
		memset(out, 0, sizeof(T)*(M));
		for(int i = 0; i < M; ++i){
			for(int j = 0; j < N; ++j){
				int idx = start + i-j;
				out[i] += dat[j] * in[MOD(idx, inN)];
			}
		}
	}


};

#endif