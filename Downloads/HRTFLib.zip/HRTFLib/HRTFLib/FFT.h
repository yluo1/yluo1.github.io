#ifndef FFT_H
#define FFT_H

#include "Complex.h"
#include "macros.h"

//find floor(log_2(N))
int msb_p(int N){
	int p = 0;
	while(N){
		N = N >> 1;
		++p;
	}
	return p-1;
}


//swap bits a, b from right (0 is right-most bit) of N
int swap_bits(int N, int a, int b){
	if(a < b){
		int tmp = a;
		a = b;
		b = tmp;
	}
	return (N &  ~((1 << a) | (1 << b))) | 	((N & (1 << a)) >> (a - b)) | ((N & (1 << b))  << (a - b));
}

//reverse all bits upto msb
int rev_msb(int N, int msb){
	for(int i = 0 ; i < msb/2; ++i){
		N = swap_bits(N, i, msb-1-i);
	}
	return N;
}

template <typename T>
void FFT_r2(T* x, Complex<T>* X, int N){
	//Bit-reveral ordering
	static int n = 0;
	static int p = 0;
	static int *ridx = NULL;
	if(N != n){
		if((N & (N-1)) == 0){
			p = msb_p(N);
		}else{
			return;
		}
		n = N;
		free(ridx);
		ridx = new int[N];
		for(int i = 0 ; i < N; ++i)
			ridx[i] = rev_msb(i, p);
	}

	//Make complex datatype
	for(int i = 0 ; i < N; ++i){
		X[ridx[i]] = x[i];
	}

	//perform fft
	int s = 2;
	for(int i = 0; i < p; ++i){
		for(int j = 0 ; j < N; j += s){
			int m = j + s/2;
			for(int k = 0; k < s/2; ++k){
				Complex<T> t = X[j+k];
				Complex<T> e = Complex<T>::exp((T)(-2* PI  *k/s));
				X[j+k] = t + e * X[m + k];
				X[m+k] = t - e * X[m + k];
			}
		}
		s = s * 2;
	}
}

template <typename T>
void iFFT_r2(T* x, Complex<T>* X, int N){
	//Bit-reveral ordering
	static int n = 0;
	static int p = 0;
	static int *ridx = NULL;
	static Complex<T> * xc = NULL;
	if(N != n){
		if((N & (N-1)) == 0){
			p = msb_p(N);
		}else{
			return;
		}
		n = N;
		free(ridx);
		free(xc);
		xc = new Complex<T>[N];
		ridx = new int[N];
		for(int i = 0 ; i < N; ++i)
			ridx[i] = rev_msb(i, p);
	}

	//Make complex datatype
	for(int i = 0 ; i < N; ++i){
		xc[ridx[i]] = X[i];
		xc[ridx[i]].conj();
	}

	//perform fft
	int s = 2;
	for(int i = 0; i < p; ++i){
		for(int j = 0 ; j < N; j += s){
			int m = j + s/2;
			for(int k = 0; k < s/2; ++k){
				Complex<T> t = xc[j+k];
				Complex<T> e = Complex<T>::exp((T)(-2* PI  *k/s));
				xc[j+k] = t + e * xc[m + k];
				xc[m+k] = t - e * xc[m + k];
			}
		}
		s = s * 2;
	}

	for(int i = 0 ; i < N; ++i)
		x[i] = xc[i].real / N;
}

#endif