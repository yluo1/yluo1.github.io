#ifndef COMPLEX_H
#define COMPLEX_H

template <class T>
class Complex{
public:
	T real;
	T imag;

	Complex(){
		real = 0;
		imag = 0;
	}

	Complex(T real_in, T imag_in){
		real = real_in;
		imag = imag_in;
	}

	void print(){
		cout << real << " + " << imag << "i\n";
	}

	void conj(){
		imag = -imag;
	}
	
	T abs(){
		return real*real + imag*imag;
	}

	Complex operator=(const Complex& other){
		real = other.real;
		imag = other.imag;
		return *this;
	}
	Complex operator=(const T& other){
		real = other;
		imag = 0;
		return *this;
	}
	
	Complex operator+(const Complex& other){
		return Complex(real  + other.real, imag + other.imag);
	}
	Complex operator+(const T& other){
		return Complex(real  + other, imag);
	}

	Complex operator-(const Complex& other){
		return Complex(real  - other.real, imag - other.imag);
	}
	Complex operator-(const T& other){
		return Complex(real  - other, imag);
	}

	Complex operator*(const Complex& other){
		return Complex(real * other.real - imag * other.imag, real * other.imag + imag * other.real);
	}
	Complex operator*(const T& other){
		return Complex(real * other, real * other);
	}


	
	Complex operator/(const T& other){
		return Complex(real / other, imag / other);
	}

	Complex operator/(const Complex& other){
		T otherabs = other.abs();
		return Complex(real * other.real + imag * other.imag,  imag * other.real - real * other.imag) / otherabs;
	}

	static Complex exp(T x){
		return Complex(cos(x), sin(x));
	}
};

#endif