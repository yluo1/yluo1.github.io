#ifndef HRTF_H
#define HRTF_H

#include "FIR_F.h"

template <class T>
class HRTF : public FIR_F<T>{
public:
	float theta, phi;	//spherical coordinates in radians
	HRTF(){
		theta = 0;
		phi = 0;
	}

	HRTF(int Nin, int Npin, T *datIn, int FSin, float thetaIn, float phiIn)  : FIR_F(Nin, Npin, datIn, FSin) {
		theta = thetaIn;
		phi = phiIn;
	}
	


};

#endif