#include "macros.h"

//Box-muller, fill array a with n normally distributed random numbers
void randn(float *a, int n){
	for(int i = 0 ; i < n; i+=2){
		float u = rand()/(float)RAND_MAX;
		float v = rand()/(float)RAND_MAX;
		float r  = sqrt(-2 * log(u));
		a[i] = r * cos(2*PI*v);
		if(i+1 < n){
			a[i+1] = r * sin(2*PI*v);
		}
	}
}

void puretone(float *a, int n, int FS, float freq){
	for(int i = 0 ; i < n; ++i){
		a[i] = sin(2*PI*(((float)i) /FS) * freq);
	}
}

void handel(float **a, int* aN){
	FILE *fi  = fopen("handel.bin", "rb");
	fread(aN, sizeof(int), 1, fi);
	*a = (float*) realloc(*a, sizeof(float)*(*aN));
	fread(*a, sizeof(float), *aN, fi);
	fclose(fi);
}

float gcdist(float theta1, float phi1, float theta2, float phi2){
	float sindtheta = sin(abs(theta2 - theta1)/2);
	float sinphi = sin(abs(phi2 - phi1)/2);
	return 2*asin(sqrt(sindtheta*sindtheta  + cos(PI/2-theta1)*cos(PI/2-theta2)*sinphi*sinphi));
}
