#ifndef MACROS_H
#define MACROS_H

#include <windows.h>
#include <iostream>

#define PI 3.14159265358979323846

#define MIN(a,b) (a<b ? a : b)
#define MAX(a,b) (a>b ? a : b)
#define MOD(a,b) ((a)%(b) >= 0 ? (a)%(b) : ((a)%(b)) + (b))


void randn(float *a, int n);
void puretone(float *a, int n, int FS, float freq);
void handel(float**a, int* aN);

float gcdist(float theta, float phi, float theta2, float phi2);

#endif