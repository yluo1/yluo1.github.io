HRIR Listener:
Direct-sound implementation of time-domain HRIR convolution with a Gaussian white noise process. A binary file containing floating point HRIRs and spherical-coordinate measurement directions is read. A GUI displaying a mercator projection of the HRIR measurements allows the listener to hear the HRIRs by running his/her mouse over the grid. The spatially nearest HRIR is rendered in real-time.

Author: Yuancheng [Mike] Luo, 5/20/2014

Notes/instructions:

1. On program execution, open CIPIC_*.bin.

CIPIC_*.bin is a binary file in the format 32bit little endian ints and floats:

//int H_ndims: Taps in HRIR
//int H_ndirs: Number of HRIR directions
//float H_theta[H_ndirs]: Polor coordinate theta, radians, [0, PI] => top of head, bot of head in elevation
//float H_phi[H_ndirs]: Polor coordinate phi, radians [-PI, 0, PI] => back of head from left side, center of nose, back of head from right side
//float H_L[H_ndims][H_ndirs]: Left-ear HRIRs
//float H_R[H_ndims][H_ndirs]: Right-ear HRIRs


Sample .bin are taken from subjects from the CIPIC dataset.

V. R. Algazi, R. O. Duda, D. M. Thompson and C. Avendano, "The CIPIC HRTF Database," Proc. 2001 IEEE Workshop on Applications of Signal Processing to Audio and Electroacoustics, pp. 99-102, Mohonk Mountain House, New Paltz, NY, Oct. 21-24, 2001.

2. Put on head-phones and move cursor around measurement grid to change sound-source direction.

------------------------------------Copyright
HRTFLib is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

HRTFLib is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HRTFLib .  If not, see <http://www.gnu.org/licenses/>.