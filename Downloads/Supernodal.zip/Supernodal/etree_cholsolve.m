%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [Lmat time] = etree_cholsolve(A, method)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%   method:     scalar:     1 = direct factorization without dense panel
%               updates,    2 = direct factorization with dense panel
%               updates
%Output:
%   Lmat:       mxm sparse matrx: Factorized matrix s.t. A=Lmat*Lmat'
%   time:       3x1 vector of times for preordering, symbolic
%               factorization, and numerical factorization.
%
%Functionality:
%   For matrix A, compute direct factorizations of matrix A using elimination
%   trees in the symbolic factorization phase and a post-order traversal of
%   the elimination tree in the numerical factorization phase. No
%   preordering phase is used for experiments.

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Lmat time] = etree_cholsolve(A, method)

global M;
[M N] = size(A);

if M ~= N
    disp('Matrix A must have same dimensions');
    return
end

if ~issparse(A)
    disp('Matrix A must be sparse');
    return
end

global L;               %Lower triangular factorization
L = tril(A);

time = zeros(3,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Preorder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%None (usually Cuthill�McKee or nested disection)

time(1,1) = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Symbolic Factorization: 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
global li;              %Build elimination tree
global stn;             %Elimination tree's sub-tree nodes
[p li stn] = etreemod(A);  


global et;              %Complete elimination tree list for children nodes
et = cell(M,1);        
for i=1:M
  et{i, 1} = find(p == i)';
end

er =   find(p == 0);    %Find elimination tree's roots (column indices)
nroots  = size(er, 1);
time(2,1) = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Numerical Factorization:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic

for i=1:nroots
    %Traverse roots of elimination tree
    if method == 1
       etree_cholsolve_recur_d(er(i));
    elseif method == 2
       etree_cholsolve_recur_d2(er(i));
    end
end

time(3,1) = toc;
Lmat = L;

