%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function sn_cholsolve_recur_i(nodei, tau, yu)
%Incomplete Factorization: Recursively factorize A into LL' using elimination tree:
%Input:
%   nodei:      nodei:      supernode ID located in the supernode
%                           elimination tree
%   tau:        scalar:     dropping threshold
%   yu:         scalar:     target threshold number of row-indices per supernode
%                           (yu * #row indices prior to factorization)
%Output:
%   None
%
%Functionality:
%   Perform an incomplete left-looking cholesky decomposition on columns from a
%   post-order traversal of the supernodal elimination tree to factorize
%   L.

%   Panel update: dense column

%   Dropping:       dropscore(row i) =  1/(m columns) * sum(abs(L(i,j)/L(j,j))) 
%                   for j=k:k+m-1, i>=k+m
%                   drop if dropscore < tau
%
%                   Secondary drop if rows remaining > yu*rows initial
%                   tau2 = dmax*dmin/(dmin+target/l_remain*(dmax-dmin))
%                   dmax is max drop score <=1
%                   dmin is min drop score >=tau
%                   drop if dropscore < updated tau2
%                   See reference [1] for more details
%
%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sn_cholsolve_recur_i(nodei, tau, yu)

global snt;         %Elimination tree
global sn_li;       %non-zero patterns in supernodes
global sn_c;        %columns in supernodes
global L;           %Lower triangular factorization to update
global visited;     %0 = unvisited supernode, 1 = visited
global sn_li0;      %initial non-zero rows in supernodal i
global sn_stn;      %Supernodal cell of sub-tree supernodes of supernodal i

%Mark as visited
visited(nodei) = 1;

%Post-order traversal
for i=snt{nodei,1}
    if visited ( i ) == 0           %Supernode unvisited
        sn_cholsolve_recur_i(i , tau, yu)
    end
end

%Left-looking cholesky factorization 
%Load supernode nodei into a dense column block
LdcM = size(sn_li{nodei,1}, 1);                     %Non-zero rows in supernode
LdcN = size(sn_c{nodei,1}, 1);                      %Columns in supernode
Ldc = zeros(LdcM, LdcN);

Ldc(:,:) =  L( sn_li{nodei,1} , sn_c{nodei,1});

for i=sn_stn{nodei,1}
   Ldc_iN = size( sn_c{i, 1}, 1);
   for j=sn_c{nodei, 1}'
       if isempty( find( sn_li{i,1} == j ) ) == 0
            %row j appears in pattern of supernode i so update nodei

            %Load supernode i into dense block and perform blas3 update

            Ldc_i = zeros(LdcM, Ldc_iN);
            Ldc_i(:,:) =  L( sn_li{nodei,1} , sn_c{i, 1});

            Ldc = Ldc -  Ldc_i * Ldc_i(1:LdcN,:)';
            break;
       end
   end
end


%Factorize supernode nodei, update diagonals, divide
for i=1:LdcN
    for j=1:i-1
        Ldc(i:LdcM, i) = Ldc(i:LdcM, i) -  Ldc(i,j) * Ldc(i:LdcM, j);
    end
    Ldc(i,i) = sqrt(Ldc(i,i));
    Ldc(i+1 : LdcM, i) = Ldc(i+1 : LdcM, i) / Ldc(i,i);
end

%Apply row dropping criteria
dropScore = zeros(LdcM, 1);
droppedRows = [];
rowsRemaining = ones(LdcM, 1);

for i=LdcN+1:LdcM
    for j=1:LdcN
        dropScore(i, 1) = dropScore(i, 1) + abs( Ldc(i,j) / Ldc(j,j) ) ;
    end
    dropScore(i, 1) = dropScore(i, 1)/LdcN;
    if dropScore(i, 1) < tau
        droppedRows = [droppedRows; i];
        rowsRemaining(i) = 0;
        Ldc(i, :) = 0;
    end
end

rRemains = LdcM - size(droppedRows, 1);
target = yu*sn_li0(nodei);
    
if rRemains > target
    %Recompte tau
    %Find dmax = maximum drop score less than or equal to 1.0
    %Find dmin = minimum drop score greater than or equal to tau
    dscore_leq1 = find(dropScore <= 1.0);
    dmax = max(dropScore(dscore_leq1));
    dscore_greTau = find(dropScore >= tau);
    dmin = min(dropScore(dscore_greTau));

    tau = dmax*dmin / (dmin + target/rRemains * (dmax - dmin));

    for i=LdcN+1:LdcM
        if rowsRemaining(i) == 1
            if dropScore( i, 1) < tau
                 droppedRows = [droppedRows; i];
                 rowsRemaining(i) = 0;
                 Ldc(i, :) = 0;
            end
        end
    end

end
   

%Write back to sparse format
L( sn_li{nodei,1} , sn_c{nodei,1}) = Ldc;

%Remove dropped rows from supernodal row-indices list
if ~isempty(droppedRows)
    sn_li{nodei,1}(droppedRows) = []; 
end

