%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sn_cholsolve_test(A, m, density, oThres, tau, yu, ploton)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%   m:          scalar:     Number of rows in matrix A
%   density:    scalar:     0 to 1 percent of non-zeros in random A
%   oThres:     scalar:     required percent of similar row indices between
%                           adjacent supernodes 
%   tau:        scalar:     dropping threshold
%   yu:         scalar:     target threshold number of row-indices per supernode
%                           (yu * #row indices prior to factorization)
%   ploton:     scalar:     1 = display plots of factorization, 0 = not
%Output:
%   None
%
%Functionality:
%   For matrix A, run the supernodal cholesky algorithm for direct and
%   incomplete factorizations. Recording timings and compute residuals

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sn_cholsolve_test(A, m, density, oThres, tau, yu, ploton)

%if A is empty, generate random mxm SPD matrix
if isempty(A)
  A = sprandsym(m, density, abs(rand(m,1)) );
end

m = size(A, 1);

%run tests
[L1 t1] = sn_cholsolve(A, oThres, 0, tau, yu);
[L2 t2] = sn_cholsolve(A, oThres, 1, tau, yu);


%Display time
disp('Times [preordering, symbolic factorization, numerical factorization], totalTime');
disp('sn_cholsolve 0: direct factorization');
t1
sum(t1)
disp('sn_cholsolve 1: incomplete factorization');
t2
sum(t2)

%Reference solution
Lp = chol(A, 'lower');
Li = cholinc(A, inf)';

%Differences between A and reconstructed LL'
disp('norm2 residuals: chol, cholinc, direct sn_cholsolve, incomplete sn_cholsolve');
norm(full(A-Lp*Lp'))
norm(full(A-Li*Li'))
norm(full(A-L1*L1'))
norm(full(A-L2*L2'))
   


%if plot is enabled, print from diagnostics
if ploton == 1
    
    figure; hold on;
    title('tril(A)');
    spy(tril(A));
  
    figure;  hold on;
    title('L from built-in direct cholesky');
    spy(Lp);
    
    figure;  hold on;
    title('L from built-in incomplete inf-cholesky');
    spy(Li);
    
    figure;  hold on;
    title('L from supernodal direct cholesky');
    spy(L1);
        
    figure;  hold on;
    title('L from supernodal incomplete cholesky');
    spy(L2);


end

  
   

    
