%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [Lmat time] = sn_cholsolve(A, oThres, method, tau, yu)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%   oThres:     scalar:     required percent of similar row indices between
%                           adjacent supernodes 
%   method:     scalar:     1 = direct factorization via supernodes
%                           2 = incomplete factorization via supernodes
%   tau:        scalar:     dropping threshold
%   yu:         scalar:     target threshold number of row-indices per supernode
%                           (yu * #row indices prior to factorization)

%Output:
%   Lmat:       mxm sparse matrx: Factorized matrix s.t. A=Lmat*Lmat'
%   time:       3x1 vector of times for preordering, symbolic
%               factorization, and numerical factorization.
%
%Functionality:
%   For matrix A, compute direct factorizations of matrix A using elimination
%   trees in the symbolic factorization phase and a post-order traversal of
%   the elimination tree in the numerical factorization phase. No
%   preordering phase is used for experiments.

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Lmat time] = sn_cholsolve(A, oThres, method, tau, yu)

global M;
[M N] = size(A);

if M ~= N
    disp('Matrix A must have same dimensions');
    return
end

if ~issparse(A)
    disp('Matrix A must be sparse');
    return
end

global L;                   %Lower triangular factorization
L = tril(A);

time = zeros(3,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Preorder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%None (usually Cuthill�McKee or nested disection)

time(1,1) = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Symbolic Factorization: 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
global sn_li;              %Build elimination tree
global sn_c;
global sn_stn;
[p li stn] = etreemod(A);                           %Build elimnation tree
[sn_p sn_li sn_c sn_stn] = sn_etree(p, li, oThres);    %Build supernodal tree

%Complete supernodal graph
global snt;
sn_M = size(sn_c, 1);
snt = cell(sn_M, 1);                            %Supernodal tree

%Complete elimination tree for children nodes
for i = 1:sn_M
    for j=1:sn_M
        if isempty(find(sn_p{j,1} == i)) == 0
            snt{i, 1} = union( snt{i,1}, j);
        end
    end
end


%Find Supernodal graph roots
snt_r = [];
for i = 1:sn_M
    if isempty (sn_p{i,1} )
        snt_r = union( snt_r, i);
    end
end
snt_r = snt_r';
nroots = size(snt_r, 1);

global sn_li0;    
if method == 1
    %Determine number of initial non-zero rows in supernodal i
    
    sn_li0 = zeros(sn_M, 1); 
    for i=1:sn_M
        sn_i_M = size(sn_li{i, 1} ,1 );
        for j=1:sn_i_M
            if ~all(~L( sn_li{i,1}(j,1), sn_c{i,1} ))
                sn_li0(i) = sn_li0(i) + 1;
            end
        end
    end
end

time(2,1) = toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Numerical Factorization:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
global visited;
visited = zeros(sn_M, 1);   %0 = unvisited supernode, 1 = visited

for i=1:nroots
    %Traverse roots of elimination tree
    if method == 0
        sn_cholsolve_recur_d(snt_r(i));
    elseif method == 1
        sn_cholsolve_recur_i(snt_r(i),  tau, yu);
    end
end

time(3,1) = toc;

Lmat = tril(L);

