%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [L time] = cholesky_naive(A)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%Output:
%   L:          mxm sparse matrix of factorized L, A=LL'
%   time:       time taken to compute factorization
%
%Functionality:
%   For matrix A, perform a left-looking cholesky decomposition on matrix A

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [L time] = cholesky_naive(A)

M = size(A, 1);

L = tril(A);

tic
%Left-looking cholesky factorization
for nodei=1:M
    for i=1:nodei-1
        %row j appears in pattern of col i so update nodei
        L(nodei:M, nodei) = L(nodei:M, nodei) - L(nodei, i) * L(nodei:M, i);
    end

    %Update diagonal and divide
    L(nodei, nodei) = sqrt(L(nodei, nodei));
    L((nodei+1):M, nodei) = L((nodei+1):M, nodei) / L(nodei, nodei);
end
time=toc;
