%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function etree_cholsolve_recur_d(nodei)
%Input:
%   nodei:      column ID located in the elimination tree
%Output:
%   None
%
%Functionality:
%   Perform a direct left-looking cholesky decomposition on columns from a
%   post-order traversal of the elimination tree to factorize
%   L

%   Panel updates: sparse

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function etree_cholsolve_recur_d(nodei)

global et;      %Elimination tree
global li;      %non-zero pattern
global L;       %Lower triangular factorization to update
global M;       %Total # of columns
global stn;     %Elimination tree's sub-tree nodes

%Post-order traversal
for i=et{nodei,1}
    etree_cholsolve_recur_d(i)
end

%Left-looking cholesky factorization
for i=stn{nodei,1}
   if isempty( find( li{i,1} == nodei ) ) == 0
        %row j appears in pattern of col i so update nodei
        L(nodei:M, nodei) = L(nodei:M, nodei) - L(nodei, i) * L(nodei:M, i);
   end
end

%Update diagonal and divide
L(nodei, nodei) = sqrt(L(nodei, nodei));
L((nodei+1):M, nodei) = L((nodei+1):M, nodei) / L(nodei, nodei);
