%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function sn_cholsolve_recur_d(nodei)
%Input:
%   nodei:      supernode ID located in the supernode elimination tree
%Output:
%   None
%
%Functionality:
%   Perform a direct left-looking direct cholesky decomposition on columns from a
%   post-order traversal of the supernodal elimination tree to factorize
%   L

%   Panel updates: sparse

%   Dropping:   none
%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sn_cholsolve_recur_d(nodei)

global snt;         %Elimination tree
global sn_li;       %non-zero patterns in supernodes
global sn_c;        %columns in supernodes
global L;           %Lower triangular factorization to update
global visited;     %0 = unvisited supernode, 1 = visited
global sn_stn;      %Supernodal cell of sub-tree supernodes of supernodal i

%Mark as visited
visited(nodei) = 1;

%Post-order traversal
for i=snt{nodei,1}
    if visited ( i ) == 0           %Supernode unvisited
        sn_cholsolve_recur_d(i)
    end
end

%Left-looking cholesky factorization
%Load supernode nodei into a dense column block
LdcM = size(sn_li{nodei,1}, 1);                     %Non-zero rows in supernode
LdcN = size(sn_c{nodei,1}, 1);                       %Columns in supernode
Ldc = zeros(LdcM, LdcN);

Ldc(:,:) =  L( sn_li{nodei,1} , sn_c{nodei,1});

for i=sn_stn{nodei,1}
   Ldc_iN = size( sn_c{i, 1}, 1);
   for j=sn_c{nodei, 1}'
       if isempty( find( sn_li{i,1} == j ) ) == 0
            %row j appears in pattern of supernode i so update nodei

            %Load supernode i into dense block and perform blas3 update

            Ldc_i = zeros(LdcM, Ldc_iN);
            Ldc_i(:,:) =  L( sn_li{nodei,1} , sn_c{i, 1});

            Ldc = Ldc -  Ldc_i * Ldc_i(1:LdcN,:)';
            break;
       end
   end
end


%Factorize supernode nodei, update diagonals, divide
for i=1:LdcN
    for j=1:i-1
        Ldc(i:LdcM, i) = Ldc(i:LdcM, i) -  Ldc(i,j) * Ldc(i:LdcM, j);
    end
    Ldc(i,i) = sqrt(Ldc(i,i));
    Ldc(i+1 : LdcM, i) = Ldc(i+1 : LdcM, i) / Ldc(i,i);
end

%Write back to sparse format
L( sn_li{nodei,1} , sn_c{nodei,1}) = Ldc;
