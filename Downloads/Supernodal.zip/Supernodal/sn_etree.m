%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function  [sn_p sn_li  sn_c] = sn_etree(p, li, oThres)
%Input:    

%   p:          Mx1 Vector of edge to parent in elimination tree
%               e.g. p(1) = 2 implies column 1 needs to be factorized before 2
%   li:         Mx1 Cell containing vectors for each column the
                %non-zero (w/ fill-in) patterns in factor L
%   oThres:     scalar:     required percent of similar row indices between
%                           adjacent supernodes 

%Output:
%   sn_p:      _x1 Cell of Mx1 Vectors of edges to parents in elimination tree
%              e.g. sn_p{1, 1} = 2 implies supernode 1 needs to be factorized before 2
%   sn_li:     _x1 Cell containing row-index vectors for each supernode the
%              non-zero (w/ fill-in) patterns in cholesky factorized  L
%   sn_c:      _x1 Cell containing vectors to columns per supernode
%   sn_stn:    _x1 cell containing vectors of list of sub-tree supernodes

%Functionality:
%   Generate supernodal elimination tree for sparse matrix A. oThres
%   determines the ratio of overlapping row-indices between adjacent
%   columns needed to satisfy forming a supernode.

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function  [sn_p sn_li  sn_c sn_stn] = sn_etree(p, li, oThres)

M = size(p, 1);
 
li_sn = zeros(M, 1);    %column supernode ref
sn_curr = 1;            %Current supernode ID

li_sn(1, 1) = sn_curr;

%First pass: find similar blocks by overlap columns
for i = 2:M
    overlapPattern = intersect( li{i,1}, li{i-1, 1} ); 
    ratio = size( overlapPattern, 1) / (size( li{i,1}, 1));
    
 %   unionPattern = union(li{i,1}, li{i-1, 1});
   % ratio = (size( li{i-1,1}, 1)) / size( unionPattern, 1);
    
    %to make a new supernode, ratio <= oThres or column node not parent of
    %previous node
    if ratio <= oThres || p(i-1) ~= i
        sn_curr = sn_curr + 1;
    end
    
    li_sn(i, 1) = sn_curr;   
end

%Initialize supernodal tree
sn_p =  cell(sn_curr, 1);       %Supernodal edge to set of parents
sn_li = cell(sn_curr, 1);       %Supernodal cell of row indicies in supernodal i
sn_c =  cell(sn_curr, 1);       %Supernodal cell of columns indices in supernodal i
sn_stn = cell(sn_curr, 1);      %Supernodal cell of sub-tree supernodes of supernodal i

%Second pass: complete supernodal tree structure
for i = 1:M
    if p(i) > 0 && li_sn( p(i), 1) ~= li_sn( i, 1)
        sn_p{li_sn(i, 1), 1} = union( sn_p{li_sn(i, 1), 1}, li_sn( p(i), 1) );
        sn_stn{li_sn( p(i), 1), 1} = union( union( sn_stn{li_sn( p(i), 1)}, sn_stn{li_sn(i, 1),1} ), li_sn(i, 1));
    end  
    sn_li{li_sn(i, 1), 1} = union( sn_li{li_sn(i, 1), 1}, li{i, 1} );
    sn_c{li_sn(i, 1), 1} = union( sn_c{li_sn(i, 1), 1}, i);
end

%Transpose
for i=1:sn_curr
   sn_c{i, 1} = sn_c{i, 1}';
end



