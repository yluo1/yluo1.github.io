%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function precon_tests(A, m, density, oThres)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%   m:          scalar:     Number of rows in matrix A
%   density:    scalar:     0 to 1 percent of non-zeros in random A
%   oThres:     scalar:     required percent of similar row indices between
%                           adjacent supernodes 
%Output:
%   None
%
%Functionality:
%   For matrix A, compute preconditioners from inf-cholinc and incomplete 
%   cholesky factorization with static supernodes (ICFSS) with varied tau,
%   yu parameters. Test preconditioner for solving artifical linear system
%   Ax=ones(m,1) via PCG with 1e-6 tol and 1000 max iterations.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function precon_tests(A, m, density, oThres)

%if A is empty, generate random mxm SPD matrix
if isempty(A)
	A = sprandsym(m, density, abs(rand(m,1)) );
end

m = size(A, 1);

%Run PCG Test
b = ones(m, 1);
    
disp('PCG without preconditioning');
tic
x = pcg(A,b, 1e-6, 1000);
toc

disp('PCG with cholinc preconditioner');
Li = cholinc(A, 'inf');
tic
x = pcg(A,b, 1e-6, 1000, Li, Li');
toc

%Run sn_cholsolve incomplete factorization for various tau, yu
disp('PCG with sn_cholsolve preconditioner');
for i = 2:5             %Vary tau
    tau = 10^(-i);
    for yu=1:.5:3     %Vary yu
        tau
        yu
        %Produce preconditioners
        [L2 t2] = sn_cholsolve(A, oThres, 1, tau, yu);
        
        %Print timing
        disp('sn_cholsolve timing');
        t2
        sum(t2)
        %Run PCG Test
        tic
        x = pcg(A,b, 1e-6, 1000, L2, L2');
        toc
    end
end