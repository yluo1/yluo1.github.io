%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function etree_cholsolve_recur_d2(nodei)
%Input:
%   nodei:      column ID located in the elimination tree
%Output:
%   None
%
%Functionality:
%   Perform a directleft-looking cholesky decomposition on columns from a
%   post-order traversal of the elimination tree to factorize
%   L

%   Panel update: write to dense column and udpate

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function etree_cholsolve_recur_d2(nodei)

global et;      %Elimination tree
global li;      %non-zero pattern
global L;       %Lower triangular factorization to update
global stn;     %Elimination tree's sub-tree nodes

%Post-order traversal
for i=et{nodei,1}
    etree_cholsolve_recur_d2(i)
end

%Left-looking cholesky factorization
%Load column nodei into a dense column
LdcM = size(li{nodei,1}, 1);                       %Non-zero rows in column
Ldc = zeros(LdcM, 1);
Ldc(: , 1) =  L( li{nodei,1} , nodei);

for i=stn{nodei,1}
   if isempty( find( li{i,1} == nodei ) ) == 0
        %row j appears in pattern of col i so update nodei
        %Load col i into dense column and perform blas1 update
        Ldc_i = zeros(LdcM, 1);
        Ldc_i(:, 1) =  L( li{nodei,1} , i);
        
        Ldc = Ldc - Ldc_i(1,1) * Ldc_i;
   end
end

%Update diagonal and divide
Ldc(1,1) = sqrt(Ldc(1,1));
Ldc(2:LdcM, 1) = Ldc(2:LdcM, 1) / Ldc(1,1);

%Write back to sparse format
L( li{nodei,1} , nodei) = Ldc;
