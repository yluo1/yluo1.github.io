%Run cholesky factorization test for various solvers
%Author: Yuancheng Luo, documentation: Yuancheng LUo

%Generate random SSPD 500x500 matrix
A = sprandsym(500, .1 , abs(rand(500,1)) );

%Run test 1 for verifying elimination tree based cholesky
etree_cholsolve_test(A, 500, .1, 1) ;

%Run test 2 for verifying supernodal elimination tree based cholesky
sn_cholsolve_test(A, 500, .1, .9, 1e-7, 3, 1) ;

%Run test 3 for timing purposes of naive, single tree, supernodal direct
%cholesky
direct_speedtests(A, 500, .1); 

%Run test 4 using preconditioning example under Ax=ones(m,1) under supernodal
%cholesky
precon_tests(A, 500, .1, .9); 

%Repeat tests 3,4 for structured matrix
load plbuckle; 
set(0, 'RecursionLimit', 1282); 
direct_speedtests(Problem.A, 1282, .1); 

precon_tests(Problem.A, 500, .1, .9); 