%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function etree_cholsolve_test(A, m, density,  ploton)
%Input:
%   A:          mxm sparse matrix: SPD square matrix, if A = [], then generate 
%                                  random mxm SPD matrix
%   m:          scalar:     Number of rows in matrix A
%   density:    scalar:     0 to 1 percent of non-zeros in random A
%   ploton:     scalar:     1 = display plots of factorization, 0 = not
%Output:
%   None
%
%Functionality:
%   For matrix A, run the direct cholesky algorithms (naive, elimination trees
%   elimination trees with dense panels) and comparing timings + residuals.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function etree_cholsolve_test(A, m, density,  ploton)

%if A is empty, generate random mxm SPD matrix
if isempty(A)
    A = sprandsym(m, density, abs(rand(m,1)) );
end

%Run tests
[L1 t1] = cholesky_naive(A);
[L2 t2] = etree_cholsolve(A, 1);
[L3 t3] = etree_cholsolve(A, 2);   
    

disp('Times [preordering, symbolic factorization, numerical factorization], totalTime');

disp('cholesky_naive:');
t1
sum(t1)
disp('etree_cholsolve 0: (without dense updates)');
t2
sum(t2)
disp('etree_cholsolve 1: (with dense updates)');
t3
sum(t3)

Lp = chol(A, 'lower');
    
%Residuals: Differences between A and reconstructed LL'
disp('norm2 residuals: chol, cholesky_naive, etree_cholsolve 0, etree_cholsolve 1');
norm(full(A-Lp*Lp'))
norm(full(A-L1*L1'))
norm(full(A-L2*L2'))
norm(full(A-L3*L3'))
    
    
%if plot is enabled, print from diagnostics
if ploton == 1
   
    figure; hold on;
    title('tril(A)');
    spy(tril(A));

    figure; hold on;
    title('L from built-in direct cholesky');
    spy(Lp);

    figure; hold on;
    title('L from naive cholesky');
    spy(L1);
    
    figure; hold on;
    title('L from etree cholesky');
    spy(L2);
    
    figure; hold on;
    title('L from etree cholesky with dense updates');
    spy(L3);



end