%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [p, li] = etreemod(A)
%Input:    
%   A:      MxM Sparse matrix 

%Output:
%   p:      Mx1 Vector of edge to parent in elimination tree
%           e.g. p(1) = 2 implies column 1 needs to be factorized before 2
%   li:     Mx1 Cell containing row-index vectors for each column the
%           non-zero (w/ fill-in) patterns in cholesky factorized L
%   stn:    Mx1 cell containing vectors of list of sub-tree nodes

%Functionality:
%   Compute column-wise elimination tree for matrix A for cholesky decomposition

%   References: [1] Adaptive Techniques for Improving the Performance of 
%                   Incomplete Factorization Preconditioning. Anshul Gupta
%                   and Thomas George,
%                   Feburary 8, 2010, SIAM.
%               [2] Efficient Sparse Cholesky Factorization. Jonathan Hogg.
%                   J.Hogg@ed.ac.uk. University of Edinburgh. August 13,
%                   2006.

%   Documentation:  Yuancheng Luo,          Author: Yuancheng Luo 5/2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [p, li, stn] = etreemod(A)

[M N] = size(A);

if M ~= N
    disp('Matrix A must have same dimensions');
    return
end

if ~issparse(A)
    disp('Matrix A must be sparse');
    return
end

p = zeros(M, 1);
li = cell(M, 1);
stn = cell(M, 1);

%Step through all columns of A
for i=1:M  
    nzCList = find(A(i:M,i))+i-1;   %Non-zero pattern of column i on/below diagonal
    
    pc = find(p == i);              %Find all prior columns that column i depends on
    pcM = size(pc,1);
    
    %Update nzCList
    for j=1:pcM
        nzCList = union(nzCList, li{pc(j),1});   %Returns union of patterns
        nzCList( find(nzCList == pc(j) ) ) = [];
    end
    li{i,1} = nzCList;
    
    nzCList = nzCList( find(nzCList ~= i) );
    if isempty(nzCList) == 0                    %pattern is non-empty
        p(i) = nzCList(1);
        stn{nzCList(1), 1} = union( union( stn{nzCList(1),1}, stn{i,1} ), i);
    end
    
end





