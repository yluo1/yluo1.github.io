function [x] = uniformPointsTriag(r, n, up)
%input r is radius of cell
%output x, y are point coordinates

if nargin < 1
    r = 1;
end

if nargin < 2
    n = 20000;
end

v1 = rand(1,n)*(r*sqrt(3)/2);
v2 = rand(1,n)*(r/2);
v3 = floor(rand(1,n)*3);        %Determine the rotation

%Convert to polar coordinates
R = sqrt(v1.^2 + v2.^2);
theta = atan(v1 ./ v2);
thetaThres = atan(sqrt(3));

part1 = find(theta <= thetaThres);
part2 = find(theta >= thetaThres);

%Translate part2
v2(part2) = v2(part2) - r/2;
v1(part2) = -(v1(part2) - r*sqrt(3)/2);
R(part2) = sqrt(v1(part2).^2 + v2(part2).^2);
theta(part2) = atan( v1(part2) ./ v2(part2) );

%Rotate part 1 and 2
thetaRot = zeros(1, n);

initRot = up * pi/6;

thetaRot(part1) = initRot + theta(part1) + 2*pi / 3 * v3(part1);
thetaRot(part2) = initRot + theta(part2) + 2*pi / 3 * v3(part2);

%Transform back to cartesian coords
x = [R .* cos(thetaRot) ; R .* sin(thetaRot)];

%Plot  points
% plot(x(1, part1),x(2, part1), 'ro', x(1, part2),x(2,part2), 'bo');
% pause;
