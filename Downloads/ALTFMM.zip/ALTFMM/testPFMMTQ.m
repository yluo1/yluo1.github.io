function [N, maxlvl, tdirect, tfmm, err] = testPFMMTQ(percOcc)
rand('seed',12345)

%Initialization
ppc = floor(FMM_Cell_2DTQ_Coulombic.p * 2.05); %points per cell
ppc = 20;

%Generate data for a set of triangular lattice points for the first __
%number of hexagonal cell centers on level __
maxlvl = FMM_Cell_2DTQ_Coulombic.maxlvl;
reps = FMM_Cell_2DTQ_Coulombic.reps;
ncells = reps ^ (maxlvl);
r = FMM_Cell_2DTQ_Coulombic.r;

x = [];
y = [];

occCells = randperm(floor(ncells * percOcc));
for i = occCells
    
    s = FMM_Cell_2DTQ_Coulombic.CellCenter(i-1, maxlvl);
    up = FMM_Cell_2DTQ_Coulombic.isUp(i-1, maxlvl);
    [xt] = uniformPointsTriag(r, ppc, up);
    [yt] = uniformPointsTriag(r, ppc, up);
    
    x = [x bsxfun(@plus, xt, s)];
    y = [y bsxfun(@plus, yt, s)];
end

N = size(x, 2)
u = rand(N, 1);
derr = 10^-6;

%Generate FMM cells and initial bookkeeping
[cellarray, xc, yc]  = FMM_Cell_2DTQ_Coulombic.gen(x, y);

cellarray

% figure;
% hold on;
% for i = 1 : maxlvl
%     cg = rand(1,3);
%     for j = 1:(reps^i)
%         plot(cellarray{i}(j).center(1), cellarray{i}(j).center(2), 'o', 'color', cg);
%     end
%     pause;
% end
% pause;
% plot(xc(1,:), xc(2, :), 'ro');
% pause;

tic
vdirect = FMM_Cell_2DTQ_Coulombic.direct2DCoulombic(xc, yc, u);
tdirect = toc

%Single-level FMM
% tic
% vslfmm = FMM_Cell_2DTQ_Coulombic.SLFMM(cellarray, xc, yc, u);
% toc
% err = max(max(abs(real(vdirect - vslfmm))))

%Multi-level FMM
tic
vslfmm = FMM_Cell_2DTQ_Coulombic.MLFMM(cellarray, xc, yc, u);
tfmm = toc
err = max(max(abs(real(vdirect - vslfmm))))