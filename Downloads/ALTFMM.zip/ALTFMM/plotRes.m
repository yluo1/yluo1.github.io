function plotRes

res = load('res0-chim.mat');

N = res.N;
err = res.err;
fmmtype = res.fmmtype;
maxlvl = res.maxlvl;
tdirect = res.tdirect;
tfmm = res.tfmm;

res = load('res1-chim.mat');

N = [N res.N];
err = [err res.err];
fmmtype = [fmmtype res.fmmtype];
maxlvl = [maxlvl res.maxlvl];
tdirect = [tdirect res.tdirect];
tfmm = [tfmm res.tfmm];

hcidx = find(fmmtype == 0);
stidx = find(fmmtype == 1);
tqidx = find(fmmtype == 2);

lvl5 = find(maxlvl == 5);
lvl4 = find(maxlvl == 4);
lvl3 = find(maxlvl == 3);

hclvl5 = intersect(hcidx, lvl5);
tqlvl5 = intersect(tqidx, lvl5);
stlvl4 = intersect(stidx, lvl4);

hclvl4 = intersect(hcidx, lvl4)
tqlvl4 = intersect(tqidx, lvl4)
stlvl3 = intersect(stidx, lvl3)

[Nsort, nsidx] = sort(N);
tdirsort = tdirect(nsidx);

figure;
hold on
plot(log10(N(hclvl5)), log10(tfmm(hclvl5)), 'b-*', log10(N(hclvl4)), log10(tfmm(hclvl4)), 'b-',  log10(N(stlvl4)), log10(tfmm(stlvl4)), 'm:*',  log10(N(stlvl3)), log10(tfmm(stlvl3)), 'm:', log10(N(tqlvl5)), log10(tfmm(tqlvl5)), 'r--*',  log10(N(tqlvl4)), log10(tfmm(tqlvl4)), 'r--',log10(Nsort), log10(tdirsort), 'g.-');
xlabel('log(N) and log(M) source and target points')
ylabel('log(Runtime (sec))') 
legend('Quadtree lvl5', 'Quadtree lvl4', 'Septree lvl4', 'Septree lvl3', 'Triangle Quadtree lvl5','Triangle Quadtree lvl4', 'Direct');
title('Runtime Results for MLFMM under p=12')


figure;
hold on
%plot(N(hclvl5), err(hclvl5), 'b-*', N(hclvl4), err(hclvl4), 'b-',  N(stlvl4), err(stlvl4), 'm:*',  N(stlvl3), err(stlvl3), 'm:', N(tqlvl5), err(tqlvl5), 'r--*',  N(tqlvl4), err(tqlvl4), 'r--');
plot(log10(N(hclvl5)), log10(err(hclvl5)), 'b-*', log10(N(hclvl4)), log10(err(hclvl4)), 'b-',  log10(N(stlvl4)), log10(err(stlvl4)), 'm:*',  log10(N(stlvl3)), log10(err(stlvl3)), 'm:', log10(N(tqlvl5)), log10(err(tqlvl5)), 'r--*',  log10(N(tqlvl4)), log10(err(tqlvl4)), 'r--');

xlabel('log(N) and log(M) source and target points')
ylabel('log(max(max(abs(err)))') 
legend('Quadtree lvl5', 'Quadtree lvl4', 'Septree lvl4', 'Septree lvl3', 'Triangle Quadtree lvl5','Triangle Quadtree lvl4');
title('log(max(max(abs(error)))) for MLFMM under p=12')


figure;
hold on
p = 10:2:18;
errhc = load('errphc.mat');
errst = load('errpst.mat');
errtq = load('errptq.mat');

plot(p, errhc.hctfmm, 'b-*',p, errst.sttfmm, 'r-*', p, errtq.tqtfmm, 'g-*');
xlabel('P truncation terms');
ylabel('Runtime (sec)');
legend('Quadtree lvl 4', 'Septree lvl 3', 'Triangle Quadtree lvl 4');
title('Runtime Results for MLFMM for N = 5120');

figure;
hold on
plot(p, log10(errhc.hcerr), 'b-*',p, log10(errst.sterr), 'r-*', p, log10(errtq.tqerr), 'g-*');
xlabel('P truncation terms');
ylabel('log10(max(max(abs(err)))') 
legend('Quadtree lvl 4', 'Septree lvl 3', 'Triangle Quadtree lvl 4');
title('log(max(max(abs(err)))) Results for MLFMM for N = 5120');

