%fmmtype = 0, 1, 2 for HC, ST, TQ
function [N, maxlvl, tdirect, tfmm, err] = testUniformFMM(fmmtype, percOcc)

if fmmtype == 0
    [N, maxlvl, tdirect, tfmm, err] = testUniformFMMHC(percOcc);
elseif fmmtype == 1
    [N, maxlvl, tdirect, tfmm, err] = testUniformFMMST(percOcc);
else
    [N, maxlvl, tdirect, tfmm, err] = testUniformFMMTQ(percOcc);
end


