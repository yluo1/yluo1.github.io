function [x] = uniformPointsSquare(r, n)
%input r is radius of cell
%output x, y are point coordinates

if nargin < 1
    r = 1;
end

if nargin < 2
    n = 20000;
end

x = (rand(2,n)-.5) * r * sqrt(2);

% %Plot  points
% plot(x(1, :),x(2, :), 'ro');
