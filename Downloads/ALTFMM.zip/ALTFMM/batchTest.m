function batchTest

tid = 1;

for fmmInt = 0:2
    for occInt = 1:1
        fmmtype(tid) = fmmInt;
        [N(tid), maxlvl(tid), tdirect(tid), tfmm(tid), err(tid)] = testUniformFMM(fmmInt,occInt/10);
        tid = tid + 1;
    end
end

save('res0.mat', 'fmmtype', 'N', 'maxlvl', 'tdirect', 'tfmm', 'err');