%FMM_Cell_2DRQ inherits from FMM_Cell
classdef FMM_Cell_2DTQ < FMM_Cell
	
    %Properties shared by all instances
    properties(Constant)
        d = 2;                          %Dimensions of cell
        reps = 4;                       %Number of self repeating elements on current level
        maxlvl = 4;                     %Lowest level of subdivision (constant for all cells)
        p = 18;                         %Number of expansion terms
        r = .125;                       %Temporary radius

        %sibling table
        %node,      left, right, vert
        sibtab = [  2   3   1;
                    -1  -1  0;
                    -1  0   -1;
                    0   -1  -1];
        
        %Reflection table
        %node,      left, right, vert
        reftab = [  2 3 1;
                    3 2 0;
                    1 0 2;
                    0 1 3];
    end
    
    %Instance methods
    methods
        %Constructor
        function obj = FMM_Cell_2DTQ(dxl, dxr, dyl, dyr, center)
            obj.dxl = dxl;
            obj.dxr = dxr;
            obj.dyl = dyl;
            obj.dyr = dyr;
            obj.center = center;
        end
    end
    
    
    %Tertiary methods
    methods(Static = true)
        
        
        %Convert axis components to uid
        function n = idxToUID(N)
            m = length(N);
            if m > 0
                n = 0;
            else
                n = [];
            end
            for i = 1:m
                n = n + N(m-i+1)*(4^(i-1));
            end 
        end
        
        %Convert uid to axis components
        function N = UIDToIdx(n)
            n4 = dec2base(n, 4);
            l = length(n4);
            N = zeros(1, l);
            for i = 1:l
                N(i) = str2num(n4(i));
            end
        end
        
        %Create bookmark structure from data
        function [cml,cmr, xc] = generateBookmarks(x)
            %x is row vector of n data points 
            %cml, cmr are bookmark{left, right} for data points xc
            %xc is rearranged data points in morton z cells in memory

            %cell cm is empty if either cml(bm) or cmr(bm) is not finite
            %cell contains all inclusive points between clm, cmr
            
            k = FMM_Cell_2DTQ.reps ^ FMM_Cell_2DTQ.maxlvl;
            
            cml = ones(k, 1)*inf;
            cmr = ones(k, 1)*-inf;
            n = length(x);          %n data points
            cmc = cell(k);          %cell for indexing points x in boxes
            
            for i = 1:n
                cm = FMM_Cell_2DTQ.CellIndex(x(:, i), FMM_Cell_2DTQ.maxlvl) + 1;
                cmc{cm} = [cmc{cm} i];
            end
            
            xc = zeros(FMM_Cell_2DTQ.d, n);
            xcl = 1;
            for i = 1:k
                sxc = size(cmc{i}, 2);
                if sxc > 0
                    cml(i) = xcl;
                    xc(:, xcl : (xcl + sxc - 1) ) = x(:, cmc{i});
                    xcl = xcl + sxc;
                    cmr(i) = xcl - 1;
                end
            end
        end
    end
    
    %Aux methods
    methods(Static = true)
        
        %Return 1 if up, -1 if down
        function up = isUp(n, l)
           N = FMM_Cell_2DTQ.UIDToIdx(n);
           up = 2 *(mod(mod(length(find(N == 0)),2) + l-length(N) +1, 2)) - 1;
        end
        
        %Return vector x that is center of cell n
        %Assume that l > maxlvl => l = maxlvl
        function s = CellCenter(n, l)
            maxlvl = FMM_Cell_2DTQ.maxlvl;
            dlvl = maxlvl - l;
            N = FMM_Cell_2DTQ.UIDToIdx(n);
            ln = length(N);
            s = zeros(FMM_Cell_2DTQ.d, 1);
            r = FMM_Cell_2DTQ.r;
            
            for i = 1:ln
                k = N(i);
                
%               up = FMM_Cell_2DTQ.isUp(bitshift(bitshift(n, -2*(ln-i)), 2*(ln-i)) ,l - ln + i );  
                up = FMM_Cell_2DTQ.isUp(bitshift(n, -2*(ln-i)) ,l - ln + i );
                
                if k > 0              
                    ii = ln - i + dlvl;
            
                    rt = r * 2^(ii);
                    theta = up*(pi/2 + (k-1)*2*pi/3);

                    s(1) = s(1) + rt * cos(theta);
                    s(2) = s(2) + rt * sin(theta);
                end
            end
        end
        
        %Return number of cells on a level
        function c = CCellsLvl(l)
            c = FMM_Cell_2DTQ.reps ^ l;
        end
        
        %Return all nonempty cells for x and y on level l (not optimized)
        function [ncx, ncy] = NonemptyCellsLvl(l, cellarray)
            ncx = [];
            ncy = [];
            ncs = FMM_Cell_2DTQ.CCellsLvl(l);
            for i = 1:ncs
                if isfinite(cellarray{l}(i).dxl)
                    ncx = [ncx i-1];
                end
                if isfinite(cellarray{l}(i).dyl)
                    ncy = [ncy i-1];
                end
            end
        end
        
        %Return all nonempty cells for x, y on level l given single cell c
        function [fx, fy] = isCellEmpty(c, l, cellarray)       
            fx = isfinite(cellarray{l}(c+1).dxl);
            fy = isfinite(cellarray{l}(c+1).dyl);
        end
        
        %Sweep though source x and receiver y points, generate cell array
        %of FMMCell_Hypercube variables
        function [cellarray, xc, yc] = gen(x, y)
            [csl,csr, xc] = FMM_Cell_2DTQ.generateBookmarks(x);
            [ctl,ctr, yc] = FMM_Cell_2DTQ.generateBookmarks(y);
        
            cellarray = cell(FMM_Cell_2DTQ.maxlvl, 1);
            for i = FMM_Cell_2DTQ.maxlvl : -1 : 1
                k = FMM_Cell_2DTQ.reps ^ i;
                for j = 1 : k
                    if i == FMM_Cell_2DTQ.maxlvl
                        cellarray{i}(1, j) = FMM_Cell_2DTQ(csl(j), csr(j), ctl(j), ctr(j), FMM_Cell_2DTQ.CellCenter(j-1, i));
                    else
                        Ch = FMM_Cell_2DTQ.Children(j-1) + 1;
                        dxl = inf;
                        dyl = inf;
                        dxr = -inf;
                        dyr = -inf;
                        for l = 1 : FMM_Cell_2DTQ.reps
                            dxl = min(dxl, cellarray{i+1}(1, Ch(l)).dxl);
                            dyl = min(dyl, cellarray{i+1}(1, Ch(l)).dyl);
                            dxr = max(dxr, cellarray{i+1}(1, Ch(l)).dxr);
                            dyr = max(dyr, cellarray{i+1}(1, Ch(l)).dyr);
                        end
                        cellarray{i}(1, j) = FMM_Cell_2DTQ(dxl, dxr, dyl, dyr, FMM_Cell_2DTQ.CellCenter(j-1, i));
                    end
                end
            end
        end
        
        %Return cell ID containing vector x at level l
        function n = CellIndex(x, l)
            
            maxlvl = FMM_Cell_2DTQ.maxlvl;
            r = FMM_Cell_2DTQ.r;
            
            up = 1;
            pv = [0; 0];
            N = zeros(l);
            for i = 1:l
                %For each lvl i, find corresponding nearest center
                %Generate center points
                pvs = pv;

                rt = r * 2^(maxlvl - i);
                for k = 1:3
                    if up == 1 %in upward triangle
                        theta = pi/2 + (k-1)*2*pi/3;
                    else %in inverted triangle
                        theta = -pi/2 - (k-1)*2*pi/3;
                    end
                    pvs = [pvs [pv(1) + rt * cos(theta); pv(2) + rt * sin(theta)] ];
                end

                %Find closest point in pvs
                res = bsxfun(@minus, pvs, x);
                [resmin, idx] = min(sum(res .^ 2, 1));

                pv = pvs(:, idx);
                N(i) = idx-1;

                if idx == 1
                    up = ~up;
                end
            end
            n = FMM_Cell_2DTQ.idxToUID(N);
        end
        
        %Return parent ID of cell n
        function m = Parent(n)
              m = floor(n/FMM_Cell_2DTQ.reps);
        end

        %Return cell IDs of childrens of n
        function Ch = Children(n)
            Ch = n*FMM_Cell_2DTQ.reps + [0 : (FMM_Cell_2DTQ.reps-1)];
        end

        %Return cell IDs of all siblings of n
        function Sb = Siblings(n)
            Sb = FMM_Cell_2DTQ.Children(FMM_Cell_2DTQ.Parent(n));    
        end
        
        %Return cell ID of neighbor in specified direction
        %dirc 1 = left, 2 = right, 3 = vert
        function NN = NeighborDir(N, l, dirc)
            stab = FMM_Cell_2DTQ.sibtab;
            rtab = FMM_Cell_2DTQ.reftab;
            ln = length(N);
            if ln > 0
                if ln < l
                   %Pad N with zeros
                   N = [zeros(1, l - ln), N];
                end
                NN = N;

                %Find child of nearest common ancestor in direction of dirc
                sibidx = stab(N+1, dirc)';
                ca = find(sibidx ~= -1, 1, 'last');

                if ~isempty(ca)
                    NN(ca : l) = [sibidx(ca) rtab(N(ca+1:end)+1, dirc)' ];
                else
                    NN = [];
                end
            else
                NN = [];
            end
            
        end
        
        %Return cell IDs of all neighbors of cell n on level l
        function Nei = Neighbors(n, l)
            reps = FMM_Cell_2DTQ.reps;
            N = FMM_Cell_2DTQ.UIDToIdx(n);
            
            L = FMM_Cell_2DTQ.NeighborDir(N, l, 1);
            R = FMM_Cell_2DTQ.NeighborDir(N, l, 2);
            V = FMM_Cell_2DTQ.NeighborDir(N, l, 3);
            LL = FMM_Cell_2DTQ.NeighborDir(L, l, 1);
            LV = FMM_Cell_2DTQ.NeighborDir(L, l, 3);
            RR = FMM_Cell_2DTQ.NeighborDir(R, l, 2);
            RV = FMM_Cell_2DTQ.NeighborDir(R, l, 3);
            VL = FMM_Cell_2DTQ.NeighborDir(V, l, 1);
            VR = FMM_Cell_2DTQ.NeighborDir(V, l, 2);
            LVR = FMM_Cell_2DTQ.NeighborDir(LV, l, 2);
            VLL = FMM_Cell_2DTQ.NeighborDir(VL, l, 1);
            VRR = FMM_Cell_2DTQ.NeighborDir(VR, l, 2);
            
            Nei = [FMM_Cell_2DTQ.idxToUID(L); 
                FMM_Cell_2DTQ.idxToUID(R);
                FMM_Cell_2DTQ.idxToUID(V);
                FMM_Cell_2DTQ.idxToUID(LL);
                FMM_Cell_2DTQ.idxToUID(LV);
                FMM_Cell_2DTQ.idxToUID(RR);
                FMM_Cell_2DTQ.idxToUID(RV);
                FMM_Cell_2DTQ.idxToUID(VL);
                FMM_Cell_2DTQ.idxToUID(VR);
                FMM_Cell_2DTQ.idxToUID(LVR);
                FMM_Cell_2DTQ.idxToUID(VLL);
                FMM_Cell_2DTQ.idxToUID(VRR)]';
                                  
            Nei = Nei(find(Nei < (reps^l)));
        end

        %Return cell IDs of all E4 neighbors of cell n on level l
        function NeiE4 = NeighborsE4(n, l)
            NeiC = [n FMM_Cell_2DTQ.Neighbors(n, l)];
            NeiP = [FMM_Cell_2DTQ.Parent(n) FMM_Cell_2DTQ.Neighbors(FMM_Cell_2DTQ.Parent(n), l-1)];
            NeiE4 = [];
            for i = NeiP
                NeiE4 = [NeiE4 setdiff(FMM_Cell_2DTQ.Children(i), NeiC)];
            end
        end

    end
    

end