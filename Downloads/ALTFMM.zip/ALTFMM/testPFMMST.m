function [N, maxlvl, tdirect, tfmm, err] = testPFMMST(percOcc)
rand('seed',12345)

%Initialization
ppc = floor(FMM_Cell_2DST_Coulombic.p * 2.7); %points per cell
ppc = 20;

%Generate data for a set of triangular lattice points for the first __
%number of hexagonal cell centers on level __
maxlvl = FMM_Cell_2DST_Coulombic.maxlvl;
reps = FMM_Cell_2DST_Coulombic.reps;
ncells = reps ^ (maxlvl);
r = FMM_Cell_2DST_Coulombic.r;

x = [];
y = [];

occCells = randperm(floor(ncells * percOcc));
for i = occCells
    s = FMM_Cell_2DST_Coulombic.CellCenter(i-1, maxlvl);
    [xt] = uniformPointsHex(r, ppc);
    [yt] = uniformPointsHex(r, ppc);
    
    x = [x bsxfun(@plus, xt, s)];
    y = [y bsxfun(@plus, yt, s)];
end

N = size(x, 2)
u = rand(N, 1);
derr = 10^-6;

%Generate FMM cells and initial bookkeeping
[cellarray, xc, yc]  = FMM_Cell_2DST_Coulombic.gen(x, y);

cellarray

tic
vdirect = FMM_Cell_2DST_Coulombic.direct2DCoulombic(xc, yc, u);
tdirect = toc

%Single-level FMM
% tic
% vslfmm = FMM_Cell_2DST_Coulombic.SLFMM(cellarray, xc, yc, u);
% toc
% err = max(max(abs(real(vdirect - vslfmm))))

%Multi-level FMM
tic
vslfmm = FMM_Cell_2DST_Coulombic.MLFMM(cellarray, xc, yc, u);
tfmm = toc
err = max(max(abs(real(vdirect - vslfmm))))