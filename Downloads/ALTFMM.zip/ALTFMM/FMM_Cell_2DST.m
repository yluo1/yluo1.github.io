%FMM_Cell_2DST inherits from FMM_Cell
classdef FMM_Cell_2DST < FMM_Cell
	
    %Properties shared by all instances
    properties(Constant)
        d = 2;                          %Dimensions of cell
        reps = 7;                       %Number of self repeating elements on current level
        maxlvl = 3;                     %Lowest level of subdivision (constant for all cells)
        p = 10;                         %Number of expansion terms
        r = .125;                       %Temporary radius
        
        %Number of cells needed along axis
        %axisK = (3^(FMM_Cell_2DST.maxlvl+1) + 2 * FMM_Cell_2DST.maxlvl + 1)/4;  %Incorrect formula also
        axisK = 40;
        
        %Unit vector addition
        tab = {    0	1	2	3	4	5	6;
                   1	fliplr([6 3])	fliplr([1 5])	2	0	6	fliplr([6 4]);
                   2	fliplr([1 5])	fliplr([1 4])	fliplr([2 6])	3	0	1;
                   3	2	fliplr([2 6])	fliplr([2 5])	fliplr([3 1])	4	0;
                   4	0	3	fliplr([3 1])	fliplr([3 6])	fliplr([4 2])	5;
                   5	6	0	4	fliplr([4 2])	fliplr([4 1])	fliplr([5 3]);
                   6	fliplr([6 4])	1	0	5	fliplr([5 3])	fliplr([5 2]);};   
            
        %Axis indices
        bpos = FMM_Cell_2DST.initAxis(1);
        bneg = FMM_Cell_2DST.initAxis(4);
        cpos = FMM_Cell_2DST.initAxis(2);
        cneg = FMM_Cell_2DST.initAxis(5);
        
    end
    
    %Instance methods
    methods
        %Constructor
        function obj = FMM_Cell_2DST(dxl, dxr, dyl, dyr, center)
            obj.dxl = dxl;
            obj.dxr = dxr;
            obj.dyl = dyl;
            obj.dyr = dyr;
            obj.center = center;
        end
    end
    
    %Class initialization methods
    methods(Static = true)
        function ax = initAxis(v)
            ax = {[v]};
            tab = FMM_Cell_2DST.tab;
            k = FMM_Cell_2DST.axisK;
            for i = 2:k
                ax{i} = fliplr(FMM_Cell_2DST.addGBT(fliplr(ax{i-1}), fliplr([v]), [], tab));
            end
        end
    end
    
    %Tertiary methods
    methods(Static = true)
        
        %GBT addition of a, b with carry c
        function n = addGBT(a, b, c, tab)
            la = length(a);
            lb = length(b);
            lmax = max(la, lb);
            n = [];

            if la == 1 && lb == 1
                n = tab{a+1, b+1};
            else
                for i = 1 : lmax;
                    %Let t = c + ai
                    if ~isempty(c) %carry exists
                        if la >= i %a(i) exists
                            t = FMM_Cell_2DST.addGBT(a(i), c, [], tab);
                        else
                            t = c;
                        end
                    else %carry doesnot exist
                        if la >= i
                            t = a(i);
                        else
                            t = [];
                        end
                    end

                    %Let d = t + bi
                    if ~isempty(t) %t exists
                        if lb >= i %b(i) exists
                            d = FMM_Cell_2DST.addGBT(t, b(i), [], tab);
                        else
                            d = t;
                        end
                    else %neither carry nor a(i) exist
                        if lb >= i
                            d = b(i);
                        end
                    end
                    
                    n = [n, d(1)];                    
                    if length(d) > 1
                        c = d(2:end);
                    else
                        c = [];
                    end
   
                    %Last digit, add whatever carry we have to n
                    if i == lmax
                        n = [n, c];
                    end
                end
            end
        end
        
        %Convert axis components to uid
        function n = idxToUID(N)
            m = length(N);
            n = 0;
            for i = 1:m
                n = n + N(m-i+1)*(7^(i-1));
            end 
        end
        
        %Convert uid to axis components
        function N = UIDToIdx(n)
            n7 = dec2base(n, 7);
            l = length(n7);
            N = zeros(1, l);
            for i = 1:l
                N(i) = str2num(n7(i));
            end
        end
        
        %Create bookmark structure from data
        function [cml,cmr, xc] = generateBookmarks(x)
            %x is row vector of n data points 
            %cml, cmr are bookmark{left, right} for data points xc
            %xc is rearranged data points in morton z cells in memory

            %cell cm is empty if either cml(bm) or cmr(bm) is not finite
            %cell contains all inclusive points between clm, cmr
            
            k = FMM_Cell_2DST.reps ^ FMM_Cell_2DST.maxlvl;
            
            cml = ones(k, 1)*inf;
            cmr = ones(k, 1)*-inf;
            n = length(x);          %n data points
            cmc = cell(k);          %cell for indexing points x in boxes
            
            for i = 1:n
                cm = FMM_Cell_2DST.CellIndex(x(:, i), FMM_Cell_2DST.maxlvl) + 1;
                cmc{cm} = [cmc{cm} i];
            end
            
            xc = zeros(FMM_Cell_2DST.d, n);
            xcl = 1;
            for i = 1:k
                sxc = size(cmc{i}, 2);
                if sxc > 0
                    cml(i) = xcl;
                    xc(:, xcl : (xcl + sxc - 1) ) = x(:, cmc{i});
                    xcl = xcl + sxc;
                    cmr(i) = xcl - 1;
                end
            end
        end
    end
    
    %Aux methods
    methods(Static = true)
        
        %Return vector x that is center of cell n
        %Assume that l > maxlvl => l = maxlvl
        function s = CellCenter(n, l)
            dlvl = FMM_Cell_2DST.maxlvl - l;
            N = FMM_Cell_2DST.UIDToIdx(n);
            ln = length(N);
            s = zeros(FMM_Cell_2DST.d, 1);
            r = FMM_Cell_2DST.r;
            for i = 1:ln
                if N(i) ~=0
                    ii = ln-i+dlvl;
                    theta = ii * atan(sqrt(3)/2) + N(i)*(pi/3) - pi/6;
                    R = r * sqrt(3) * sqrt(7)^ii;
                    s(1) = s(1) + R*cos(theta);
                    s(2) = s(2) + R*sin(theta);
                end
            end
        end
        
        %Return number of cells on a level
        function c = CCellsLvl(l)
            c = FMM_Cell_2DST.reps ^ l;
        end
        
        %Return all nonempty cells for x and y on level l (not optimized)
        function [ncx, ncy] = NonemptyCellsLvl(l, cellarray)
            ncx = [];
            ncy = [];
            ncs = FMM_Cell_2DST.CCellsLvl(l);
            for i = 1:ncs
                if isfinite(cellarray{l}(i).dxl)
                    ncx = [ncx i-1];
                end
                if isfinite(cellarray{l}(i).dyl)
                    ncy = [ncy i-1];
                end
            end
        end
        
        %Return all nonempty cells for x, y on level l given single cell c
        function [fx, fy] = isCellEmpty(c, l, cellarray)       
            fx = isfinite(cellarray{l}(c+1).dxl);
            fy = isfinite(cellarray{l}(c+1).dyl);
        end
        
        %Sweep though source x and receiver y points, generate cell array
        %of FMMCell_Hypercube variables
        function [cellarray, xc, yc] = gen(x, y)
            [csl,csr, xc] = FMM_Cell_2DST.generateBookmarks(x);
            [ctl,ctr, yc] = FMM_Cell_2DST.generateBookmarks(y);
        
            cellarray = cell(FMM_Cell_2DST.maxlvl, 1);
            for i = FMM_Cell_2DST.maxlvl : -1 : 1
                k = FMM_Cell_2DST.reps ^ i;
                for j = 1 : k
                    if i == FMM_Cell_2DST.maxlvl
                        cellarray{i}(1, j) = FMM_Cell_2DST(csl(j), csr(j), ctl(j), ctr(j), FMM_Cell_2DST.CellCenter(j-1, i));
                    else
                        Ch = FMM_Cell_2DST.Children(j-1) + 1;
                        dxl = inf;
                        dyl = inf;
                        dxr = -inf;
                        dyr = -inf;
                        for l = 1 : FMM_Cell_2DST.reps
                            dxl = min(dxl, cellarray{i+1}(1, Ch(l)).dxl);
                            dyl = min(dyl, cellarray{i+1}(1, Ch(l)).dyl);
                            dxr = max(dxr, cellarray{i+1}(1, Ch(l)).dxr);
                            dyr = max(dyr, cellarray{i+1}(1, Ch(l)).dyr);
                        end
                        cellarray{i}(1, j) = FMM_Cell_2DST(dxl, dxr, dyl, dyr, FMM_Cell_2DST.CellCenter(j-1, i));
                    end
                end
            end
        end
        
        %Return cell ID containing vector x at level l
        function n = CellIndex(x, l)

            r = FMM_Cell_2DST.r;
            
            %Compute approximate axis components of x,y
            b = 2*x(1) / (3*r);
            c = (x(2) * sqrt(3) - x(1)) / (3*r);
            
            %Define potential lattice points
            fb = floor(b);
            cb = ceil(b);
            fc = floor(c);
            cc = ceil(c);
                
            lx = zeros(8, 1);
            lx(1:2) = [3*r*fb / 2; r*sqrt(3) * (2*fc + fb)/2]; %ff
            lx(3:4)  = [3*r*fb / 2; r*sqrt(3) * (2*cc + fb)/2]; %fc
            lx(5:6)  = [3*r*cb / 2; r*sqrt(3) * (2*fc + cb)/2]; %cf
            lx(7:8)  = [3*r*cb / 2; r*sqrt(3) * (2*cc + cb)/2]; %cc
            
            %Find nearest neighbor lattice point
            nn = [sum((lx(1:2) - x).^2, 1) ; sum((lx(3:4)- x).^2, 1) ; sum((lx(5:6) - x).^2, 1) ; sum((lx(7:8) - x).^2, 1)];

            [mm, idx] = min(nn);

            lxf = lx(((idx-1)*2 + 1):((idx-1)*2 + 2));
            
            %Determine axis components
            bf = 2*lxf(1,:) / (3*r);
            cf = (lxf(2,:) * sqrt(3) - lxf(1,:)) / (3*r);

            bf = round(bf);
            cf = round(cf);
            
            %Determine cell indices of axis components 
            if bf > 0
               bc = FMM_Cell_2DST.bpos{bf};
            elseif bf < 0
               bc = FMM_Cell_2DST.bneg{-bf};
            else
               bc = 0;
            end
            if cf > 0
               cc = FMM_Cell_2DST.cpos{cf};
            elseif cf < 0
               cc = FMM_Cell_2DST.cneg{-cf};
            else
               cc = 0;
            end
            
            %GBT add components and truncate to level l
            t = fliplr(FMM_Cell_2DST.addGBT(fliplr(bc), fliplr(cc), [], FMM_Cell_2DST.tab));   
            
            t = FMM_Cell_2DST.idxToUID(t);
            t = FMM_Cell_2DST.UIDToIdx(t);

            mt = min(length(t), l);            
            n = FMM_Cell_2DST.idxToUID(t(1:mt));

        end
        
        %Return parent ID of cell n
        function m = Parent(n)
              m = floor(n/FMM_Cell_2DST.reps);
        end

        %Return cell IDs of childrens of n
        function Ch = Children(n)
            Ch = n*FMM_Cell_2DST.reps + [0 : (FMM_Cell_2DST.reps-1)];
        end

        %Return cell IDs of all siblings of n
        function Sb = Siblings(n)
            Sb = FMM_Cell_2DST.Children(FMM_Cell_2DST.Parent(n));    
        end

        %Return cell IDs of all neighbors of cell n on level l
        function Nei = Neighbors(n, l)
            reps = FMM_Cell_2DST.reps;
            N = FMM_Cell_2DST.UIDToIdx(n);
            %Ternary addition
            Nei = zeros(1, 6);
            tab = FMM_Cell_2DST.tab;
            for i = 1:6
                nei = fliplr(FMM_Cell_2DST.addGBT(fliplr(N), fliplr([i]), [], tab));
                Nei(i) = FMM_Cell_2DST.idxToUID(nei);
            end
            Nei = Nei(find(Nei < (reps^l)));
        end

        %Return cell IDs of all E4 neighbors of cell n on level l
        function NeiE4 = NeighborsE4(n, l)
            NeiC = [n FMM_Cell_2DST.Neighbors(n, l)];
            NeiP = [FMM_Cell_2DST.Parent(n) FMM_Cell_2DST.Neighbors(FMM_Cell_2DST.Parent(n), l-1)];
            NeiE4 = [];
            for i = NeiP
                NeiE4 = [NeiE4 setdiff(FMM_Cell_2DST.Children(i), NeiC)];
            end
        end

    end
    

end