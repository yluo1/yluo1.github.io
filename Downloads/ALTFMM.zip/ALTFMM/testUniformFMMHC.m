function [N, maxlvl, tdirect, tfmm, err] = testUniformFMMHC(percOcc)
rand('seed',12345)

%Initialization
ppc = floor(FMM_Cell_HC_2DCoulombic.p * 2.07); %points per cell

%Generate data for a set of triangular lattice points for the first __
%number of hexagonal cell centers on level __
maxlvl = FMM_Cell_HC_2DCoulombic.maxlvl;
reps = FMM_Cell_HC_2DCoulombic.reps;
ncells = reps ^ (maxlvl);

r = FMM_Cell_HC_2DCoulombic.CellSize(maxlvl) * sqrt(2)/2;

x = [];
y = [];

occCells = randperm(floor(ncells * percOcc));

for i = occCells
    s = FMM_Cell_HC_2DCoulombic.CellCenter(i-1, maxlvl);
    [xt] = uniformPointsSquare(r, ppc);
    [yt] = uniformPointsSquare(r, ppc);
    
    x = [x bsxfun(@plus, xt, s)];
    y = [y bsxfun(@plus, yt, s)];
end


N = size(x, 2)
u = rand(N, 1);
derr = 10^-6;

%Generate FMM cells and initial bookkeeping
[cellarray, xc, yc]  = FMM_Cell_HC_2DCoulombic.gen(x, y);

cellarray

tic
vdirect = FMM_Cell_HC_2DCoulombic.direct2DCoulombic(xc, yc, u);
tdirect = toc

%Single-level FMM
% tic
% vslfmm = FMM_Cell_HC_2DCoulombic.SLFMM(cellarray, xc, yc, u);
% toc
% err = max(max(abs(real(vdirect - vslfmm))))

%Multi-level FMM
tic
vslfmm = FMM_Cell_HC_2DCoulombic.MLFMM(cellarray, xc, yc, u);
tfmm = toc
err = max(max(abs(real(vdirect - vslfmm))))