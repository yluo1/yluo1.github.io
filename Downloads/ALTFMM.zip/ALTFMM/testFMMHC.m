function testFMMHC
rand('seed',12345)

%Initialization
N = 1000;
M = N;

%Generate data
x = rand(FMM_Cell_HC.d, N);
y = rand(FMM_Cell_HC.d, M);
u = rand(N, 1);
derr = 10^-6;

%Generate FMM cells and initial bookkeeping
[cellarray, xc, yc]  = FMM_Cell_HC_2DCoulombic.gen(x, y);

cellarray
% cellarray{1}(1)

tic
vdirect = FMM_Cell_HC_2DCoulombic.direct2DCoulombic(xc, yc, u);
toc

% tic
% vslfmm = FMM_Cell_HC_2DCoulombic.SLFMM(cellarray, xc, yc, u);
% toc
% err = max(max(abs(real(vdirect - vslfmm))))

tic
vslfmm = FMM_Cell_HC_2DCoulombic.MLFMM(cellarray, xc, yc, u);
toc
err = max(max(abs(real(vdirect - vslfmm))))
