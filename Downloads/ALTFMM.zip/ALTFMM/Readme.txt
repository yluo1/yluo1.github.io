Multi-level fast multipole methods via alternative tilings of point geometry (Triangle, Hexagonal):
See test*.m for examples.