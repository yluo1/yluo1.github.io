classdef FMM_Cell_2DTQ_Coulombic < FMM_Cell_2DTQ
       
    
	%Direct method
    methods(Static = true)
        function v = direct2DCoulombic(x, y, u)
            d = FMM_Cell_2DTQ_Coulombic.d;
            if size(x, 1) ~= d || size(y, 1) ~= 2
                error('x or y not d x N');
            elseif d ~= 2
                error('2D Columbic requires FMM_Cell_2DST.d = 2');
            end
            
            N = size(x, 2);
            M = size(y, 2);
            v = zeros(M, 1);
            for j  = 1 : M
                cy = complex(y(1, j), y(2, j));
                for i = 1 : N
                    cx = complex(x(1, i), x(2, i));
                    v(j) = v(j) + log(cy - cx) * u(i);
                end
            end
        end
    end
    
    %Translation and expansion methods
    methods(Static = true)
        
        %Single-level FMM
        function v = SLFMM(cellarray, xc, yc, u)
            M = size(yc, 2);
            v = zeros(M, 1);

            maxlvl = FMM_Cell_2DTQ_Coulombic.maxlvl;
            p = FMM_Cell_2DTQ_Coulombic.p;
            k = FMM_Cell_2DTQ_Coulombic.CCellsLvl(maxlvl);
            %S-Expansion coefficients
            sc = zeros(p, k, maxlvl);
            %R-Expansion coefficients
            rc = zeros(p, k, maxlvl);
            
            %Precompute factorials
            fact = zeros(2*p, 1);
            for i = 0 : (2*p)
                fact(i+1) = factorial(i);
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Upward pass
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            lvl = maxlvl;
            %Do S-Expansion
            [ncx, ncy] = FMM_Cell_2DTQ_Coulombic.NonemptyCellsLvl(lvl, cellarray);            
            for bs = ncx %For each source cell, compute S expansion coefficients
                a = FMM_Cell_2DTQ_Coulombic.CellCenter(bs, lvl); %Expansion center
                for l = 0 : (p-1) %Iterate across all powers upto p-1
                    for i = cellarray{lvl}(bs+1).dxl : cellarray{lvl}(bs+1).dxr
                        if l == 0
                            sc(l+1, bs+1, lvl) = sc(l+1, bs+1, lvl) + 1 * u(i); %Expansion coefficients
                        else
                            sc(l+1, bs+1, lvl) = sc(l+1, bs+1, lvl) - (complex(xc(1, i) - a(1), xc(2,i) - a(2))^l)/l * u(i); %Expansion coefficients
                        end
                    end
                end
            end
               
            %Do S|R translation
            [ncx, ncy] = FMM_Cell_2DTQ_Coulombic.NonemptyCellsLvl(lvl, cellarray);
            for bt =  ncy
                at = FMM_Cell_2DTQ_Coulombic.CellCenter(bt, lvl); %Expansion center
                Ne = [bt FMM_Cell_2DTQ_Coulombic.Neighbors(bt, lvl)];
                Nen = setdiff(ncx, Ne);
                for bs = Nen
                    as = FMM_Cell_2DTQ_Coulombic.CellCenter(bs, lvl);
                    t = complex(at(1) - as(1), at(2) - as(2));
                    sr = zeros(p, p);

                    sr(1, 1) = log(t);
                    for l = 1 : (p-1)
                        sr(1, l+1) = t^-l;
                    end
                    for m = 1 : (p-1)
                        sr(m+1, 1) = -1/(m * (-t)^m);
                        for l = 1 : (p-1)
                            sr(m+1, l+1) = (-1)^m * (t)^(-m -l) * fact(m + l -1 + 1) / (fact(l-1 + 1) * fact(m + 1) );
                        end
                    end
                    rc(:, bt+1, lvl) = rc(:, bt+1, lvl) + sr * sc(:, bs+1, lvl);  
                end
            end

            %R-expansions
            for bt = ncy
                a = FMM_Cell_2DTQ_Coulombic.CellCenter(bt, lvl); %Expansion center

                for j = cellarray{lvl}(bt+1).dyl : cellarray{lvl}(bt+1).dyr %Iterate across all target points in box bt
                    for l = 0 : (p-1) %Iterate across terms
                        if l == 0
                            v(j) = v(j) + 1 * rc(l+1, bt+1, lvl);
                        else
                            v(j) = v(j) + (complex(yc(1, j) - a(1) ,yc(2, j) - a(2)) ^ l) * rc(l+1, bt+1, lvl);
                        end
                    end
                end

                %Directly process source points in target box bt and neighbors
                Ne = [bt FMM_Cell_2DTQ_Coulombic.Neighbors(bt, lvl)];
                for bs = Ne
                    for j =  cellarray{lvl}(bt+1).dyl : cellarray{lvl}(bt+1).dyr    
                        for i = cellarray{lvl}(bs+1).dxl : cellarray{lvl}(bs+1).dxr
                            v(j) = v(j) + log(complex(yc(1,j) - xc(1,i), yc(2,j) - xc(2,i))) * u(i);
                        end
                    end
                end   
            end

        end
         
        %Multi-level FMM
        function v = MLFMM(cellarray, xc, yc, u)
            M = size(yc, 2);
            v = zeros(M, 1);

            maxlvl = FMM_Cell_2DTQ_Coulombic.maxlvl;
            p = FMM_Cell_2DTQ_Coulombic.p;
            k = FMM_Cell_2DTQ_Coulombic.CCellsLvl(maxlvl);
            %S-Expansion coefficients
            sc = zeros(p, k, maxlvl);
            %R-Expansion coefficients
            rc = zeros(p, k, maxlvl);
            
            %Precompute factorials
            fact = zeros(2*p, 1);
            for i = 0 : (2*p)
                fact(i+1) = factorial(i);
            end

            %Timing 
            uptimes = 0;
            srtimes = 0;
            rrtimes = 0;
            rexptimes = 0;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Upward pass
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%             tic
            for lvl = maxlvl : -1 : 1
                [ncx, ncy] = FMM_Cell_2DTQ_Coulombic.NonemptyCellsLvl(lvl, cellarray);       
                if lvl == maxlvl %Do S-Expansion      
                    for bs = ncx %For each source cell, compute S expansion coefficients
                        %a = FMM_Cell_2DTQ_Coulombic.CellCenter(bs, lvl); %Expansion center
                        a = cellarray{lvl}(bs+1).center;
                        for l = 0 : (p-1) %Iterate across all powers upto p-1
                            for i = cellarray{lvl}(bs+1).dxl : cellarray{lvl}(bs+1).dxr
                                if l == 0
                                    sc(l+1, bs+1, lvl) = sc(l+1, bs+1, lvl) + 1 * u(i); %Expansion coefficients
                                else
                                    sc(l+1, bs+1, lvl) = sc(l+1, bs+1, lvl) - (complex(xc(1, i) - a(1), xc(2,i) - a(2))^l)/l * u(i); %Expansion coefficients
                                end
                            end
                        end
                    end
                else %Do S|S Translation
                    for bs = ncx %Iterate across all source boxes
                        %Iterate across all children of souce box
                        ncxc = FMM_Cell_2DTQ_Coulombic.Children(bs);
                        %at = FMM_Cell_2DTQ_Coulombic.CellCenter(bs, lvl);
                        at = cellarray{lvl}(bs+1).center;
                        for bsc = ncxc
                             %as = FMM_Cell_2DTQ_Coulombic.CellCenter(bsc, lvl+1);
                             as = cellarray{lvl+1}(bsc+1).center;
                             t = complex(at(1) - as(1), at(2) - as(2));
                             ss = zeros(p, p);
                             ss(1, 1) = 1;
                             for m = 1 : (p-1)
                                ss(m+1, 1) = -(-t)^m / m;
                                for l = 1 : m
                                    ss(m+1, l+1) = (-t)^(m-l) * fact(m - 1 +1) / (fact(m-l-1 +1 + 1) * fact(l-1 + 1) );
                                end
                             end
                             sc(:, bs+1, lvl) =  sc(:, bs+1, lvl) + ss * sc(:, bsc+1, lvl+1);
                        end
                    end
                end
            end
%             uptimes = uptimes + toc;

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Downward pass
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for lvl = 1 : maxlvl
%                 tic
                %Do S|R translation
                [ncx, ncy] = FMM_Cell_2DTQ_Coulombic.NonemptyCellsLvl(lvl, cellarray);
                for bt =  ncy
                	%at = FMM_Cell_2DTQ_Coulombic.CellCenter(bt, lvl); %Expansion center
                    at = cellarray{lvl}(bt+1).center;
                    NeiE4 = FMM_Cell_2DTQ_Coulombic.NeighborsE4(bt, lvl);
        
                    for bs = NeiE4
                        %as = FMM_Cell_2DTQ_Coulombic.CellCenter(bs, lvl);
                        as = cellarray{lvl}(bs+1).center;
                       
                        t = complex(at(1) - as(1), at(2) - as(2));
                        sr = zeros(p, p);

                        sr(1, 1) = log(t);
                        for l = 1 : (p-1)
                            sr(1, l+1) = t^-l;
                        end
                        for m = 1 : (p-1)
                            sr(m+1, 1) = -1/(m * (-t)^m);
                            for l = 1 : (p-1)
                                sr(m+1, l+1) = (-1)^m * (t)^(-m -l) * fact(m + l -1 + 1) / (fact(l-1 + 1) * fact(m + 1) );
                            end
                        end
                        rc(:, bt+1, lvl) = rc(:, bt+1, lvl) + sr * sc(:, bs+1, lvl);  
                    end
                end
%                 srtimes = srtimes + toc;
                
                if lvl == maxlvl %R-expansions
%                     tic
                    for bt = ncy
                        %a = FMM_Cell_2DTQ_Coulombic.CellCenter(bt, lvl); %Expansion center
                        a = cellarray{lvl}(bt+1).center;
                        for j = cellarray{lvl}(bt+1).dyl : cellarray{lvl}(bt+1).dyr %Iterate across all target points in box bt
                            for l = 0 : (p-1) %Iterate across terms
                                if l == 0
                                    v(j) = v(j) + 1 * rc(l+1, bt+1, lvl);
                                else
                                    v(j) = v(j) + (complex(yc(1, j) - a(1) ,yc(2, j) - a(2)) ^ l) * rc(l+1, bt+1, lvl);
                                end
                            end
                        end
                        
                        %Directly process source points in target box bt and neighbors
                        Ne = [bt FMM_Cell_2DTQ_Coulombic.Neighbors(bt, lvl)];
                        for bs = Ne
                            for j =  cellarray{lvl}(bt+1).dyl : cellarray{lvl}(bt+1).dyr
                                for i = cellarray{lvl}(bs+1).dxl : cellarray{lvl}(bs+1).dxr
                                    v(j) = v(j) + log(complex(yc(1,j) - xc(1,i), yc(2,j) - xc(2,i))) * u(i);
                                end
                            end
                        end   
                    end
%                     rexptimes = rexptimes + toc;
                else  %Do R|R Translation
%                     tic
                    for bt = ncy %Iterate across all target boxes
                        %Iterate across all children of target box
                        ncyc = FMM_Cell_2DTQ_Coulombic.Children(bt);
                        %as = FMM_Cell_2DTQ_Coulombic.CellCenter(bt, lvl);
                        as = cellarray{lvl}(bt+1).center;
                        for btc = ncyc
                            %at = FMM_Cell_2DTQ_Coulombic.CellCenter(btc, lvl+1); %Expansion center
                            at = cellarray{lvl+1}(btc+1).center;
                            t = complex(at(1) - as(1), at(2) - as(2));
                            rr = zeros(p, p);
                            for m = 0 : (p-1)
                                for l = m : (p-1) %Iterate across all powers upto p-1
                                    rr(m+1, l+1) =  fact(l+1) / (fact(m+1) * fact(l-m+1)) * t^(l-m);
                                end
                            end
                            rc(:, btc+1, lvl+1) =  rr * rc(:, bt+1, lvl);
                        end
                    end
%                     rrtimes = rrtimes + toc;
                end
            end
  
%             uptimes
%             rrtimes
%             srtimes
%             rexptimes
            
        end
        
    end
    
    
end