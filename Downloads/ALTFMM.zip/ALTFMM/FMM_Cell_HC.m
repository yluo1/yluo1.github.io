%FMM_Cell_HC inherits from FMM_Cell
classdef FMM_Cell_HC < FMM_Cell
	
    %Properties shared by all instances
    properties(Constant)
        d = 2;                          %Dimensions of cell
        reps = 2^FMM_Cell_HC.d;         %Number of self repeating elements on current level
        maxlvl = 4;                     %Lowest level of subdivision (constant for all cells)
        p = 18;                         %Number of expansion terms
    end
    
    %Instance methods
    methods
        %Constructor
        function obj = FMM_Cell_HC(dxl, dxr, dyl, dyr, center)
            obj.dxl = dxl;
            obj.dxr = dxr;
            obj.dyl = dyl;
            obj.dyr = dyr;
            obj.center = center;
        end
    end
    
    %Tertiary methods
    methods(Static = true)
        
        %Interleave d-dimensional vector N to return cell ID n
        function n = Interleave(N)
            n = 0;
            d = FMM_Cell_HC.d;
            for i = 0 : 31
                n = bitset(n, i+1, bitget(N(d-mod(i, d)), floor(i/d)+1 ) );
            end
        end
        
        %Deinterleave cell ID n to return d-dimensional vector N
        function N = Deinterleave(n)
            d = FMM_Cell_HC.d;
            N = zeros(d, 1);
            for i = 0:31
                N(d-mod(i,d)) = bitset(N(d-mod(i,d)), floor(i/d)+1, bitget(n, i+1)); 
            end
        end

        %Recursive Neighbors helper function
        function n = NeighborsR(N, c)
            if c <= FMM_Cell_HC.d
                n = [];
                Nt = N;
                for t = -1:1
                    Nt(c) = N(c) + t;
                    if Nt(c) >= 0
                        n = [n FMM_Cell_HC.NeighborsR(Nt, c+1)];
                    end
                end
            else
                n = FMM_Cell_HC.Interleave(N);
            end
        end
        
        %Unrolled Neighbors helper function
        function n = NeighborsU(N)
            d = FMM_Cell_HC.d;
            n = [];
            NN = N;
            k = 3^d;
            t = [0 -1 1];
            for i = 1:k
                for j = 1:d
                    tj = 1 + mod(floor(i/(3^(j-1))), 3);
                    NN(j) = N(j) + t(tj); 
                end

                if isempty(find(NN < 0))                    
                    n = [n  FMM_Cell_HC.Interleave(NN)];
                end
            end
            
        end
        
        %Create bookmark structure from data
        function [cml,cmr, xc] = generateBookmarks(x)
            %x is row vector of n data points 
            %cml, cmr are bookmark{left, right} for data points xc
            %xc is rearranged data points in morton z cells in memory

            %cell cm is empty if either cml(bm) or cmr(bm) is not finite
            %cell contains all inclusive points between clm, cmr
            
            k = FMM_Cell_HC.reps ^ FMM_Cell_HC.maxlvl;
            
            cml = ones(k, 1)*inf;
            cmr = ones(k, 1)*-inf;
            n = length(x);          %n data points
            cmc = cell(k);          %cell for indexing points x in boxes
            
            for i = 1:n
                cm = FMM_Cell_HC.CellIndex(x(:, i), FMM_Cell_HC.maxlvl) + 1;
                cmc{cm} = [cmc{cm} i];
            end
            
            xc = zeros(FMM_Cell_HC.d, n);
            xcl = 1;
            for i = 1:k
                sxc = size(cmc{i}, 2);
                if sxc > 0
                    cml(i) = xcl;
                    xc(:, xcl : (xcl + sxc - 1) ) = x(:, cmc{i});
                    xcl = xcl + sxc;
                    cmr(i) = xcl - 1;
                end
            end
        end
    
    end
    
    %Aux methods
    methods(Static = true)
        %Return size s of box at level l
        function s = CellSize(l)
            s = 2^-l;
        end
        
        %Return vector x that is center of cell n in unit cube
        function s = CellCenter(n, l)
            N = FMM_Cell_HC.Deinterleave(n);
            s = (N + .5 ) / (2^l);
        end
        
        %Return number of cells on a level
        function c = CCellsLvl(l)
            c = FMM_Cell_HC.reps ^ l;
        end
        
        %Return all nonempty cells for x and y on level l (not optimized)
        function [ncx, ncy] = NonemptyCellsLvl(l, cellarray)
            ncx = [];
            ncy = [];
            ncs = FMM_Cell_HC.CCellsLvl(l);
            for i = 1:ncs
                if isfinite(cellarray{l}(i).dxl)
                    ncx = [ncx i-1];
                end
                if isfinite(cellarray{l}(i).dyl)
                    ncy = [ncy i-1];
                end
            end
        end
        
        %Return all nonempty cells for x, y on level l given single cell c
        function [fx, fy] = isCellEmpty(c, l, cellarray)       
            fx = isfinite(cellarray{l}(c+1).dxl);
            fy = isfinite(cellarray{l}(c+1).dyl);
        end
        
        %Sweep though source x and receiver y points, generate cell array
        %of FMMCell_Hypercube variables
        function [cellarray, xc, yc] = gen(x, y)
            [csl,csr, xc] = FMM_Cell_HC.generateBookmarks(x);
            [ctl,ctr, yc] = FMM_Cell_HC.generateBookmarks(y);
        
            cellarray = cell(FMM_Cell_HC.maxlvl, 1);
            for i = FMM_Cell_HC.maxlvl : -1 : 1
                k = FMM_Cell_HC.reps ^ i;
                for j = 1 : k
                    if i == FMM_Cell_HC.maxlvl
                        cellarray{i}(1, j) = FMM_Cell_HC(csl(j), csr(j), ctl(j), ctr(j), FMM_Cell_HC.CellCenter(j-1, i));
                    else
                        Ch = FMM_Cell_HC.Children(j-1) + 1;
                        dxl = inf;
                        dyl = inf;
                        dxr = -inf;
                        dyr = -inf;
                        for l = 1 : FMM_Cell_HC.reps
                            dxl = min(dxl, cellarray{i+1}(1, Ch(l)).dxl);
                            dyl = min(dyl, cellarray{i+1}(1, Ch(l)).dyl);
                            dxr = max(dxr, cellarray{i+1}(1, Ch(l)).dxr);
                            dyr = max(dyr, cellarray{i+1}(1, Ch(l)).dyr);
                        end
                        cellarray{i}(1, j) = FMM_Cell_HC(dxl, dxr, dyl, dyr, FMM_Cell_HC.CellCenter(j-1, i));
                    end
                end
            end
        end
        
        %Return cell ID containing vector x in unit cube at level l
        function n = CellIndex(x, l)
            n = FMM_Cell_HC.Interleave(floor(x * 2^l));
        end
        
        %Return parent ID of cell n
        function m = Parent(n)
            m = bitshift(n, -FMM_Cell_HC.d);
        end

        %Return cell IDs of childrens of n
        function Ch = Children(n)
            d = FMM_Cell_HC.d;
            Ch = bitshift(n, d) + [0 : (2^d - 1)];
        end

        %Return cell IDs of all siblings of n
        function Sb = Siblings(n)
            Sb = ChildrenAll(Parent(n));
        end

        %Return cell IDs of all neighbors of cell n on level l
        function Nei = Neighbors(n, l)
           d = FMM_Cell_HC.d;
           N = FMM_Cell_HC.Deinterleave(n);
           %Nei = FMM_Cell_HC.NeighborsR(N, 1);
           Nei = FMM_Cell_HC.NeighborsU(N);
           Nei = Nei(find(Nei < (2^d)^l & Nei ~= n));

        end

        %Return cell IDs of all E4 neighbors of cell n on level l
        function NeiE4 = NeighborsE4(n, l)            
            NeiC = [n FMM_Cell_HC.Neighbors(n, l)];
            NeiP = [FMM_Cell_HC.Parent(n) FMM_Cell_HC.Neighbors(FMM_Cell_HC.Parent(n), l-1)];
            NeiE4 = [];
            for i = NeiP
                NeiE4 = [NeiE4 setdiff(FMM_Cell_HC.Children(i), NeiC)];
            end
        end

        %Return level l where each box contains less than or equal to s points,
        %assuming X is sorted
        function L = GetMaxLevel(s, X)
            i = 0;
            m = s;
            L = 0;
            N = size(X, 2);
            while m < N
                i = i + 1;
                m = m + 1;
                a = Interleave(floor(X(:, i) * 2^floor(32/FMM_Cell_HC.d)), FMM_Cell_HC.d);
                b = Interleave(floor(X(:, m) * 2^floor(32/FMM_Cell_HC.d)), FMM_Cell_HC.d);
                j = 32+FMM_Cell_HC.d;
                while a ~= b
                    j = j - FMM_Cell_HC.d;
                    a = Parent(a, FMM_Cell_HC.d);
                    b = Parent(b, FMM_Cell_HC.d);
                end
                L = max(L, j/FMM_Cell_HC.d);
            end
        end
    end

end