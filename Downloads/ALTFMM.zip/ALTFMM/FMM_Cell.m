classdef FMM_Cell
    
	properties
        %Data variables
        dxl = 0;                    %Pointer or idx to first element in source data array in cell
        dxr = 0;                    %Pointer or idx to last element in source data array in cell
        dyl = 0;                    %Pointer or idx to first element in target data array in cell
        dyr = 0;                    %Pointer or idx to last element in target data array in cell
        center;                     %Cell center
    end
    
    %FMM methods
    methods (Static = true, Abstract = true)
        [cellarray, xc, yc] = gen(x, y)	%Sweep though data, generate cell array of instances
       
        s = CellCenter(n, l);           %return vector s of center of cell n
        n = CellIndex(x, l)             %Return cell ID containing vector x in at level l        
        m = Parent(n)                   %Return parent ID of cell n
        Ch = Children(n, l, X)          %Return cell IDs of non-empty childrens of n on level l
        Sb = Siblings(n, l, X)          %Return cell IDs of all nonempty siblings of n on level l
        Nei = Neighbors(n, l, X)        %Return cell IDs of all neighbors of cell n on level l
        NeiE4 = NeighborsE4(n, l, X)    %Return cell IDs of all E4 neighbors of cell n on level l
        
       % L = GetMaxLevel(s, X)           %Return level l where each box contains less than or equal to s points, assuming X is sorted
    end

    
end