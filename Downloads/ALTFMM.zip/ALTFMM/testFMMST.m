function testFMMST
rand('seed',12345)

%Initialization
N = 1000;
M = N;

%Generate data
x = 2*(rand(FMM_Cell_2DST.d, N)-.5);
y = 2*(rand(FMM_Cell_2DST.d, M)-.5);
u = rand(N, 1);
derr = 10^-6;

%Generate FMM cells and initial bookkeeping
[cellarray, xc, yc]  = FMM_Cell_2DST_Coulombic.gen(x, y);

cellarray

tic
vdirect = FMM_Cell_2DST_Coulombic.direct2DCoulombic(xc, yc, u);
toc

% tic
% vslfmm = FMM_Cell_2DST_Coulombic.SLFMM(cellarray, xc, yc, u);
% toc
% err = max(max(abs(real(vdirect - vslfmm))))

% tic
vslfmm = FMM_Cell_2DST_Coulombic.MLFMM(cellarray, xc, yc, u);
% toc
err = max(max(abs(real(vdirect - vslfmm))))


% %Test CellIndex
% tidxs = 2000;
% tidxc = cell(tidxs);
% for i = 1:N
%    idx = FMM_Cell_2DST.CellIndex(x(:,i), inf); 
%    tidxc{idx+1} = [tidxc{idx+1} i]; 
% end
% 
% %Display contents in each cell tidxc
% figure;
% hold on;
% for i = 1 : tidxs
%     if ~isempty(tidxc{i})
%         xx = x(1, tidxc{i});
%         yy = x(2, tidxc{i});
%         rcolor= rand(1, 3);
%         plot(xx, yy, 'ro', 'Color', rcolor);
%         
%         size(tidxc{i})
%         pause;
%     end
% end

% %Test cell center
% figure;
% hold on;
% for i = 0:1000
%     s = FMM_Cell_2DST.CellCenter(i, inf);
%     plot(s(1), s(2), 'ro');
%     pause;
% end