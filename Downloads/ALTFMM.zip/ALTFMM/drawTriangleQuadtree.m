function drawTriangleQuadtree

r = FMM_Cell_2DTQ.r;
maxlvl =  FMM_Cell_2DTQ.maxlvl;
v = []; %Contains set of cell centers

%Equivalent to cell center
for i = 0 : (4^maxlvl-1)

%     j = dec2bin(i, maxlvl*2);
%     up = 1;
%     pv = [0;0];
%     for l = 1 : maxlvl
%         k = bin2dec(j( ((l-1)*2 + 1):((l-1)*2 + 2) ));
% 
%         rt = r * 2^(maxlvl - l);
%         if k > 0
%             if up == 1 %in upward triangle
%                 theta = pi/2 + (k-1)*2*pi/3;
%             else %in inverted triangle
%                 theta = -pi/2 - (k-1)*2*pi/3;
%             end
%             pv(1) = pv(1) + rt * cos(theta);
%             pv(2) = pv(2) + rt * sin(theta);
%         end
%         
%         %Toogle inverted triangle if point is 0
%         if k == 0
%             up = ~up;
%         end
%     end

    pv = FMM_Cell_2DTQ.CellCenter(i, maxlvl);
    
    v = [v pv];
end
% plot(v(1, :), v(2, :), 'ro');


%Testing cellIndex
%Generate points 
nc = 100;
x = [];
for i = 1:(4^maxlvl)
   %For each cell center, generate nc points 
   rc = (rand(2, nc)-.5)*r*2;
   x = [x [rc(1, :) + v(1, i) ; rc(2, :) + v(2,i)] ];
end
% plot(x(1, :), x(2, :), 'ro');
% pause;


n = length(x);
assgn = cell(n, 1);

for i = 1:n
%     up = 1;
%     pv = [0; 0];
%     j = [];
%     for l = 1:maxlvl
%         %For each lvl l, find corresponding nearest center
%         %Generate center points
%         pvs = pv;
%         
%         rt = r * 2^(maxlvl - l);
%         for k = 1:3
%             if up == 1 %in upward triangle
%                 theta = pi/2 + (k-1)*2*pi/3;
%             else %in inverted triangle
%                 theta = -pi/2 - (k-1)*2*pi/3;
%             end
%             pvs = [pvs [pv(1) + rt * cos(theta); pv(2) + rt * sin(theta)] ];
%         end
%         
%         %Find closest point in pvs
%         res = bsxfun(@minus, pvs, x(:, i));
%         [resmin, idx] = min(sum(res .^ 2, 1));
%         
%         pv = pvs(:, idx);
%         j = [j dec2bin(idx-1, 2)];
%         
%         if idx == 1
%             up = ~up;
%         end
%         
%     end
%     idx = (bin2dec(j) + 1);
%     assgn{idx} = [assgn{idx} i];
    
    idx = FMM_Cell_2DTQ.CellIndex(x(:,i), maxlvl)+1;
    assgn{idx} = [assgn{idx} i];
end

figure;
hold on;

for i = 1: (4^maxlvl)
    cc = rand(1,3);
    for j = assgn{i}
        plot(x(1, j), x(2, j), 'o', 'color', cc );
    end
end






