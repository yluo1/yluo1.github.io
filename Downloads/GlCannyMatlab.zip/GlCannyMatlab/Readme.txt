Build using Microsoft Visual Studios 2005, NVIDIA nvcc, Matlab 7.3+
Updated for CUDA 3.1

Under Project Properties:
Add to Configuration Properties->Linker->Input->Additional Dependencies: cudart.lib cutil32D.lib cufft.lib libmx.lib libmex.lib libmat.lib


Add to Configuration Properties->Linker->General->Additional Library Directories: Cuda path; NVIDIA CUDA SDK library path; Matlab library path

e.g.
"$(CUDA_LIB_PATH)";"C:\Program Files\NVIDIA Corporation\NVIDIA CUDA SDK\common\lib";"C:\Program Files\MATLAB\R2006b\extern\lib\win32\microsoft";"C:\Program Files\NVIDIA Corporation\NVIDIA CUDA SDK\common\lib\"


For .cu files, compile using nvcc:
Add to Custom build step->Command Line:

$(CUDA_BIN_PATH)\nvcc.exe -ccbin "$(VCInstallDir)bin" -c -D_DEBUG -DWIN32 -D_CONSOLE -D_MBCS -Xcompiler /EHsc,/W3,/nologo,/Wp64,/Od,/Zi,/RTC1,/MTd -I"$(CUDA_INC_PATH)"  -I"C:\program files\NVIDIA Corporation\NVIDIA CUDA SDK\common\inc" -I"C:\MATLAB7\extern\include" -o $(ConfigurationName)\$(InputName).obj $(InputName).cu


The output should be a .mexw32 file


To run from matlab, call the m file cannyCudaTest.m with parameters: fileName,thresholdLow,thresholdHigh,hysteresis Iterations, total interations

e.g. cannyCudaTest('cmanLarge.jpg',50,100,4,.8,1)
