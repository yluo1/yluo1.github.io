#include "ConstantsIO.h"

Mouse defaultMouse;
Keyboard defaultKeyboard;
Display defaultDisplay(WINDOWWIDTH,WINDOWHEIGHT,WINDOWMINCUT,WINDOWMAXCUT,FOV);