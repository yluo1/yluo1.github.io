#ifndef _MAPIMPULSE_
#define _MAPIMPULSE_

#include "ForcePongConstants.h"



#endif