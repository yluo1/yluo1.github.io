#include "Extensions.h"

//Extensions
PFNWGLSWAPINTERVALFARPROC wglSwapIntervalEXT=(PFNWGLSWAPINTERVALFARPROC)wglGetProcAddress( "wglSwapIntervalEXT" );