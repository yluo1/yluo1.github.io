/*
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer. 

Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution. 

The name of the author may not be used to endorse or promote products
derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Copyright 2008 Yuancheng Luo

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef _OPENCVVID_H_
#define _OPENCVVID_H_

#include <stdlib.h>
#include <stdio.h>

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

#include "Vector.h"


class OpenCVVid{
private:

	//Video
	CvCapture *capture;
	GLubyte *frameDat;


	IplImage *currentFrame;
	IplImage *interFrame3_8u;
	IplImage *interFrame1_8u;
	IplImage *interFrame1_8u2;


public:
	Vector captureDims;
	int captureFPS;
	int captureNumFrames;
	int frameSize;
	int width;
	bool isVideo;
	int nChannels;

	OpenCVVid(){
		capture=NULL;
		currentFrame=NULL;
		interFrame3_8u=NULL;
		interFrame1_8u=NULL;
		interFrame1_8u2=NULL;
		nChannels=0;
		isVideo=true;
	}

	OpenCVVid(char *fileName){
		loadVideo(fileName);
		isVideo=true;
	}
	
	void loadVideo(char *fileName){
		printf("loading %s\n",fileName);
		currentFrame=cvLoadImage(fileName);
		if(currentFrame){//If Image

			isVideo=false;
			captureDims=Vector(	currentFrame->width,currentFrame->height);
			frameSize=captureDims.x*captureDims.y*sizeof(GLubyte)*3;
			width=(int)captureDims.x;

			interFrame3_8u=cvCreateImage( cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 3);
			interFrame1_8u=cvCreateImage(cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 1);
			interFrame1_8u2=cvCreateImage(cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 1);

			nChannels=currentFrame->nChannels;
			if(nChannels==3){
				cvConvertImage( currentFrame,currentFrame,CV_CVTIMG_FLIP|CV_CVTIMG_SWAP_RB);
			}
		


		}else{//If Video

			isVideo=true;
			capture=cvCaptureFromAVI(fileName);
			currentFrame=NULL;
			//Grab Video Properties
			cvQueryFrame(capture);

			captureDims=Vector(	cvGetCaptureProperty(capture,CV_CAP_PROP_FRAME_WIDTH),
								cvGetCaptureProperty(capture,CV_CAP_PROP_FRAME_HEIGHT));
			printf("%f %f\n",cvGetCaptureProperty(capture,CV_CAP_PROP_FRAME_WIDTH),cvGetCaptureProperty(capture,CV_CAP_PROP_FRAME_HEIGHT));
			captureFPS=cvGetCaptureProperty(capture,CV_CAP_PROP_FPS);
			captureNumFrames=cvGetCaptureProperty(capture,CV_CAP_PROP_FRAME_COUNT);
			frameSize=captureDims.x*captureDims.y*sizeof(GLubyte)*3;
			frameDat=NULL;
			width=(int)captureDims.x;

			interFrame3_8u=cvCreateImage( cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 3);
			interFrame1_8u=cvCreateImage(cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 1);
			interFrame1_8u2=cvCreateImage(cvSize(captureDims.x, captureDims.y), 
									 IPL_DEPTH_8U, 1);
		}

	}

	IplImage* getIPLFrame(){
		if(isVideo){
			if(capture==NULL||!cvGrabFrame(capture)) return NULL;
			return cvRetrieveFrame(capture);
		}else return currentFrame;
	}

	GLubyte* getFrameDataFast(){

		currentFrame=getIPLFrame();
		if(isVideo)
			nChannels=currentFrame->nChannels;

		if(currentFrame!=NULL){
			frameDat=(GLubyte*)(currentFrame->imageData);
		}
		return frameDat;
	}

	GLubyte *getCurrentFrame(){
		if(currentFrame!=NULL){
			frameDat=(GLubyte*)(currentFrame->imageData);
		}
		return frameDat;
	}
	
	GLubyte *getFrameDataNormal(){
		if(frameDat==NULL) frameDat=(GLubyte*)calloc(frameSize,1);
		currentFrame=getIPLFrame();
		if(currentFrame!=NULL){
			int nChannels=currentFrame->nChannels;
			
			for(int a=0;a<captureDims.y;++a){
				int row=a*width;
				for(int b=0;b<captureDims.x;++b){
					frameDat[3*(row+b)]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 2];
					frameDat[3*(row+b)+1]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 1];
					frameDat[3*(row+b)+2]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 0];
				}
			}
		}
		
		return frameDat;
	}

	GLubyte *smoothCurrentFrame(int kernelWidth,int kernelHeight,int iterations){
		if(currentFrame!=NULL){
			cvSmooth( currentFrame,interFrame3_8u, CV_GAUSSIAN, kernelWidth, kernelHeight, iterations);
			return (GLubyte*)(interFrame3_8u->imageData);
		}
		return NULL;
	}

	GLubyte *cannyCurrentFrame(float highThres,float lowThres,int appertureSize){
		if(currentFrame!=NULL){
			if(nChannels==3){
				cvCvtColor(currentFrame,interFrame1_8u2,CV_BGR2GRAY);
				cvCanny(interFrame1_8u2,interFrame1_8u,lowThres,highThres,appertureSize);
				cvCvtColor(interFrame1_8u,interFrame3_8u,CV_GRAY2BGR);
				return (GLubyte*)(interFrame3_8u->imageData);
			}else if(nChannels==1){
				return (GLubyte*)(currentFrame->imageData);
			}
			return NULL;
		}
		return NULL;
	}

	GLubyte *getFrameDataChromaticity(){
		if(frameDat==NULL) frameDat=(GLubyte*)calloc(frameSize,1);
		currentFrame=getIPLFrame();
		if(currentFrame!=NULL){
			int nChannels=currentFrame->nChannels;
			
			for(int a=0;a<captureDims.y;++a){
				int row=a*width;
				for(int b=0;b<captureDims.x;++b){
					float sum=0;
					for(int c=0;c<3;++c) sum+=frameDat[3*(row+b)]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + c];
					if(sum!=0){
						frameDat[3*(row+b)]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 2]/sum*255;
						frameDat[3*(row+b)+1]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 1]/sum*255;
						frameDat[3*(row+b)+2]=(currentFrame->imageData + a*currentFrame->widthStep)[b*nChannels + 0]/sum*255;
					}else{
						frameDat[3*(row+b)]=0;
						frameDat[3*(row+b)+1]=0;
						frameDat[3*(row+b)+2]=0;
					}
		
				}
			}
		}
		
		return frameDat;
	}

	GLubyte *getFrameDataSlow(){
		if(frameDat==NULL) frameDat=(GLubyte*)calloc(1,frameSize);
		currentFrame=getIPLFrame();
		if(currentFrame!=NULL){
			for(int a=0;a<captureDims.y;++a){
				int row=a*width;
				for(int b=0;b<captureDims.x;++b){
					CvScalar s=cvGet2D(currentFrame,a,b);
					frameDat[3*(row+b)]=(GLubyte)s.val[2];
					frameDat[3*(row+b)+1]=(GLubyte)s.val[1];
					frameDat[3*(row+b)+2]=(GLubyte)s.val[0];
				}
			}
		}
		return frameDat;
	}

	void unloadVideo(){
		if(capture!=NULL) cvReleaseCapture(&capture);
	}

	void cleanup(){
		if(interFrame3_8u!=NULL) cvReleaseImage(&interFrame3_8u);
		if(interFrame1_8u!=NULL) cvReleaseImage(&interFrame1_8u);
		if(interFrame1_8u2!=NULL) cvReleaseImage(&interFrame1_8u2);
		//unloadVideo();

		//free(frameDat);
	}
};
#endif