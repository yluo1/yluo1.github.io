#ifndef _EDGE_DETECTOR_H
#define _EDGE_DETECTOR_H

#define CANNY_OR_SOBEL	true
#define SOBEL_SEP	true		//Separable filter, otherwise a 2D Convolution filter

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glut.h>

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

#include <cufft.h>
#include <cutil.h>

#include <time.h>
#include <Windows.h>

#include "Display.h"
#include "Keyboard.h"
#include "OpenCVVid.h"
#include "PBO.h"
#include "Texture.h"

//Externs
extern "C" void cannyInit(int iWidth,int iHeight,float stdDev);
extern "C" void cannyFree();
extern "C" void cannyGL(int pbo_in, int pbo_out,int iWidth, int iHeight,float thresholdLow,float thresholdHigh,int hysteresisIts,int channels);

extern "C" void pboRegister(int pbo);
extern "C" void pboUnregister(int pbo);

extern "C" void cudaInit();

class EdgeDetector{
private:
	Display *cDisplay;
	Keyboard *cKeyboard;
	
	PBO vidBufferSrc,vidBufferDest;
	OpenCVVid vidIn;
	Texture vidOutTexture;
	Texture vidProcessedTexture;

	float minThreshold;
	float maxThreshold;
	int hysteresisIts;
	float stdDev;
	int gaussRadius;
	bool pause;
	bool gLCannyEnable;
	bool openCVCannyEnable;

public:
	EdgeDetector();
	EdgeDetector(Display *cDisplay,Keyboard *cKeyboard,char *fileName);

	void run();

	void update();
	void updateCudaVersion();
	void display();
	void processKeyboard();
	void cleanup();

};

#endif