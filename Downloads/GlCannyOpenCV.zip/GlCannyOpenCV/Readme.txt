COMPILING INSTRUCTIONS

Compile using Microsoft Visual Studios 2005 and NVIDIA nvcc
Updated for CUDA 3.1

Under Project Properties:
Add to Configuration Properties->Linker->Input->Additional Dependencies: cudart.lib cutil32D.lib cufft.lib glew32d.lib glut32.lib cv.lib highgui.lib cxcore.lib


Add to Configuration Properties->Linker->General->Additional Library Directories: Cuda path; NVIDIA CUDA SDK library path; OpenCV library path; OpenGL Path (included in NVIDIA CUDA SDK library)

e.g.
"$(CUDA_LIB_PATH)";"C:\Program Files\OpenCV\lib";"C:\Program Files\NVIDIA Corporation\NVIDIA CUDA SDK\common\lib";"C:\Program Files\OpenCV\otherlibs\_graphics\lib";"$(CUDA_LIB_PATH);../../common/lib";


For .cu files, compile using nvcc:
Add to Custom build step->Command Line:

$(CUDA_BIN_PATH)\nvcc.exe -ccbin "$(VCInstallDir)bin" -c -D_DEBUG -DWIN32 -D_CONSOLE -D_MBCS -Xcompiler /EHsc,/W3,/nologo,/Wp64,/Od,/Zi,/RTC1,/MTd -I"$(CUDA_INC_PATH)" -I./ -I../../common/inc -o $(ConfigurationName)\$(InputName).obj $(InputName).cu




To execute: Pass in the filename.extension as commandline argument to run.
e.g."images\mandrill5.jpg"

Supports jpg,tif,bmp image extensions and avi movie extension

Configuration Properties->Debugging->Command Arguments


Keys:
4,6: 	decrease/increase high hysteresis threshold
7,8: 	decrease/increase low hysteresis threshold
u,o: 	decrease/increase number of hysteresis iterations
e:   	enable OpenCV canny
p:   	pause frame
q:	Toggle canny