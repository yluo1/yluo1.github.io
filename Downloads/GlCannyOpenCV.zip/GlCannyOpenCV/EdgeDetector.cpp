#include "EdgeDetector.h"
#include "cv.h"

EdgeDetector::EdgeDetector(){
}

EdgeDetector::EdgeDetector(Display *cDisplay,Keyboard *cKeyboard, char *fileName){
	this->cDisplay=cDisplay;
	this->cKeyboard=cKeyboard;

	cudaInit();

	//Setup video in 
	vidIn.loadVideo(fileName);

	//Setup PBO
	vidBufferSrc=PBO(vidIn.captureDims);
	vidBufferDest=PBO(vidIn.captureDims);

	//Register PBO to CUDA
	pboRegister(vidBufferSrc.id);

	//Setup output texture
	vidOutTexture.makeTexture(vidIn.captureDims);
	vidProcessedTexture.makeTexture(vidIn.captureDims);

	//Setup OpenGL screen
	cDisplay->initOrtho();
	glClearColor(1,1,1,1);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	minThreshold=50;
	maxThreshold=100;
	stdDev=.84089642;
	gaussRadius=3;
	hysteresisIts=4;
	pause=false;

	gLCannyEnable=true;
	openCVCannyEnable=false;

	cannyInit(vidIn.captureDims.x,vidIn.captureDims.y,stdDev);

}

void EdgeDetector::run(){
	processKeyboard();
	update();
	display();
}


void EdgeDetector::display(){
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0, 0, cDisplay->winDims.x, cDisplay->winDims.y);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);


	//Render output quad
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,vidOutTexture.id);

	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex2f(cDisplay->winDims.x*.1,0);
	glTexCoord2f(1,0); glVertex2f(cDisplay->winDims.x*.9,0);
	glTexCoord2f(1,1); glVertex2f(cDisplay->winDims.x*.9,cDisplay->winDims.y/2);
	glTexCoord2f(0,1); glVertex2f(cDisplay->winDims.x*.1,cDisplay->winDims.y/2);
	glEnd();

	glBindTexture(GL_TEXTURE_2D,vidProcessedTexture.id);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex2f(cDisplay->winDims.x*.1,cDisplay->winDims.y/2);
	glTexCoord2f(1,0); glVertex2f(cDisplay->winDims.x*.9,cDisplay->winDims.y/2);
	glTexCoord2f(1,1); glVertex2f(cDisplay->winDims.x*.9,cDisplay->winDims.y);
	glTexCoord2f(0,1); glVertex2f(cDisplay->winDims.x*.1,cDisplay->winDims.y);
	glEnd();

	glDisable(GL_TEXTURE_2D);

	//Display stats
	char c[50];
	sprintf(c,"%.2f",minThreshold);
	cDisplay->displayString("Min Threshold", Vector(1100,825),.1,NULL,Vector(1,0,0,1));
	cDisplay->displayString(c, Vector(1100,800),.1,NULL,Vector(1,0,0,1));

	sprintf(c,"%.2f",maxThreshold);
	cDisplay->displayString("max Threshold", Vector(1100,775),.1,NULL,Vector(1,0,0,1));
	cDisplay->displayString(c, Vector(1100,750),.1,NULL,Vector(1,0,0,1));
/*
	sprintf(c,"%.2f",stdDev);
	cDisplay->displayString("standard deviation", Vector(1100,725),.1,NULL,Vector(1,0,0,1));
	cDisplay->displayString(c, Vector(1100,700),.1,NULL,Vector(1,0,0,1));

	sprintf(c,"%d",gaussRadius);
	cDisplay->displayString("Gauss radius", Vector(1100,675),.1,NULL,Vector(1,0,0,1));
	cDisplay->displayString(c, Vector(1100,650),.1,NULL,Vector(1,0,0,1));
*/
	
	sprintf(c,"%d",hysteresisIts);
	cDisplay->displayString("hyst its", Vector(1100,600),.1,NULL,Vector(1,0,0,1));
	cDisplay->displayString(c, Vector(1100,575),.1,NULL,Vector(1,0,0,1));

	
}

void EdgeDetector::processKeyboard(){
	if(cKeyboard->keys['7']){
		if(minThreshold>1){
			minThreshold-=1;
		}
	}else if(cKeyboard->keys['9']){
		if(minThreshold<maxThreshold-1){
			minThreshold+=1;
		}
	}

	if(cKeyboard->keys['4']){
		if(maxThreshold>minThreshold+1){
			maxThreshold-=1;
		}
	}else if(cKeyboard->keys['6']){
		maxThreshold+=1;
	}

	if(cKeyboard->keys['1']){
		if(stdDev>.004){
			stdDev-=.004;
		}
	}else if(cKeyboard->keys['3']){
		stdDev+=.004;
	}

	if(cKeyboard->keys['2']){
		if(gaussRadius>0){
			gaussRadius--;
			cKeyboard->keys['2']=0;
		}
	}else if(cKeyboard->keys['8']){
		gaussRadius++;
		cKeyboard->keys['8']=0;
	}


	if(cKeyboard->keys['u']){
		hysteresisIts--;
		cKeyboard->keys['u']=0;
	}else if(cKeyboard->keys['o']){
		hysteresisIts++;
		cKeyboard->keys['o']=0;
	}

	if(cKeyboard->keys['p']){
		pause=!pause;
		cKeyboard->keys['p']=false;
	}


	if(cKeyboard->keys['q']){
		gLCannyEnable=!gLCannyEnable;
		cKeyboard->keys['q']=false;
	}

	if(cKeyboard->keys['e']){
		openCVCannyEnable=!openCVCannyEnable;
		cKeyboard->keys['e']=false;
	}
}

void EdgeDetector::update(){

	updateCudaVersion();
}

void EdgeDetector::updateCudaVersion(){
	pboUnregister(vidBufferSrc.id);

	//////////////Dump video data into pbo
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER_ARB, vidBufferSrc.id);
	
	// Map buffer. Returns pointer to buffer memory
	void *pboMemory;
	GLubyte *i=NULL;

	if(!pause){
		i=vidIn.getFrameDataFast();
	}else{
		i=vidIn.getCurrentFrame();
	}

	if(openCVCannyEnable){
		////Cut here
		pboMemory = glMapBuffer(GL_PIXEL_UNPACK_BUFFER_ARB, GL_WRITE_ONLY);
		
		float clock_start=timeGetTime();

		GLubyte *t=vidIn.cannyCurrentFrame(maxThreshold,minThreshold,3);
		
		float clock_end=timeGetTime();
		float time_c=(float)(clock_end-clock_start);
		static float avg=time_c;
		avg=avg*.98+.02*time_c;
		printf("OpenCV %f millis = %f fps, runavg=%f \n",time_c,1000/time_c,avg);


		if(t!=NULL)  memcpy(pboMemory,t,vidIn.frameSize);

		// Unmaps buffer, indicating we are done writing data to it
		glUnmapBuffer(GL_PIXEL_UNPACK_BUFFER_ARB);
		////End cut here
	}

	//Write original to texture
	glBindTexture(GL_TEXTURE_2D,vidOutTexture.id);
	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, vidIn.captureDims.x, vidIn.captureDims.y,
					GL_RGB,  GL_UNSIGNED_BYTE,NULL);

	pboMemory = glMapBuffer(GL_PIXEL_UNPACK_BUFFER_ARB, GL_WRITE_ONLY);
	if(i!=NULL) memcpy(pboMemory,i,vidIn.frameSize);
	glUnmapBuffer(GL_PIXEL_UNPACK_BUFFER_ARB);

	//Cuda stuff
	glBindBuffer(GL_PIXEL_PACK_BUFFER_ARB, vidBufferSrc.id);
	//Cuda processing
	pboRegister(vidBufferSrc.id);
	pboRegister(vidBufferDest.id);

	if(gLCannyEnable){
		cannyGL(vidBufferSrc.id,vidBufferDest.id,vidIn.captureDims.x,vidIn.captureDims.y,minThreshold,maxThreshold,hysteresisIts,vidIn.nChannels);
	}
	pboUnregister(vidBufferDest.id);


	
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER_ARB, vidBufferDest.id);
	glBindTexture(GL_TEXTURE_2D,vidProcessedTexture.id);
	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, vidIn.captureDims.x, vidIn.captureDims.y,
					GL_RGB, GL_UNSIGNED_BYTE,NULL);

	// Unbind buffer
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER_ARB, 0);
	glBindBuffer(GL_PIXEL_PACK_BUFFER_ARB, 0);

}


void EdgeDetector::cleanup(){
	vidIn.cleanup();
	cannyFree();
}