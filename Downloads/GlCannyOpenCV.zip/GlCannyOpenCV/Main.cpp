/*
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer. 

Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution. 

The name of the author may not be used to endorse or promote products
derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Copyright 2008 Yuancheng Luo

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.





Pass in filename.extension as command line argument to run.
Supports jpg, tif, bmp image extensions and .avi movie extension
*/
#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include <time.h>
#include "constants.h"

#include "EdgeDetector.h"

//Funtion Proto-types
void renderScene();
void forIdle();
void cleanup();
void processNormalKeys(unsigned char key, int x, int y);
void processSpecialKeys(int key, int x, int y);
void processNormalKeysUp(unsigned char key, int x, int y);
void processSpecialKeysUp(int key, int x, int y);

time_t cTime,lTime;
float fps=0;
int frames=0;

//Application
EdgeDetector edgeDetector;



void main(int argc, char** argv){
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(defaultDisplay.winPosition.x,defaultDisplay.winPosition.y);
	glutInitWindowSize(defaultDisplay.winDims.x,defaultDisplay.winDims.y);
	glutCreateWindow("OpenGL CUDA Edge Detector");

	glutDisplayFunc(renderScene);
	glutIdleFunc(forIdle);
	glutKeyboardFunc(processNormalKeys);
	glutKeyboardUpFunc(processNormalKeysUp);
	glutSpecialFunc(processSpecialKeys);
	glutSpecialFunc(processSpecialKeysUp);

	glewInit();
    if (!glewIsSupported( "GL_VERSION_2_0 GL_ARB_pixel_buffer_object")) {
        fprintf( stderr, "ERROR: Support for necessary OpenGL extensions missing.");
        fflush( stderr);
    }
	if(argc!=2){
		printf("Pass filename as 2nd parameter\n");
		getchar();
		exit(0);
	}
	
	timeBeginPeriod(1);

	edgeDetector=EdgeDetector(&defaultDisplay,&defaultKeyboard,argv[1]);
	//edgeDetector=EdgeDetector(&defaultDisplay,&defaultKeyboard,"mandrill5.jpg");
	atexit(cleanup);

	glutMainLoop();
}



void renderScene(){

}

void forIdle(){
	edgeDetector.run();

	frames++;
	time(&cTime);
	if(difftime(cTime,lTime)>=1.0){
		time(&lTime);
		fps=frames;
		frames=0;
	}
	//Display fps
	char c[10];
	itoa((int)fps,c,10);
	defaultDisplay.displayString("FPS",Vector(1100,875),.1,NULL,Vector(1,0,0,1));
	defaultDisplay.displayString(c,Vector(1100,850),.1,NULL,Vector(1,0,0,1));
	
	glutSwapBuffers();
}

void processNormalKeys(unsigned char key, int x, int y){
	defaultKeyboard.keys[key]=1;
}
void processSpecialKeys(int key, int x, int y){
	defaultKeyboard.specialKeys[key]=1;
}
void processNormalKeysUp(unsigned char key, int x, int y){
	defaultKeyboard.keys[key]=0;
}

void processSpecialKeysUp(int key, int x, int y){
	defaultKeyboard.specialKeys[key]=0;
}

void cleanup(){
	edgeDetector.cleanup();
	timeEndPeriod(1);
}