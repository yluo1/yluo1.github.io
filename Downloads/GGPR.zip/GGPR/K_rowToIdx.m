function idx = K_rowToIdx(m, n)
%Column index to KTP index (cell version)

D = numel(m);
idx = cell(D, 1);

for i = D:-1:1
    idx{i} = mod(n-1, m(i))+1;
    n = ceil(n/m(i));
end





