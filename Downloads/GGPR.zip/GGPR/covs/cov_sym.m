function varargout = cov_sym(s_C, s_x1, s_x2, s_theta, ndx1)
%Generate symbolic equations
%s_theta is 1 x m array of syms


if nargout > 1
    s_dC_dtheta = cell(numel(s_theta), 1);
    for i = 1:numel(s_theta)
        s_dC_dtheta{i} = diff(s_C, s_theta(i));
        s_dC_dtheta{i} = matlabFunction(s_dC_dtheta{i}, 'vars', {s_x1, s_x2, s_theta}); 
    end
    varargout{2} = s_dC_dtheta;
end

if nargout > 2
    s_dC_dx1 = cell(ndx1, 1);
    for i = 1:ndx1
        if i == 1
            s_dC_dx1{i} = simplify(diff(s_C, s_x1));
        else
            s_dC_dx1{i} = simplify(diff(s_dC_dx1{i-1}, s_x1));
        end
    end
    
    for i = 1:ndx1
         s_dC_dx1{i} = matlabFunction(s_dC_dx1{i}, 'vars', {s_x1, s_x2, s_theta});
    end   
    varargout{3} = s_dC_dx1;
end

s_C = matlabFunction(s_C,  'vars', {s_x1, s_x2, s_theta}); 
varargout{1} = s_C;
