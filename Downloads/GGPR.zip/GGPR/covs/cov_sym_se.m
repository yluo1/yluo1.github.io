function [varargout] = cov_sym_se(x1, x2, theta, ndx1)
%Squared exponential
%Input
%x1: m_1 x p
%x2: m_2 x p

%theta: m x p

%Output
%C: m_i x m_i
%dC_dtheta: p-cell array of m_1 x m_2
%dC_dx1: p x ndx1-cell array of m_1 x m_2

%Covariance 
%Cov(dx) = exp(-(dx.^2 / (2ell.^2) ) )
if isempty(x1) || isempty(x2)
    varargout{1:nargout} = [];
    return;
end

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_sym_se: p1, p2 mismatch'); 
end
p = p1;

[mtheta, ptheta] = size(theta);
if ptheta ~= p
   error('cov_sym_se p, x dim mismatch'); 
end

if nargin < 4
    ndx1 = 2;
end

syms s_x1 s_x2 s_theta;
persistent s_C_se s_dC_dtheta_se s_dC_dx1_se;
if isempty(s_C_se) 
    s_C = simplify(exp(-(s_x1 - s_x2).^2 ./ (2*s_theta^2)));
    [s_C_se, s_dC_dtheta_se, s_dC_dx1_se] = cov_sym(s_C, s_x1, s_x2, s_theta, ndx1);    
end

%Evaluate covariance and derivatives
[varargout{1:nargout}] = cov_sym_eval(x1, x2, theta, s_C_se, s_dC_dtheta_se, s_dC_dx1_se);
    