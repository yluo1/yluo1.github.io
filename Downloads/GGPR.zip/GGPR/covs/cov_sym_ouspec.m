function [varargout] = cov_sym_ouspec(x1, x2, theta, ndx1)
%Ornstein-Uhlenbeck spectral density
%Input
%x: m_i x mtheta
%theta: mtheta x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i
%dC_dx1: p x ndx1-cell array of m_1 x m_2

%Covariance 
%Cov(dx) = 1 / (ell^2 + r^2)

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_sym_ouspec: p1, p2 mismatch'); 
end
p = p1;

[mtheta, ptheta] = size(theta);
if ptheta ~= p
   error('cov_sym_ouspec ptheta, x dim mismatch'); 
end

if nargin < 4
    ndx1 = 2;
end

syms s_x1 s_x2 s_theta;
persistent s_C_ouspec s_dC_dtheta_ouspec s_dC_dx1_ouspec;
if isempty(s_C_ouspec) 
    r = (s_x1 - s_x2);
    s_C = simplify(1./(r.^2 + s_theta.^2) );
    [s_C_ouspec, s_dC_dtheta_ouspec, s_dC_dx1_ouspec] = cov_sym(s_C, s_x1, s_x2, s_theta, ndx1);    
end

%Evaluate covariance and derivatives
[varargout{1:nargout}] = cov_sym_eval(x1, x2, theta, s_C_ouspec, s_dC_dtheta_ouspec, s_dC_dx1_ouspec);