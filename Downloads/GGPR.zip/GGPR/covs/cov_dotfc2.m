function [C, dC] = cov_dotfcq(x1, x2, theta)
%Dot-product full-covariance cholesky v2
%Input
%x: m_i x p
%theta: (p^2+p)/2 x 1

%Output
%C: m_i x m_i
%dC: (p^2+p)/2-cell array of m_i x m_i

%Covariance 
%Cov(x1,x2) = (x1'*Ut*U*x2).^pp where U is upper triangular

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_dotfc: p1, p2 mismatch'); 
end
p = p1;
pp = 1;

mtheta = length(theta);

if mtheta ~=  (p^2+p)/2
   error('cov_dotfc: mtheta, (p^2+p)/2 mismatch'); 
end

%Produce lower triangular L 
ell = tril(ones(p));
ell = reshape(ell, p^2, 1);
lidx = find(ell == 1);
% clidx = ceil(lidx / p);
% rlidx = lidx - (clidx-1)*p;

% U = eye(p);
L = zeros(p^2, 1);
L(lidx) = theta;
L = reshape(L, p, p);

C = (x1*L*L'*x2').^pp;

if nargout > 1
	dC = cell(mtheta, 1);
    for j = 1:m1
        for k = 1:m2
            tmp = x1(j, :)' * (x2(k, :) * L) + x2(k,:)' * (x1(j , :) * L);
            tmp = reshape(tmp, [p^2, 1]);
            tmp = tmp(lidx);
            for i = 1:mtheta
                dC{i}(j, k) = tmp(i, 1); 
            end
        end
    end
    for i =  1:mtheta
        dC{i} = pp * C.^(pp-1) .* dC{i}; 
    end
end

