function [C, dC] = cov_ou(x1, x2, theta)
%Ornstein-Uhlenbeck
%Input
%x: m_i x mtheta
%theta: mtheta x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i

%Covariance 
%Cov(dx) = exp(-(abs(dx) / (ell) ) )

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_ou: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta ~= p
   error('cov_ou mtheta, x dim mismatch'); 
end

ell = theta';

C = zeros(m1, m2);
if nargout > 1
    dC = cell(mtheta, 1);
    for j = 1:mtheta
        dC{j} = zeros(m1, m2);
    end
end

for i = 1:m2
    s1 = abs(bsxfun(@minus, x1, x2(i,:)));
    s1 = -bsxfun(@rdivide, s1, ell);
    s2 = sum(s1, 2);
    C(:, i) = exp(s2);

    if nargout > 1
        for j = 1:mtheta
            dC{j}(:, i) = -s1(:, j) / ell(j); 
        end
    end
end
if nargout > 1
    for j = 1:mtheta
        dC{j} = dC{j} .* C;
    end
end