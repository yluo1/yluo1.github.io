function [C, dC] = cov_gabor(x1, x2, theta)
%Squared exponential *  periodic
%Input
%x: m_i x mtheta
%theta: 2 * mtheta x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i

%Covariance 
%Cov(dx) = exp(-(dx)^2 / (2ell.^2) ) ) cos(2pi |dx| / p^2)


[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_gabor: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta/2 ~= p
   error('cov_gabor mtheta, x dim mismatch with theta'); 
end

ell = theta(1:(mtheta/2))';
period = theta((mtheta/2 + 1) : end)';

C = zeros(m1, m2);
Ce = zeros(m1, m2);
Cc = zeros(m1, m2);
Cs = zeros(m1, m2);

if nargout > 1
    dC = cell(mtheta, 1);
    for j = 1:mtheta
        dC{j} = zeros(m1, m2);
    end
end

for i = 1:m2
    s1 = bsxfun(@minus, x1, x2(i,:));
    s1e = -bsxfun(@rdivide, s1.^2, 2*(ell.^2));
    s2e = sum(s1e, 2);
    s1c = 2*pi * bsxfun(@rdivide, abs(s1), period.^2);
    s2c = sum(s1c, 2);
    
    Ce(:, i) = exp(s2e);
    Cc(:, i) = cos(s2c);
    Cs(:, i) = sin(s2c);
    C(:, i) = Ce(:,i) .* Cc(:,i);
    
    if nargout > 1
        for j = 1:(mtheta/2)
            dC{j}(:, i) = -2*s1e(:, j) / ell(j); 
        end
        for j = 1:(mtheta/2)
            dC{mtheta/2 + j}(:, i) = -2 * s1c(:, j) / period(j); 
        end
    end
end
if nargout > 1
    for j = 1:(mtheta/2)
        dC{j} = dC{j} .* C;
    end
    for j = 1:(mtheta/2)
        dC{mtheta/2 + j} = dC{mtheta/2 + j} .* Ce .* -Cs;
    end
end
