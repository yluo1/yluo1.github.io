function [C, dC] = cov_ou_fc(x1, x2, theta)
%Exponential with Full-covariance and cholesky hyperparams (Mahalanobis)
%Input
%x: m_i x p
%theta: (p^2+p)/2 x 1

%Output
%C: m_i x m_i
%dC: (p^2+p)/2-cell array of m_i x m_i

%Covariance 
%Cov(x1,x2) = exp(-.5 sqrt((x1-x2)'*L*L'*(x1-x2)) ) where L is lower triangular

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_se_fc: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);

if mtheta ~=  (p^2+p)/2
   error('cov_se_fc: mtheta, (p^2+p)/2 mismatch'); 
end

%Produce upper triangular U 
ell = tril(ones(p));
ell = reshape(ell, p^2, 1);
lidx = find(ell == 1);

L = zeros(p^2, 1);
L(lidx) = theta;
L = reshape(L, p, p);

if nargout > 1
    dC = cell(mtheta, 1);
    for i = 1:mtheta
        dC{i} = zeros(m1, m2);
    end
end

CInner = zeros(m1, m2);
for i = 1:m1
    x2minusx1L = bsxfun(@minus, x2, x1(i, :)) * L;
    CInner(i, :) = sum(x2minusx1L.^2 ,2)';
    if nargout > 1
        for k = 1:m2
            tmp = - (x2(k, :) - x1(i, :) )' * ((x2(k, :) - x1(i, :) ) * L);
            tmp = reshape(tmp, [p^2, 1]);
            tmp = tmp(lidx);
            for j = 1:mtheta
                dC{j}(i, k) = tmp(j, 1); 
            end
        end
    end
end
C = exp(-.5 * (CInner.^(.5)) );

if nargout > 1
    for i =  1:mtheta
        dC{i} = C .* ((.5) * (CInner.^(-.5))) .* dC{i}; 
        dC{i}(~isfinite(dC{i})) = 0;
    end
end
