function [C, dC] = cov_sum_ou(x1, x2, theta)
%Additive exponential
%Input
%x: m_i x mtheta
%theta: mtheta x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i

%Covariance 
%Cov(dx) = %Cov(dx) = sum_mtheta exp(-(dx.^2 / (2ell.^2) ) )  exp(-(|dx| / (2ell.^2) ) )


[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_se: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta ~= p
   error('cov_se mtheta, x dim mismatch'); 
end

ell = theta';

C = zeros(m1, m2);
if nargout > 1
    dC = cell(mtheta, 1);
    for j = 1:mtheta
        dC{j} = zeros(m1, m2);
    end
end

for i = 1:m2
    s1 = abs(bsxfun(@minus, x1, x2(i,:)));
    s1 = -bsxfun(@rdivide, s1, 2*ell.^2);
    s2 = exp(s1);
    C(:, i) = sum(s2, 2);

    if nargout > 1
        for j = 1:mtheta
            dC{j}(:, i) = -2*s1(:, j) / ell(j) .* s2(:, j); 
        end
    end
end
