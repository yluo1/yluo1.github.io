function [C, dC] = cov_period(x1, x2, theta)
%Squared exponential of periodic
%Input
%x: m_i x mtheta
%theta: (mtheta + 1) x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i

%Covariance 
%Cov(dx) = exp(-sin(2pi|dx|/p^2)^2) / (2 * ell^2) )


[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_period: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta-1 ~= p
   error('cov_period mtheta, x dim mismatch with theta'); 
end

period = theta(1:(end-1))';
ell = theta(end)';

C = zeros(m1, m2);
Cs = zeros(m1, m2);
Cs2 = zeros(m1, m2);

if nargout > 1
    dC = cell(mtheta, 1);
    for j = 1:mtheta
        dC{j} = zeros(m1, m2);
    end
end

for i = 1:m2
    s1 = bsxfun(@minus, x1, x2(i,:));
    s1s = 2 * pi * bsxfun(@rdivide, abs(s1), period.^2);
    s2s = sum(s1s, 2);
    
    Cs(:, i) = sin(s2s);
    Cs2(:, i) = - (Cs(:,i).^2) / (2 * ell.^2);
    C(:, i) = exp(Cs2(:, i)) ;
    
    if nargout > 1
        for j = 1:(mtheta-1)
            dC{j}(:, i) = -1/(2*ell.^2) * 2 * Cs(:,i) .* cos(s2s) .* -2 .* s1s(:,j) / period(j);
        end
        dC{mtheta}(:, i) = -2 * Cs2(:, i) / ell; 
    end
end
if nargout > 1
    for j = 1:mtheta
        dC{j} = dC{j} .* C;
    end
end
