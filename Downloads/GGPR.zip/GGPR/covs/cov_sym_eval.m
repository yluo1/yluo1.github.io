function varargout = cov_sym_eval(x1, x2, theta, s_C, s_dC_dtheta, s_dC_dx1)
%Standard model
%theta = m x p hyperparams
%s_dC_dtheta = m x p hyperparams

[m1, p1] = size(x1);
[m2, p2] = size(x2);
p = p1;
ndx1 = numel(s_dC_dx1);

mtheta = numel(s_dC_dtheta);
ptheta = p;
if nargout > 1
    dC_dtheta = cell(mtheta, ptheta);
    for j = 1:ptheta
        for i = 1:mtheta
            dC_dtheta{i, j} = ones(m1, m2); 
        end
    end
end

if nargout > 2
    dC_dx1 = cell(p, ndx1);
	for i = 1:p
        for j = 1:ndx1
            dC_dx1{i,j} = ones(m1, m2); 
        end
	end
end

C = ones(m1, m2);
for i = 1:p
    x1_s = repmat(x1(:, i), 1, m2);
    x1_s = x1_s(:);
    
    x2_s = repmat(x2(:, i)', m1, 1);
    x2_s = x2_s(:);
    
%     theta_s = theta(i) * ones(m1, m2);
    theta_s = bsxfun(@times, ones(m1*m2, mtheta), theta(:, i)');
  
    Cc = reshape(s_C(x1_s, x2_s, theta_s), m1, m2);
    C = C .* Cc;
    
    if nargout > 1
        for k = 1:mtheta
            for j = 1:ptheta
                if i == j
                    dC_dtheta{k, j} = dC_dtheta{k, j} .* reshape(s_dC_dtheta{k}(x1_s, x2_s, theta_s), m1, m2);
                else
                    dC_dtheta{k, j} = dC_dtheta{k, j} .* Cc;
                end
            end
        end
    end

    if nargout > 2
        for j = 1:p
            for k = 1:ndx1
                if i == j
                    dC_dx1{j,k} = dC_dx1{j,k} .* reshape(s_dC_dx1{k}(x1_s, x2_s, theta_s), m1, m2);
                else
                    dC_dx1{j,k} = dC_dx1{j,k} .* Cc;
                end
            end
        end
    end
end

varargout{1} = C;
if nargout > 1
    varargout{2} = dC_dtheta;
end
if nargout > 2
    varargout{3} = dC_dx1;
end

    