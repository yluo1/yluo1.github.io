function y = K_diag_KzKT(K, z)
%Input:
%K is cell matrix
%z is vector
%Output:
% y = diag(K*diag(z)*K')

D = numel(K);
m1 = zeros(D, 1);
m2 = zeros(D, 1);
for i = 1:D
    [m1(i), m2(i)] = size(K{i});
end
N = prod(m1);
y = zeros(N, 1);
for i = 1:N
%     idx = K_rowToIdx(K, i);
  idx = K_rowToIdx(m1, i);
    a = 1;
	for j = 1:D
        a = K_a_b(a, K{j}(idx{j}, :)');
	end
	y(i) = (a .* z)'  * a;
end