function c = K_a_b(a, b)
%Input:
%a, b: Column vectors

%Output
%C: kron(diag(a), diag(b))

c = reshape(bsxfun(@times, a(:)', b(:)), numel(a)*numel(b), 1);