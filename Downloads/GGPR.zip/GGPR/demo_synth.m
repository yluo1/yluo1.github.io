function demo_synth
addpath('covs');

% demo_D(1);
demo_D(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function demo_D(KD)
Nd = 32;
Md = 3;
Qd = 2 * Nd;
sigma = .3;
period = 1;

[X, Xu, Xq, y, ysig] = demo_genData(KD, Nd, Md, Qd, period, sigma);

% y = [4+y, -4-y];
% ysig = [4+ysig, -4-ysig];

D = KD + 1;
ggpr.D = D;
ggpr.covs{1} = str2func('cov_sym_alpha');
ggpr.theta{1} = 1;
for i = 2:D
    ggpr.covs{i} = str2func('cov_sym_se');
    ggpr.theta{i} = 1;
end
ggpr.X = X;
ggpr.Y = ysig;
ggpr.sigma = sigma;
ggpr.maxiter = 50;
ggpr.asig = 0;

%DTC-GPR
ggpr.Xu = Xu;
ggpr.Xuc{1} = 1;
for i = 2:D
    ggpr.Xuc{i} = 0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%GRID-GPR
[ggpr_std] = std_call_ggpr(ggpr, {});
ggpr_std.maxiter = 1;
[tmp, yq, cq] = std_call_ggpr(ggpr_std, Xq);
[tmp, yq_out] = std_call_ggpr(ggpr_std, X);
std_err = sqrt(mean(sum(y-yq_out.^2)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%DTC-GRID-GPR
ggpr.axu_fac = 1.025;
ggpr.axu_start = .01;
[ggpr_dtc] = dtc_call_ggpr(ggpr, {});
ggpr_dtc.maxiter = 1;
[tmp, yq_dtc, cq_dtc] = dtc_call_ggpr(ggpr_dtc, Xq);
[tmp, yq_dtc_out] = dtc_call_ggpr(ggpr_dtc, X);
dtc_err = sqrt(mean(sum(y-yq_dtc_out.^2)));

fprintf(1, 'GRID-GPR RMSE %f, DTC-GID-GPR RMSE %f\n', std_err, dtc_err);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Display
if KD == 1
    fig = figure('Units','normalized','Position',[0 0 1 1]);
    PH = [];
    PLab = {};
    markerSize = 25;
    lineWidth = 3;
    PLab{numel(PLab)+1} = 'Observations'; H = plot(X{2}, ysig, 'rx',  'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    
    PLab{numel(PLab)+1} = ['Truth'];  H = plot(X{2}, y, 'g.-', 'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    PLab{numel(PLab)+1} = ['STD-GPR-Mean Prediction'];  H = plot(Xq{2}, yq, 'm-',   'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    PLab{numel(PLab)+1} = ['STD-GPR-95% Confidence'];  H = plot(Xq{2}, bsxfun(@plus, yq, 2*sqrt(cq)), 'c--', 'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    plot(Xq{2}, bsxfun(@minus, yq, 2*sqrt(cq)), 'c--', 'MarkerSize', markerSize, 'LineWidth', lineWidth);hold on;
    
    PLab{numel(PLab)+1} = ['DTC-GPR-Mean Prediction'];  H = plot(Xq{2}, yq_dtc, 'b-',   'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    PLab{numel(PLab)+1} = ['DTC-GPR-95% Confidence'];  H = plot(Xq{2}, bsxfun(@plus, yq_dtc, 2*sqrt(cq_dtc)), 'y--', 'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    plot(Xq{2}, bsxfun(@minus, yq_dtc, 2*sqrt(cq_dtc)), 'y--', 'MarkerSize', markerSize, 'LineWidth', lineWidth);hold on;
    PLab{numel(PLab)+1} = 'Initial Sparse Inputs';  H = plot(Xu{2}, min(ysig(:))*ones(numel(Xu{2}), 1) - 1, 'ms', 'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    PLab{numel(PLab)+1} = 'Trained Sparse Inputs';  H = plot(ggpr_dtc.Xu{2}, min(ysig(:))*ones(numel(Xu{2}), 1) - 1, 'gx', 'MarkerSize', markerSize, 'LineWidth', lineWidth); PH = [PH; H(1)]; hold on;
    
    xlabel('X','fontsize',26, 'FontName', 'Times New Roman');
    ylabel('Y','fontsize',26, 'FontName', 'Times New Roman');
    lh = legend(PH, PLab, 'Location', 'NorthEastOutside');
    set(lh,'FontSize',20);
    set(gca,'FontSize',20,'fontWeight','bold');
    
elseif KD == 2    
    fig = figure('Units','normalized','Position',[0 0 1 1]);
    markerSize = 15;
    lineWidth = 2;
    axisFontSize = 16;
    titleFontSize = 22;

    subplot(2,2, 1);
    h = pcolor(X{2}, X{3}, reshape(ysig, [numel(X{2}), numel(X{3})]));
    set(h,'EdgeColor','none');
    title('Observations', 'FontSize', titleFontSize);
    set(gca,'FontSize',axisFontSize );
    
    subplot(2,2, 3);
	h = pcolor(Xq{2}, Xq{3}, reshape(yq, [numel(Xq{2}), numel(Xq{3})]));
    set(h,'EdgeColor','none');
	title('STD-GRID-GPR-Mean', 'FontSize', titleFontSize);
	set(gca,'FontSize',axisFontSize );
    
	subplot(2,2, 2);
    h = pcolor(Xq{2}, Xq{3}, reshape(yq_dtc, [numel(Xq{2}), numel(Xq{3})]));
    set(h,'EdgeColor','none');
    title('DTC-GRID-GPR-Mean', 'FontSize', titleFontSize);    
    set(gca,'FontSize',axisFontSize );  
    
	subplot(2,2, 4);
    h = pcolor(Xq{2}, Xq{3}, reshape(2*sqrt(cq_dtc), [numel(Xq{2}), numel(Xq{3})]));
    set(h,'EdgeColor','none');
    hold on;
    [X1u, X2u] = meshgrid(Xu{2}, Xu{3});
	X1u = X1u(:);
    X2u = X2u(:);
    [X1udtc, X2udtc] = meshgrid(ggpr_dtc.Xu{2}, ggpr_dtc.Xu{3});
	X1udtc = X1udtc(:);
    X2udtc = X2udtc(:);
    PH = plot(X1u, X2u, 'ms', ...
        X1udtc, X2udtc, 'gx', ...
        'MarkerSize', markerSize, 'LineWidth', lineWidth);
    title('DTC-GRID-GPR-95% Confidence', 'FontSize', titleFontSize);    
% 	legend(PH, {'Initial Sparse Inputs', 'Trained Sparse Inputs'}, 'Location', 'South');
    colorbar
    set(gca,'FontSize',axisFontSize );
    set(fig, 'color', 'w');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X, Xu, Xq, y, ysig] = demo_genData(KD, Nd, Md, Qd, period, sigma)

D = KD + 1;
ptsN =  linspace(-1, 1, Nd)';
% ptsM = linspace(-1, 1, Md)';
% ptsM = linspace(-1, 1, Md)' * 1.4; %Stretch it
ptsM = linspace(-1, 1, Md)' * .8; %Shrink it
% ptsQ =  linspace(-1, 1, Qd)';
ptsQ =  linspace(-1, 1, Qd)' * 2; %Expand

N = Nd^KD;
M = Md^KD;

X = cell(D, 1);
Xu = cell(D, 1);
Xq = cell(D, 1);
X{1} = 1;
Xu{1} = 1;
Xq{1} = 1;
for i = 2:D
    X{i} = ptsN;
    Xu{i} = ptsM;
    Xq{i} = ptsQ;
end

%Generate output y and ysig
y = zeros(N, 1);
for i = 1:KD
    y = y + kron(kron(ones(Nd^(i-1), 1), ptsN.^2), ones(Nd^(KD-i), 1));
end
y = sqrt(y)/KD;
y = cos(y * pi * period); %cos
% y = sin(y * pi * period) ./ (period * y); %Sinc
y(~isfinite(y)) = 1;
randn('state', 2013);
ysig = y + randn(N, 1)*sigma^2;

