Gridded-Gaussian Process Regression (GGPR) + Deterministic Training Conditional (DTC) Extension

Author: Yuancheng Luo, 1/2/2017

Description: 
Tensor GPR or exact GPR where inputs pairs are constrained to fall onto a grid are efficiently trained by exploting properties of Kronecker products. 
An extension to sparse grid GPR (Deterministic training conditional) where some or all of the input dimensions are sparse is included. 
Code tested on Matlab 2012a.

Features:
-GP inference for multiple M conditionally independent tasks (NxM observations) using common training inputs and covariance functions, different observations
-Robust back-propagation for GP hyperparameter training
-Symbolic toolbox integration for covariance functions

See demo scripts for usage examples:
demo_real_logmag.m: Interpolates log-magnitude HRTF spectral data over spherical-coordinates & frequency domain
demo_complex.m:     Interpolates complex HRTF data over spherical-coordinates & frequency domain
demo_synth.m:       Synthetic data

If you use this code, please consider citing

Yuancheng Luo and Ramani Duraiswami, "Fast Near-GRID Gaussian Process Regression", AISTATS 2013.