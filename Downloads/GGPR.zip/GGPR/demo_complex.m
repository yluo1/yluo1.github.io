%HRTF complex interpolation
function [ggpr_std, ggpr_dtc, yq, yq_dtc] = demo_complex(subj, binRange, isLeft)
addpath('covs');
addpath('utils');

if nargin < 1
    subj = 48;
end

if nargin < 2
    binRange = 1:129;
end

if nargin < 3
    isLeft = 1;
end

%Load HRTF data
%andre_r1_44100
if isa(subj, 'double') %from CIPIC
    fname = ['data/CIPIC_NBINSFFT_256_SUBJ_', num2str(subj), '.mat'];
else %Custom (output name will be custom...)
    fname = subj;
end
    
dat = load(fname);

if isLeft == 0
    Y = dat.YRight;
else
	Y = dat.YLeft;
end
%Compute min-phase
Y = fft(minPhaseHRIR_from_magHRTF(abs(Y)));
%Use only select frequency range
Y = Y(binRange, :);

[N1, N2]= size(Y);
Y = Y / max(abs(Y(:)));

%Y = log10(Y / max(Y(:)) );  %Full observations
%Subtract out mean
% meanY = mean(Y, 2);
% Y = bsxfun(@minus, Y, meanY);

%meanConstant = mean(Y(:));
%Y = Y - meanConstant;

%Set training samples
rand('state', 2355);
train_idx = {1:N1; randperm(N2)};
train_idx{2} = train_idx{2}(1:ceil(N2*(1/5))); %Train on subset
X = {1; dat.X; (1:N1)'}; %Full inputs (dummy, direction, frequency inputs), minor to major dimension ordering 

%Setup GRID-GPR structure
ggpr.D = 3;
ggpr.covs = {str2func('cov_sym_alpha'); ...
    str2func('cov_sym_matv3_2_chord'); ...
    str2func('cov_sym_ouspec')}; 
% ggpr.theta = {1; 1; [1; 1]}; %For gabor
ggpr.theta = {1; 1; 1};
ggpr.X = {X{1}; X{2}(train_idx{2}, :); X{3}(train_idx{1}); };
YTrain  = Y(train_idx{1}, train_idx{2});
ggpr.Y = YTrain(:);
ggpr.sigma = 0.01;  %prev .1
ggpr.maxiter = 50;
ggpr.asig = 0;
%ggpr.asig = 1.00001;
ggpr.a_fac = 1.1;  ggpr.a_start = .05;
%ggpr.meanConstant = meanConstant;

%Setup DTC-GPR
M = 100; %Number of inducing directions
ggpr.Xu = {X{1}; X{2}(train_idx{2}(1:M), :); X{3}(train_idx{1}) };
ggpr.Xuc = {1;[0, 0]; 1};   %1 = constrained (dummy variable and frequency), 0 = unconstrained (theta, phi direction)
% ggpr.Xu = {X{1}; X{2}(train_idx{2}(1:M), :); X{3}(train_idx{1}(1:5:end) ) };
% ggpr.Xuc = {1;[0, 0]; 0};   %1 = constrained (dummy variable and frequency), 0 = unconstrained (theta, phi direction)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%GRID-GPR
[ggpr_std] = std_call_ggpr(ggpr, {});
ggpr_std.maxiter = 1;
[tmp, yq] = std_call_ggpr(ggpr_std, X);
yq = abs(reshape(yq, [N1, N2]));

ggpr_std.theta{1}
ggpr_std.theta{2}
ggpr_std.theta{3}
std_sdr  = squeeze(10*log10(bsxfun(@times, 1 ./ sum(bsxfun(@minus, yq, abs(Y)).^2, 2), sum(abs(Y).^2, 2))));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%DTC-GRID-GP
ggpr.axu_fac = 1.025;
ggpr.axu_start = .01;
[ggpr_dtc] = dtc_call_ggpr(ggpr, {});
ggpr_dtc.maxiter = 1;
[tmp, yq_dtc] = dtc_call_ggpr(ggpr_dtc, X);
yq_dtc = abs(reshape(yq_dtc, [N1, N2]));
dtc_sdr  = squeeze(10*log10(bsxfun(@times, 1 ./ sum(bsxfun(@minus, yq_dtc, abs(Y)).^2, 2), sum(abs(Y).^2, 2))));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Spectral distrotion errors
std_sd = mean((sqrt(400 * sum((reshape(log10(abs(Y)), [N1, N2]) -  reshape(log10(abs(yq)), [N1, N2]) ).^2, 1) / N1 )))
dtc_sd = mean((sqrt(400 * sum((reshape(log10(abs(Y)), [N1, N2]) -  reshape(log10(abs(yq_dtc)), [N1, N2]) ).^2, 1) / N1 )))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Display
fontsize_label = 18;
fontsize_legend = 18;
fontsize_gca = 18;
fontsize_title = 20;
fig = figure('Units','normalized','Position',[0 0 1 1]);
subplot(1,2,1);     plot(1:size(std_sdr), std_sdr, 'ro-', 1:size(dtc_sdr), dtc_sdr, 'bd-', 'linewidth', 2);
lh = legend('STD-GRID-GPR', 'DTC-GRID-GPR', 'location', 'best');
title('Goodness-of-fit', 'FontSize', fontsize_title);
xlabel('Freq. Bin', 'FontSize', fontsize_label);
ylabel('Signal-to-Distortion Ratio', 'FontSize', fontsize_label);
axis tight;
set(gca,'FontSize', fontsize_gca );
set(lh, 'fontsize', fontsize_legend);

subplot(1,2,2);
plot(ggpr.Xu{2}(:, 2), pi/2 - ggpr.Xu{2}(:, 1),  'ms', ...
    ggpr_dtc.Xu{2}(:, 2), pi/2 - ggpr_dtc.Xu{2}(:, 1),  'kx', ...
    'markersize', 10, 'linewidth' ,2);
lh = legend('Initial', 'Trained', 'location', 'best');
title('Inducing Directions', 'FontSize', fontsize_title);
xlabel('Azimuth', 'FontSize', fontsize_label);
ylabel('Elevation', 'FontSize', fontsize_label);
axis([-pi, pi, -pi/2, pi/2]);
set(gca,'FontSize', fontsize_gca );
set(lh, 'fontsize', fontsize_legend);
set(fig, 'color', 'w');

%Save binaries
% if isLeft == 0
% 	ggprToBin(ggpr_std, 0, ['data/GGPR_CIPIC_', num2str(subj), '_RIGHT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange)) '.bin']);
%     ggprToBin(ggpr_dtc, 1, ['data/SGGPR_CIPIC_', num2str(subj), '_RIGHT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange)) '.bin']);
% else
% 	ggprToBin(ggpr_std, 0, ['data/GGPR_CIPIC_', num2str(subj),'_LEFT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange)) '.bin']);
%     ggprToBin(ggpr_dtc, 1, ['data/SGGPR_CIPIC_', num2str(subj), '_LEFT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange)) '.bin']);
% end

%Save GGPR structures
% if isa(subj, 'double')
%     if isLeft == 0
%         save(['data/GGPR_CIPIC_', num2str(subj), '_RIGHT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange))], 'ggpr_std', 'ggpr_dtc', 'X');
%     else
%         save(['data/GGPR_CIPIC_', num2str(subj), '_LEFT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange))], 'ggpr_std', 'ggpr_dtc', 'X');
%     end
% else
% 	if isLeft == 0
%         save(['data/CUSTOM', '_RIGHT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange))], 'ggpr_std', 'ggpr_dtc', 'X');
%     else
%         save(['data/CUSTOM', '_LEFT_', 'LMIN_', num2str(min(binRange)), '_LMAX_', num2str(max(binRange))], 'ggpr_std', 'ggpr_dtc', 'X');
%     end
% end


%Plot mecator project slice
f_bin_plot = 40;
clim = [0, 1];
figure;
subplot(2,2,1);
plotCustomFreqSingle(X{2}(:, 1), X{2}(:, 2), 'Reference', abs(Y(f_bin_plot, :)) , clim);
subplot(2,2,2);
plotCustomFreqSingle(X{2}(train_idx{2}, 1), X{2}(train_idx{2}, 2), 'Training Samples', abs(Y(f_bin_plot, train_idx{2})), clim);
subplot(2,2,3);
plotCustomFreqSingle(X{2}(:, 1), X{2}(:, 2), 'GP-STD Inference', abs(yq(f_bin_plot, :)), clim);
subplot(2,2,4);
plotCustomFreqSingle(X{2}(:, 1), X{2}(:, 2), 'DTC-STD Inference', abs(yq_dtc(f_bin_plot, :)), clim);
