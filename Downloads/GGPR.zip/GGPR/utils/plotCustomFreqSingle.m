
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plotCustomFreqSingle(theta, phi, title_name, Y, clim)
%Switch theta from 0 being top of head to 0 being equator
theta = pi/2 - theta;

%Compute meshgrid
x0 = linspace(min(phi), max(phi), 100);
y0 = linspace(min(theta), max(theta), 100);
[xi,yi] = meshgrid(x0, y0);

[M, N] = size(Y);

minY = min(Y(:));
maxY = max(Y(:));

plotSlice(phi, theta, x0, y0, xi, yi, Y, 'Azim.', 'Elev.', title_name);
if nargin < 5
    caxis([minY, maxY]);
else
    caxis(clim);
end
colorbar


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plotSlice(x, y, x0, y0, xi, yi, c, xlabelstring, ylabelstring, titlestring)

zi = griddata(x,y,c,xi,yi, 'nearest');
% zi = griddata(x,y,c,xi,yi, 'cubic');
h = sanePColor(x0(:)', y0(:)', zi);
colormap(pink);

xlabel(xlabelstring);
ylabel(ylabelstring);
title(titlestring);
