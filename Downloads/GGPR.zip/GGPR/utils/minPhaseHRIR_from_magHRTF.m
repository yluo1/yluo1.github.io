function mx = minPhaseHRIR_from_magHRTF(x)
%Input: x-HRTF [Nfreq, NDirs]
%Output: Min-phase HRIR

error(nargchk(1,1,nargin,'struct'));

% Check for valid input signal
[errid,errmsg] = chkinput(x);
if ~isempty(errmsg), error(errid,errmsg); end

n = size(x, 1);
% fftxabs = abs(fft(x));
fftxabs = abs(x);
if any(fftxabs == 0)
    error(generatemsgid('ZeroInFFT'),...
        'The Fourier transform of X contains zeros. Therefore, the real cepstrum of X does not exist.');
end
xhat = real(ifft(log(fftxabs)));

odd = fix(rem(n,2));
wn = [1; 2*ones((n+odd)/2-1,1) ; ones(1-rem(n,2),1); zeros((n+odd)/2-1,1)];
wn = repmat(wn, 1, size(x, 2));
yhat = real(ifft(exp(fft(wn.*xhat))));

mx = yhat;

%--------------------------------------------------------------------------
function [errid,errmsg] = chkinput(x)
% Check for valid input signal

errid = '';
errmsg = '';

if isempty(x) || issparse(x) || ~isreal(x),
    errid = generatemsgid('invalidInput');
    errmsg = 'The input signal X must be real.';
    return;
end
