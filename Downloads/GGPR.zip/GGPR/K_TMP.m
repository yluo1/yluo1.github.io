function Tout = K_TMP(C, T)
%Kronecker-tensor matrix product
%Input
%C: D-Cell array of m_i x mu_i matrices
%T: vector of N x M
%Output: kron(C)T

D = numel(C);
for i = 1:D
	[m1(i), m2(i)] = size(C{i});
end
n1 = prod(m1);
n2 = prod(m2);

[N, M] = size(T);
if N ~= n2    
    error('C, T dim mismatch');
end

Tout = zeros(n1, M);
for j = 1:M    
    N = n2;
    t = T(:, j);
    for i = D:-1:1
        t = reshape(t, m2(i), N/m2(i));
        t = C{i}*t;
        t = t.';
        t = t(:);
        N = length(t);
    end
    Tout(:, j) = t;
end