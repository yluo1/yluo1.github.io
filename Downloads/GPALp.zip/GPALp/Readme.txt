Gaussian Process Active-Learning for HRTFs Demo
Author: Yuancheng[Mike] Luo, yluo1@umd.edu

1. Open Matlab & put on headphones 

----------------------------------------
2a. Call REC_INTERFACE(name, max_iterQ, showDot): By default settings, you will be asked to localize 10 HRTFs each along 14 directions (7 on the horizontal and 7 on the vertical planes)

name is string of username

max_iterQ is number of HRTF queries to label per target direction

showDot 0:1 shows locations of target directions

Example: REC_INTERFACE('John Doe');

----------------------------------------
2b. (optional): Run REC2(U, max_iterQ, showDot) for target directions U

U is 1x2 matrix of target directions in elevation, azimuth
elevation: [pi/2, 0, -pi/2] = [north, hplane, south poles]
azimuth: [-pi,0,pi] = [left-back, nose, right-back] 

-----------------------------------------
3. On the azimuth-elevation pane, click on perceived sound-source direction of the SECOND sound-click

-----------------------------------------
4. Output file structure
userOut/<username>.mat	
var outH/MPlane contains

X: [*, 200] matrix of left (1:100), right (101:200) magnitude-HRTFs
Y: [*, 3] matrix of user reported directions over unit sphere
U: [*, 3] matrix of target directions over unit sphere
U_thetaPhi: [*, 2] matrix of target directions over spherical coordinates
GPR_Y{1}: [*] vector of -YU' 

If possible, send the output file to yluo1@umd.edu.
