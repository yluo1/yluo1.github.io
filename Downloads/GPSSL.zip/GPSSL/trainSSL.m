addpath(genpath('./GGPR'));

maxiter = 50;
trainN = 417;%100, 417, 1250
rand('state', 125);

%Load data
load('./dat/subj_1.mat');
[dx, dy, dz] = sph2cart(phi, pi/2-theta, 1);
trainY  = [dx, dy, dz];

%Extract features

%avg. mag features
trainX = abs(HRTF_L) ./ ((abs(HRTF_L) + abs(HRTF_R)));
trainX = trainX(1:100,:)';

%mag pair features
% trainX = [abs(HRTF_L(1:100,:)); abs(HRTF_R(1:100,:))];
% trainX = trainX' ./ max(trainX(:));

randSet = randperm(size(trainX,1));
randSet = randSet(1:trainN);

%Train GP model
ggpr = trainGGPR(trainX(randSet,:), trainY(randSet,:), maxiter);

%Test SSL
testX = trainX;
testY = testGGPR(testX, ggpr);

plotSSL(trainY,  trainY(randSet,:), testY);

%save GP model
save('out/ggpr_subj_1.mat', 'ggpr'); 
