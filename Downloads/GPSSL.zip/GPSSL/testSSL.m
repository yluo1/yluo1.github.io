addpath(genpath('./GGPR'));
load('out/ggpr_subj_1.mat');
load('dat/subj_1.mat');

NSec = 1; %number of seconds
Fs = 44100; %sample rate of source-signal
dirIdx = 1044; %direction index for theta(dirIdx), phi(dirIdx) of source-signal

%Cartesdian directions on unit sphere
[dx, dy, dz] = sph2cart(phi, pi/2-theta, 1);
truthY  = [dx, dy, dz];

%Generate WGN time-domain source signal
s = wgn(Fs*NSec, 1, 10);
s_L = conv(s, ifft(HRTF_L(:, dirIdx)));
s_R = conv(s, ifft(HRTF_R(:, dirIdx)));


%Short-time Fourier transforms
% S_L = abs(stft(s_L, 1000, 10, 199, Fs));
% S_R = abs(stft(s_R, 1000, 10, 199, Fs));

%Averaged STFT
S_L = mean(abs(stft(s_L, 100, 10, 199, Fs)),2);
S_R = mean(abs(stft(s_R, 100, 10, 199, Fs)), 2);


testX = ( S_L(1:100,:) ./ (S_L(1:100,:) +  S_R(1:100,:)))';
testY = testGGPR(testX, ggpr);


plotSSL(truthY(dirIdx,:),  ggpr.Y, testY);