function K = K_expand(K1)
D = numel(K1);
K = 1;
for i = 1:D
    K = kron(K, K1{i});
end