function [ggpr, yq, cq] = dtc_call_ggpr(ggpr, Xq)
%Conditionally independent Deterministic Conditional-Gridded-Gaussian Process Regression

%Input:
%ggpr structure: 
%REQUIRED
%ggpr.Y: [NxM] matrix of N = prod m_i observations over M tasks, 
%ggpr.X: [Dx1] cell-array of [n_i x p_i] matrices, 
%n_i is # of samples, p_i is # of predictor variables
%ggpr.Xu: [Dx1] cell-array of [nu_i x p_i] matrices of inducing inputs, 
%nu_i is # of inducing inputs
%ggpr.Xuc: [Dx1] cell-array of [1 x p_1] array of constraints,
%Xuc{2}(1) = 1 => Xu{2}(:, 1) are fixed
%ggpr.theta: [Dx1] cell-array of hyperparameters
%ggpr.sigma: [1x1] standard deviation
%ggpr.covs: [Dx1] cell-array of covariance functions
%ggpr.maxiter: Number of iterations to train theta

%OPTIONAL
%ggpr.t: [NxM] matrix of latest projections
%ggpr.lh [1x1] last log-marginal likelihood
%ggpr.asig: [1x1] learning rate 
%ggpr.a_sig_fac: [1x1] momentum
%ggpr.a_start: [1x1] learning rate 
%ggpr.a_fac: [1x1] momentum
%ggpr.axu_start: [1x1] learning rate 
%ggpr.axu_fac:  [1x1] momentum 
%ggpr.save_eigmats: 1 = save eigendecompositions, 0 = not (default)

%Xq: [Dx1] cell-array of [m_*i x p_i] matrices


if ~isfield(ggpr, 'axu_fac')
    ggpr.axu_fac = 1.2;
end
if ~isfield(ggpr, 'axu_start')
    ggpr.axu_start = .01;
end

if ~isfield(ggpr, 'asig')
    ggpr.asig = 0;
end
if ~isfield(ggpr, 'a_sig_fac')
    ggpr.a_sig_fac = 1.1;
end
if ~isfield(ggpr, 'a_fac')
    ggpr.a_fac = 1.2;
end
if ~isfield(ggpr, 'a_start')
    ggpr.a_start = .1;
end
if ~isfield(ggpr, 'full_cq')
    ggpr.full_cq = 0;
end
if ~isfield(ggpr, 'save_eigmats')
    ggpr.save_eigmats = 0;
end


if nargout <= 2
    [ggpr, yq] = dtc_gpr_rprop(ggpr, Xq);
elseif nargout == 3
    [ggpr, yq, cq] = dtc_gpr_rprop(ggpr, Xq);
end

function[ggpr, yq, cq]  = dtc_gpr_rprop(ggpr, Xq)
%Deterministic Training Conditional-GPR-Resilient backpropagation
Y = ggpr.Y;
X = ggpr.X;
Xu = ggpr.Xu;
Xuc = ggpr.Xuc;
theta = ggpr.theta;
sigma = ggpr.sigma;
maxiter =  ggpr.maxiter;
covs =  ggpr.covs;
asig = ggpr.asig;
a_sig_fac = ggpr.a_sig_fac;
a_fac = ggpr.a_fac;
a_start = ggpr.a_start;
axu_start = ggpr.axu_start;
axu_fac = ggpr.axu_fac;
full_cq = ggpr.full_cq;
save_eigmats = ggpr.save_eigmats;

%Initialization
D = length(X);
if length(theta) ~= D
    error('dim: theta, X mismatch');
end
if ~isempty(Xq)
    if length(Xq) ~= D
        error('dim: Xq, X mismatch');
    end
end

ptheta = zeros(D, 1);
mtheta = zeros(D, 1);
mup = zeros(D, 1);
mu = zeros(D, 1);
for i = 1:D
    [mtheta(i), ptheta(i)] = size(theta{i});
    [mu(i), mup(i)] = size(Xu{i});
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Paramter training: Rprop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic

%Scale
a = theta;
axu = Xu;
pdlh_p = theta;
pdlhxu_p = Xu;
amax = inf; %Default
for i = 1:D
    for k = 1:ptheta(i)
        for j = 1:mtheta(i)
            pdlh_p{i}(j, k) = 0;
            a{i}(j, k) = a_start;
        end
    end
    for p = 1:mup(i)
        for j = 1:mu(i)
            pdlhxu_p{i}(p,j) = 0;
            axu{i}(p,j) = axu_start;
        end
    end
end
pdlhsig_p = 0;

for iter = 1:maxiter
    %Compute t, negative log-likelihood, and partial derivatives
    [lh, pdlh, pdlhsig, pdlhxu, eigmats] = dtc_compute(Y, X, Xu, Xuc, theta, sigma, covs);
        
    if iter < maxiter
        %Update hyperparameters
        for i = 1:D
            for k = 1:ptheta(i)
                for j = 1:mtheta(i)
                    pdlh{i}(j, k) = real(pdlh{i}(j, k));
                    if pdlh{i}(j, k) * pdlh_p{i}(j, k) > 0
                        if a{i}(j, k) * a_fac <= amax
                            a{i}(j, k) = a{i}(j, k) * a_fac;
                        end
                    elseif pdlh{i}(j, k) * pdlh_p{i}(j, k) < 0
                        a{i}(j, k) = a{i}(j, k) * .5;
                        pdlh{i}(j, k) = 0;
                    end
                    theta{i}(j, k) = theta{i}(j, k) - a{i}(j, k) * sign(pdlh{i}(j, k));
                end
            end
        end
        pdlh_p = pdlh;
        
        %Update sparse inputs
        for i = 1:D
            if ~isempty(find(Xuc{i} == 0, 1))
                for p = 1:mup(i);
                    if Xuc{i}(p) == 0
                        for j = 1:mu(i)
                            pdlhxu{i}(p,j) = real(pdlhxu{i}(p,j));
                            if pdlhxu{i}(p,j) * pdlhxu_p{i}(p,j) > 0 %Same direction
                                if axu{i}(p,j) * axu_fac <= amax
                                    axu{i}(p,j) = axu{i}(p,j) * axu_fac;
                                end
                            elseif pdlhxu{i}(p,j) * pdlhxu_p{i}(p,j) < 0 %Overshot
                                axu{i}(p,j) = axu{i}(p,j) * .5;
                                pdlhxu_p{i}(p,j) = 0;
                            end
                            Xu{i}(j,p) = Xu{i}(j,p) - axu{i}(p,j) * sign(pdlhxu{i}(p,j));
                        end
                    end
                end
            end
        end
        pdlhxu_p = pdlhxu;
        
        if pdlhsig * pdlhsig_p > 0
            asig = asig * a_sig_fac;
        elseif pdlhsig * pdlhsig_p < 0
            asig = asig * .5;
            pdlhsig = 0;
        end
        sigma = sigma - asig * sign(pdlhsig);
        pdlhsig_p = pdlhsig;
    end
    %     celldisp(theta)
    % 	sigma
    fprintf(1, 'rprop iter %d, log-marginal likelihood %f \r', iter, -lh);
end
if ~exist('eigmats', 'var')
    if isfield(ggpr, 'eigmats')
        eigmats = ggpr.eigmats;
    else
        error('No eigmats');
    end
end
if maxiter == 0 %Use latest projections t
    t = ggpr.t;
    lh = ggpr.lh;
else
    t = eigmats.t;
end
ttime = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inference
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
yq = {};
cq = {};

if ~isempty(Xq)
    %Predicted Mean
    Kqu = cell(D, 1);
    for i = 1:D
        Kqu{i} = covs{i}(Xq{i}, Xu{i}, theta{i});
    end
	yq = K_TMP(Kqu, t);

    %Predicted variance
    if nargout >= 3
        diagKqq = 1;
        diagQqq = 1;
        KquOmega = cell(D, 1);
        for i = 1:D
            Kuu = covs{i}(Xu{i}, Xu{i}, theta{i});
            Kqq = covs{i}(Xq{i}, Xq{i}, theta{i});
            Qqq = Kqu{i} * (Kuu \ Kqu{i}');
            diagKqq = K_a_b(diagKqq, diag(Kqq));
            diagQqq = K_a_b(diagQqq, diag(Qqq));
            KquOmega{i} = Kqu{i} * eigmats.Omega{i};
        end
        diagKquSigmaKuq = sigma^2 * K_diag_KzKT(KquOmega, eigmats.zbinv);
        cq = diagKqq - diagQqq + diagKquSigmaKuq;
    end
end
ptime = toc;

ggpr.theta = theta;
ggpr.sigma = sigma;
ggpr.lh = lh;
ggpr.ttime = ttime;
ggpr.ptime = ptime;
ggpr.t = t;
ggpr.Xu = Xu;
if save_eigmats
    ggpr.eigmats = eigmats;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lh, pdlh, pdlhsig, pdlhxu, eigmats] = dtc_compute(Y, X, Xu, Xuc, theta, sigma, covs)
%Input:
%y: N x 1 vector of observations
%X: D-cell array of variables m_i x p
%Xu: D-cell array of variables mu_i x p
%Xuc: D-cell array of flags 1 x p: 0 = unconstrained (learn), 1 = fixed
%theta: D-cell array of theta_i hyperparameters
%covs: D-cell array of covariance functions

%Output:
%lh: negative log-marignal-liklihood
%pdlh: D-cell array of partial lh w.r.t. each hyperparameter
%pdlhxu: D-cell array of partial lh w.r.t. each inducing location
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DIAG_TRUTH = 1; %Comment out to disable ground-truth debugging

%Generate covariance and partial covariance matrix decompositions
D = numel(X); %Number of dimensions
Kuu = cell(D, 1);
Kuf = cell(D, 1);
Kfu = cell(D, 1);

%Derivative matrices
dKuu = cell(D, 1);
dKuf = cell(D, 1);
dKXuu = cell(D, 1);
dKXuf = cell(D, 1);

%Others
Omega = cell(D, 1);
OmegaT = cell(D, 1);
KuuInvKufKfuOmega = cell(D, 1);
KfuOmega = cell(D, 1);
diagOmegaTKufKfuOmega = cell(D, 1);
ZFull = 1;
ZBFull = 1;

ptheta = zeros(D, 1);
mtheta = zeros(D, 1);
mu = zeros(D, 1);
mup = zeros(D, 1);
m = zeros(D, 1);
for i = 1:D
    %Get matrix dimensions
    [mtheta(i), ptheta(i)] = size(theta{i});
    m(i) = size(X{i}, 1);
    [mu(i), mup(i)] = size(Xu{i});
    
    %Compute covariances
    if ~isempty(find(Xuc{i} == 0, 1)) %For inducing inputs
        [Kuu{i}, dKuu{i}, dKXuu{i}] = covs{i}(Xu{i}, Xu{i}, theta{i});
        [Kuf{i}, dKuf{i}, dKXuf{i}] = covs{i}(Xu{i}, X{i}, theta{i});
    else
        [Kuu{i}, dKuu{i}] = covs{i}(Xu{i}, Xu{i}, theta{i});
        [Kuf{i}, dKuf{i}] = covs{i}(Xu{i}, X{i}, theta{i});
    end
    Kfu{i} = Kuf{i}';
    
    %Compute eigendecompositions
    [U, Z] = eig(Kuu{i});
    ZFull = K_a_b(ZFull, diag(Z));
    ZinvSqrt = diag(1 ./ sqrt(diag(Z)));
    [UB, ZB] =  eig(ZinvSqrt * U' * Kuf{i} * Kfu{i} * U * ZinvSqrt);
    Omega{i} = U * ZinvSqrt * UB;
    OmegaT{i} = Omega{i}';
    ZBFull = K_a_b(ZBFull, diag(ZB));
    KfuOmega{i} = Kfu{i} * Omega{i} ;
    KuuInvKufKfuOmega{i} = Kuu{i} \ (Kuf{i}*KfuOmega{i});
    diagOmegaTKufKfuOmega{i} = diag(OmegaT{i} * Kuf{i} * KfuOmega{i});
end
N = prod(m);
M = prod(mu);

%Compute t = Sigma_Kuf_y
Kuf_y = K_TMP(Kuf, Y);
zinv = 1 ./ ZFull;
zbinv = (1 ./ (ZBFull + sigma^2));
t = K_TMP(Omega, bsxfun(@times, K_TMP(OmegaT, Kuf_y), zbinv));

%%%%DIAGNOSTIC TRUTH%%%
if exist('DIAG_TRUTH', 'var')
    SIGMA = inv(sigma^-2 * K_expand(K_TP(Kuf, Kfu)) + K_expand(Kuu));
    PHI = sigma^-2 * SIGMA;
    T = PHI * Kuf_y;
    disp('DIAG_TRUTH: t');
    norm(T-t)
    pause;
end

%Useful outputs
eigmats.Omega = Omega;
eigmats.zbinv = zbinv;
eigmats.zinv = zinv;
eigmats.t = t;

%Compute negative log-marginal likelihood
Kfu_t = K_TMP(Kfu, t);
lh  = 1/2 * ((N-M)*log(sigma^2) - sum(log(zbinv)) - sum(log(zinv))  ...
    + sigma^-2 * sum(Y(:) .* (Y(:) - Kfu_t(:))) ...
    + N * log(2*pi));

%%%%DIAGNOSTIC TRUTH%%%
if exist('DIAG_TRUTH', 'var')
    KFU = K_expand(Kfu);
    KUF = KFU';
    KUU = K_expand(Kuu);
    KFU_T = KFU * T;
    LH  = 1/2 * ((N-M)*log(sigma^2) - log(det(PHI)) ...
        + sigma^-2 * trace(Y' * (Y - KFU_T)) ...
        + N * log(2*pi));
    disp('DIAG_TRUTH: -LH');
    norm(LH - lh)
    pause;
end


%Compute gradients
tmp1_diagOmegaTKufKfuOmega = diagOmegaTKufKfuOmega;
tmp2_diagOmegaTKufKfuOmega = diagOmegaTKufKfuOmega;
tmp_dKfu = Kfu;
tmp_dKuu = Kuu;
pdlh = cell(D, 1);
pdlhxu = cell(D, 1);
for i = 1:D
    pdlh{i} = zeros(mtheta(i), ptheta(i));
    for k = 1:ptheta(i) %Iterate over hyperparameters
        for j = 1:mtheta(i)
            tmp1_diagOmegaTKufKfuOmega{i} = diag(OmegaT{i} * dKuf{i}{j, k} * KfuOmega{i});
            tmp2_diagOmegaTKufKfuOmega{i} = diag(OmegaT{i} * dKuu{i}{j, k} * KuuInvKufKfuOmega{i});
            tmp_dKfu{i} = dKuf{i}{j, k}';
            tmp_dKuu{i} = dKuu{i}{j, k};
            
            t1 = K_expand(tmp1_diagOmegaTKufKfuOmega);
            t2 = K_expand(tmp2_diagOmegaTKufKfuOmega);
            tr = zbinv' * (2 * t1 - t2);
            
            tdKuut = K_TMP(tmp_dKuu, t);	tdKuut = sum(t(:) .* tdKuut(:));
            ydkfut = K_TMP(tmp_dKfu, t);    ydkfut = sum(Y(:) .* ydkfut(:));
            tKfudKfut = K_TMP(tmp_dKfu, t); tKfudKfut = sum(Kfu_t(:) .* tKfudKfut(:));
            dyqinvq = tdKuut - 2 * sigma^-2 * (ydkfut - tKfudKfut);
            
            pdlh{i}(j, k) = 1/2 * (tr + dyqinvq);
            
            %%%%DIAGNOSTIC TRUTH%%%
            if exist('DIAG_TRUTH', 'var')
                DKUU = K_expand(tmp_dKuu);
                DKFU = K_expand(tmp_dKfu);
                T1 = 2 * trace(DKFU' * KFU * PHI);
                T2 = trace( DKUU * (KUU \ (KUF * KFU * PHI)));
                TR = T1 - T2;
                disp('DIAG_TRUTH: Gradient Theta tr');
                norm(TR - tr)
                
                DYQINVQ1    = trace(Y' * KFU * PHI * DKUU * PHI' * KUF * Y ...
                    - 2 * sigma^-2 * Y' * (eye(N) - KFU*PHI*KUF) * DKFU * PHI * KUF * Y);
                DYQINVQ2    = trace(T' * K_expand(tmp_dKuu) * t ...
                    - 2*sigma^-2*(Y'* DKFU * t - t' * KUF * DKFU * t));
                
                disp('DIAG_TRUTH: Gradient Theta dyqinvq');
                norm(DYQINVQ1 - DYQINVQ2)
                norm(dyqinvq -  DYQINVQ1)
                pause;
            end
        end
    end
    
    if ~isempty(find(Xuc{i} == 0, 1))
        pdlhxu{i} = zeros(mup(i), mu(i));
        for p = 1:mup(i) %Iterate over inducing inputs
            for j = 1:mu(i)
                curr_dKXuu = zeros(size(dKXuu{i}{p, 1}));
                curr_dKXuu(j,:) =  dKXuu{i}{p, 1}(j, :);
                curr_dKXuu(:,j) =  dKXuu{i}{p, 1}(:, j);
                curr_dKXuf =  zeros(size(dKXuf{i}{p, 1}));
                curr_dKXuf(j,:) =  dKXuf{i}{p, 1}(j, :);
                
                tmp1_diagOmegaTKufKfuOmega{i} = diag(OmegaT{i} * curr_dKXuf * KfuOmega{i});
                tmp2_diagOmegaTKufKfuOmega{i} = diag(OmegaT{i} * curr_dKXuu * KuuInvKufKfuOmega{i});
                tmp_dKfu{i} = curr_dKXuf';
                tmp_dKuu{i} = curr_dKXuu;
                
                t1 = K_expand(tmp1_diagOmegaTKufKfuOmega);
                t2 = K_expand(tmp2_diagOmegaTKufKfuOmega);
                tr = zbinv' * (2 * t1 - t2);
            
                tdKuut = K_TMP(tmp_dKuu, t);	tdKuut = sum(t(:) .* tdKuut(:));
                ydkfut = K_TMP(tmp_dKfu, t);    ydkfut = sum(Y(:) .* ydkfut(:));
                tKfudKfut = K_TMP(tmp_dKfu, t); tKfudKfut = sum(Kfu_t(:) .* tKfudKfut(:));
                dyqinvq = tdKuut - 2 * sigma^-2 * (ydkfut - tKfudKfut);
                
                pdlhxu{i}(p, j) = 1/2 * (tr + dyqinvq);
                
                %%%%DIAGNOSTIC TRUTH%%%
                if exist('DIAG_TRUTH', 'var')
                    DKUU = K_expand(tmp_dKuu);
                    DKFU = K_expand(tmp_dKfu);
                    T1 = 2 * trace(DKFU' * KFU * PHI);
                    T2 = trace( DKUU * (KUU \ (KUF * KFU * PHI)));
                    TR = T1 - T2;
                    disp('DIAG_TRUTH: Gradient Xu tr');
                    norm(TR - tr)
                    
                    DYQINVQ1    = trace(Y' * KFU * PHI * DKUU * PHI' * KUF * Y ...
                        - 2 * sigma^-2 * Y' * (eye(N) - KFU*PHI*KUF) * DKFU * PHI * KUF * Y);
                    DYQINVQ2    = trace(T' * K_expand(tmp_dKuu) * t ...
                        - 2*sigma^-2*(Y'* DKFU * t - t' * KUF * DKFU * t));
                    
                    disp('DIAG_TRUTH: Gradient Xu dyqinvq');
                    norm(DYQINVQ1 - DYQINVQ2)
                    norm(dyqinvq -  DYQINVQ1)
                    pause;
                end
                
            end
        end
    end
    %Reset diagonals
    tmp1_diagOmegaTKufKfuOmega{i} = diagOmegaTKufKfuOmega{i};
    tmp2_diagOmegaTKufKfuOmega{i} = diagOmegaTKufKfuOmega{i};
    %Reset matrices
    tmp_dKfu{i} = Kfu{i};
    tmp_dKuu{i} = Kuu{i};
end

%Compute pdlhsig
pdlhsig = 0;
