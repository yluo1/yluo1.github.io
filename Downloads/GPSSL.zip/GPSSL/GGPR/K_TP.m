function K = K_TP(K1, K2)
D = numel(K1);
if numel(K2) ~= D
    error('KTP D mismatch');
end
K = cell(D, 1);
for i = 1:D
    K{i} = K1{i}*K2{i};
end