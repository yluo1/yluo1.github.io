Gridded-Gaussian Process Regression (GPR) + Deterministic Conditional (DTC) Extension

Author: Yuancheng Luo, 10/10/2013

Description: Exact GPR where inputs pairs are constrained to fall onto a grid, i.e. set of inputs expressible as cartesian outer-products => Gram matrix expressible as Kronecker products. DTC extension supports gridded inducing inputs (sparsity along some or all input dimensions). Code tested on Matlab 2010a.

Features:
-GP inference for multiple M conditionally independent tasks (NxM observations) from common training inputs and covariance functions
-Robust back-propagation for GP hyperparameter training
-Symbolic toolbox integration for covariance functions

See demo_real.m and demo_synth.m for usage

If you use this code, please consider citing

Yuancheng Luo and Ramani Duraiswami, �Fast Near-GRID Gaussian Process Regression�, AISTATS 2013.

Enjoy!
