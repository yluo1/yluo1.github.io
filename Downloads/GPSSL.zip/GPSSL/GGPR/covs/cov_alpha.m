function [C, dC] = cov_alpha(x1, x2, theta)
%Alpha
%Input
%x: 1 x 1
%theta: 1 x 1

%Output
%C: 1 x 1
%dC: 1-cell array of 1 x 1

%Covariance 
%Cov(dx) = alpha^2

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_alpha: p1, p2 mismatch'); 
end

mtheta = length(theta);
if mtheta ~= 1
   error('cov_alpha mtheta ~= 1'); 
end

alpha = theta(1);
C = ones(m1, m2)*alpha^2;

if nargout > 1
    dC = cell(1);
    dC{1} = ones(m1, m2)*2*alpha;
end
