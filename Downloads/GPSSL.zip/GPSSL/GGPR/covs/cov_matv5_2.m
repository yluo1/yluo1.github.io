function [C, dC] = cov_matv5_2(x1, x2, theta)
%Matern v=5/2
%Input
%x: m_i x mtheta
%theta: mtheta x 1

%Output
%C: m_i x m_i
%dC: mtheta-cell array of m_i x m_i

%Covariance 
%Cov(dx) = (1+sqrt(5)r/ell + 5r^2/(3ell^2))exp(-sqrt(5)r/ell)
[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_matv5_2: p1, p2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta ~= p
   error('cov_matv5_2 mtheta, x dim mismatch'); 
end

ell = theta';

C = zeros(m1, m2);
D = zeros(m1, m2);
if nargout > 1
    dC = cell(mtheta, 1);
    for j = 1:mtheta
        dC{j} = zeros(m1, m2);
    end
end

for i = 1:m2
    r = abs(bsxfun(@minus, x1, x2(i,:)));
    s1 = bsxfun(@rdivide, sqrt(5)*r, ell);
    s2 = bsxfun(@rdivide, 5*r.^2, 3*ell.^2);    
    s3 =  exp(-sum(s1, 2));
    C(:,i) = prod(1 + s1 + s2, 2);
    D(:,i) = s3;

    if nargout > 1
        for j = 1:mtheta
            dC{j}(:, i) = 5/3 * r(:, j).^2 / (ell(j)^3) .* (1+sqrt(5)*r(:,j) / ell(j)) .* (C(:,i) ./ (1+s1(:,j) + s2(:,j))) ;
        end
    end
end
C = C .* D;
if nargout > 1
    for j = 1:mtheta
        dC{j} = dC{j} .* D;
    end
end

    
