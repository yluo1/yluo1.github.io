function [C, dC] = cov_dotfc(x1, x2, theta)
%Dot-product full-covariance cholesky
%Input
%x: m_i x p
%theta: (p^2+p)/2 x 1

%Output
%C: m_i x m_i
%dC: (p^2+p)/2-cell array of m_i x m_i

%Covariance 
%Cov(x1,x2) = (x1'*Ut*U*x2).^pp where U is upper triangular

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2
	error('cov_dotfc: p1, p2 mismatch'); 
end
p = p1;
pp = 1;

mtheta = length(theta);

if mtheta ~=  (p^2+p)/2
   error('cov_dotfc: mtheta, (p^2+p)/2 mismatch'); 
end

%Produce upper triangular U 
ell = triu(ones(p));
ell = reshape(ell, p^2, 1);
lidx = find(ell == 1);
clidx = ceil(lidx / p);
rlidx = lidx - (clidx-1)*p;

% U = eye(p);
U = zeros(p^2, 1);
U(lidx) = theta;
U = reshape(U, p, p);
L = U';

x2t = x2';
C = (x1*L*U*x2t).^pp;

if nargout > 1
	dC = cell(mtheta, 1);
    for i = 1:mtheta
        dU = zeros(p);
        dU(rlidx(i), clidx(i)) = 1;
        dC{i} = pp * C.^(pp-1) .* (x1 * (L*dU + dU'*U) * x2t);
    end
end

