function [C, dC_dtheta, dC_dx1] = cov_sym_matv5_2_chord(x1, x2, theta)
%Matern v=3/2 covariance for chordial distance
%Input
%x: m_i x 2 (elev, azim)
%theta: 1 x 1

%Output
%C: m_i x m_i
%dC: 1-cell array of m_i x m_i

%Covariance 
%Cov(Ch) = (1+sqrt(5)Ch/ell + 5Ch^2/(3ell^2))exp(-sqrt(5)Ch/ell)
%Ch = 2Rsqrt(sin^2((elev2-elev1)/2) + sin(elev1)sin(elev2)sin^2((azim1-azim2)/2))

[m1, p1] = size(x1);
[m2, p2] = size(x2);
if p1 ~= p2 && p1 ~= 2
	error('cov_matv5_2_chord: p1, p2, 2 mismatch'); 
end
p = p1;

mtheta = length(theta);
if mtheta ~= 1
   error('cov_matv5_2_chord mtheta dim mismatch'); 
end

persistent s_C_matv5_2_chord s_dC_dtheta_matv5_2_chord s_dC_dx1_e1_matv5_2_chord s_dC_dx1_a1_matv5_2_chord;

syms s_e1 s_a1 s_e2 s_a2 s_theta;
ndx1 = 2;

if isempty(s_C_matv5_2_chord) 
    R = 1;
    s_ch = 2*R*sqrt(sin((s_e2-s_e1)/2).^2 + sin(s_e1).*sin(s_e2).*sin((s_a1-s_a2)/2).^2); 
	s_C_matv5_2_chord = simplify((1+sqrt(5) .* s_ch ./ s_theta + 5 .* s_ch.^2 / (3*s_theta.^2) ) * exp(-(sqrt(5) .* s_ch ./ s_theta ) ));
    s_C_matv5_2_chord = matlabFunction(s_C_matv5_2_chord, 'vars', [s_e1, s_a1, s_e2, s_a2, s_theta]); 
    
    %Derivative w.r.t. theta
    s_dC_dtheta_matv5_2_chord = simplify(diff(s_C_matv5_2_chord, s_theta));
    s_dC_dtheta_matv5_2_chord = matlabFunction(s_dC_dtheta_matv5_2_chord, 'vars', [s_e1, s_a1, s_e2, s_a2, s_theta]); 
    
    %Derivative w.r.t. elevation and azimuth
    s_dC_dx1_e1_matv5_2_chord = cell(ndx1, 1);
    s_dC_dx1_a1_matv5_2_chord = cell(ndx1, 1);
    for i = 1:ndx1
        if i == 1
            s_dC_dx1_e1_matv5_2_chord{i} = simplify(diff(s_C_matv5_2_chord, s_e1));
            s_dC_dx1_a1_matv5_2_chord{i} = simplify(diff(s_C_matv5_2_chord, s_a1));
        else
            s_dC_dx1_e1_matv5_2_chord{i} = simplify(diff(s_dC_dx1_e1_matv5_2_chord{i-1}, s_e1));
            s_dC_dx1_a1_matv5_2_chord{i} = simplify(diff(s_dC_dx1_a1_matv5_2_chord{i-1}, s_a1));            
        end
    end

    for i = 1:ndx1
        s_dC_dx1_e1_matv5_2_chord{i} = matlabFunction(s_dC_dx1_e1_matv5_2_chord{i}, 'vars', [s_e1, s_a1, s_e2, s_a2, s_theta]);
        s_dC_dx1_a1_matv5_2_chord{i} = matlabFunction(s_dC_dx1_a1_matv5_2_chord{i}, 'vars', [s_e1, s_a1, s_e2, s_a2, s_theta]);
    end
end
   
e1_s = repmat(x1(:,1), 1, m2);
a1_s = repmat(x1(:,2), 1, m2);
e2_s = repmat(x2(:,1)', m1, 1);
a2_s = repmat(x2(:,2)', m1, 1);
theta_s = theta(1) * ones(m1, m2);

C = s_C_matv5_2_chord(e1_s, a1_s, e2_s, a2_s, theta_s);

if nargout >= 2
    dC_dtheta = cell(1);
    dC_dtheta{1} = s_dC_dtheta_matv5_2_chord(e1_s, a1_s, e2_s, a2_s, theta_s);
end

if nargout >= 3
	dC_dx1 = cell(2, ndx1);
    for i = 1:ndx1
        dC_dx1{1, i} = s_dC_dx1_e1_matv5_2_chord{i}(e1_s, a1_s, e2_s, a2_s, theta_s);
        dC_dx1{2, i} = s_dC_dx1_a1_matv5_2_chord{i}(e1_s, a1_s, e2_s, a2_s, theta_s);
    end
end


