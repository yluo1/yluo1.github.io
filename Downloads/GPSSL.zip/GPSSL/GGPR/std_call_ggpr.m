function [ggpr, yq, cq] = std_call_ggpr(ggpr, Xq)
%Conditionally independent Gridded-Gaussian Process Regression:
%Covariance matrix: C = C{1} kron C{2} ... kron ... C{D} where C_i = K(X{i}, X{i}). 
%Observations Y: [NxM] matrix of N observations for M tasks
%Projections t: [NxM] matrix of (C+sigma^2I)^-1 Y
%Inference: K(X*, X) t

%Input:
%ggpr structure: 
%REQUIRED
%ggpr.Y: [NxM] matrix of N = prod m_i observations over M tasks, 
%ggpr.X: [Dx1] cell-array of [n_i x p_i] matrices, 
%n_i is # of samples, p_i is # of predictor variables
%ggpr.theta: [Dx1] cell-array of hyperparameters
%ggpr.sigma: [1x1] standard deviation
%ggpr.covs: [Dx1] cell-array of covariance functions
%ggpr.maxiter: Number of iterations to train theta

%OPTIONAL
%ggpr.t: [NxM] matrix of latest projections
%ggpr.lh [1x1] last log-marginal likelihood
%ggpr.asig: [1x1] learning rate 
%ggpr.a_sig_fac: [1x1] momentum
%ggpr.a_start: [1x1] learning rate 
%ggpr.a_fac: [1x1] momentum
%ggpr.axu_start: [1x1] learning rate 
%ggpr.axu_fac:  [1x1] momentum 
%ggpr.full_cq: 1 = use full posterior covariance, 0 = not (default)
%ggpr.save_eigmats: 1 = save eigendecompositions, 0 = not (default)

%Xq: [Dx1] cell-array of [m_*i x p_i] matrices


if ~isfield(ggpr, 'asig')
    ggpr.asig = 0;
end
if ~isfield(ggpr, 'a_sig_fac')
    ggpr.a_sig_fac = 1.1;
end
if ~isfield(ggpr, 'a_fac')
    ggpr.a_fac = 1.2;
end
if ~isfield(ggpr, 'a_start')
    ggpr.a_start = .1;
end
if ~isfield(ggpr, 'full_cq')
    ggpr.full_cq = 0;
end
if ~isfield(ggpr, 'save_eigmats')
    ggpr.save_eigmats = 0;
end

if nargout <= 2
    [ggpr, yq] = std_gpr_rprop(ggpr, Xq);
elseif nargout == 3
    [ggpr, yq, cq] = std_gpr_rprop(ggpr, Xq);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ggpr, yq, cq]  = std_gpr_rprop(ggpr, Xq)
%GPR-Resilient backpropagation
Y = ggpr.Y;
X = ggpr.X;
theta = ggpr.theta;
sigma = ggpr.sigma;
maxiter =  ggpr.maxiter;
covs =  ggpr.covs;
asig = ggpr.asig;
a_sig_fac = ggpr.a_sig_fac;
a_fac = ggpr.a_fac;
a_start = ggpr.a_start;
full_cq = ggpr.full_cq;
save_eigmats = ggpr.save_eigmats;

%Initialization
D = length(X);
if length(theta) ~= D
    error('dim: theta, X mismatch');
end
if ~isempty(Xq)
    if length(Xq) ~= D
        error('dim: Xq, X mismatch');
    end
end

ptheta = zeros(D, 1);
mtheta = zeros(D, 1);
for i = 1:D
    [mtheta(i), ptheta(i)] = size(theta{i});
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Hyper-paramter training: Rprop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
%Initial parameters
a = theta;
pdlh_p = theta;
amax = inf;
for i = 1:D
    for k = 1:ptheta(i)
        for j = 1:mtheta(i)
            pdlh_p{i}(j, k) = 0;
            a{i}(j, k) = a_start;
        end
    end
end
pdlhsig_p = 0;

for iter = 1:maxiter
    %Compute t, negative log-marginal likelihood, and partial derivatives
    [lh, pdlh, pdlhsig, eigmats] = std_compute(Y, X, theta, sigma, covs);
       
    if iter < maxiter
        %Update hyperparameters
        for i = 1:D
            for k = 1:ptheta(i)
                for j = 1:mtheta(i)
                    pdlh{i}(j, k) = real(pdlh{i}(j, k));
                    if pdlh{i}(j, k) * pdlh_p{i}(j, k) > 0
                        if a{i}(j, k) * a_fac <= amax
                            a{i}(j, k) = a{i}(j, k) * a_fac;
                        end
                    elseif pdlh{i}(j, k) * pdlh_p{i}(j, k) < 0
                        a{i}(j, k) = a{i}(j, k) * .5;
                        pdlh{i}(j, k) = 0;
                    end
                    theta{i}(j, k) = theta{i}(j, k) - a{i}(j, k) * sign(pdlh{i}(j, k));
                end
            end
        end
        pdlh_p = pdlh;
        
        if pdlhsig * pdlhsig_p > 0
            asig = asig * a_sig_fac;
        elseif pdlhsig * pdlhsig_p < 0
            asig = asig * .5;
            pdlhsig = 0;
        end
        sigma = sigma - asig * sign(pdlhsig);
        pdlhsig_p = pdlhsig;
        
    end
    %     celldisp(theta)
    %     sigma
    fprintf(1, 'rprop iter %d, log-marginal likelihood %f \r', iter, -lh);
end
if ~exist('eigmats', 'var')
    if isfield(ggpr, 'eigmats')
        eigmats = ggpr.eigmats;
    else
        error('No eigmats');
    end
end
if maxiter == 0 %Use latest projections t
    t = ggpr.t;
    lh = ggpr.lh;
else
    t = eigmats.t;
end
ttime = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inference
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
yq = {};
cq = {};

if ~isempty(Xq)
    Kqf = cell(D, 1);
    for i = 1:D
        Kqf{i} = covs{i}(Xq{i}, X{i}, theta{i});
    end
    %Predicted Mean
    yq = K_TMP(Kqf, t);
    
    %Predicted covariances
    if nargout >= 3
        U = eigmats.U;
        zinv = eigmats.zinv;
        if full_cq %Full posterior covariance
            cq.Kqq = cell(D, 1);
            cq.KqfU = cell(D, 1);
            cq.UKfq = cell(D, 1);
            cq.zinv = zinv;
            for i = 1:D
                cq.Kqq{i} = covs{i}(Xq{i}, Xq{i}, theta{i});
                cq.KqfU{i} = Kqf{i} * U{i};
                cq.KUfq{i} = cq.KqfU{i}';
            end
        else %Diagonal posterior covariance
            diagKqq = 1;
            KqfU = cell(D, 1);
            for i = 1:D
                %For unconstrained covariance function
                %                  Kqq = covs{i}(Xq{i}, Xq{i}, theta{i});
                %                  diagKqq = K_a_b(diagKqq, diag(Kqq));
                %For stationary covariances
                Kqq = covs{i}(Xq{i}(1,:), Xq{i}(1,:), theta{i});
                diagKqq = K_a_b(diagKqq, repmat(Kqq, [size(Xq{i}, 1), 1]) );
                
                KqfU{i} = Kqf{i} * U{i};
            end
            diagKqfCinvKfq = K_diag_KzKT(KqfU, zinv);
            cq = diagKqq  - diagKqfCinvKfq;
        end
    end
end
ptime = toc;

ggpr.theta = theta;
ggpr.sigma = sigma;
ggpr.lh = lh;
ggpr.ttime = ttime;
ggpr.ptime = ptime;
ggpr.t = t;
if save_eigmats
    ggpr.eigmats = eigmats;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lh, pdlh, pdlhsig, eigmats] = std_compute(Y, X, theta, sigma, covs)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Generate covariance and partial derivative matrix decompositions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DIAG_TRUTH = 1; %Comment out to disable ground-truth debugging

D = length(X);
C =  cell(D, 1);

U = cell(D, 1);
UT = cell(D, 1);
Z = cell(D, 1);

dC = cell(D, 1);

mtheta = zeros(D, 1);
ptheta = zeros(D, 1);

m = zeros(D, 1);
z = 1;
for i = 1:D
    [mtheta(i), ptheta(i)] = size(theta{i});
    m(i) = size(X{i}, 1);
    [C{i}, dC{i}] = covs{i}(X{i}, X{i}, theta{i});
    [U{i}, Z{i}] = eig(C{i});
    UT{i} = U{i}';
    Z{i} = diag(Z{i});
    z = K_a_b(z, Z{i});
end
n2 = prod(m);
[N, M] = size(Y);
if N ~= n2
    error('N, n2 size mismatch');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute GPR terms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Compute t = Chat_inv_y
t = K_TMP(UT, Y);
zinv = 1 ./ (z + sigma^2);
t = K_TMP(U, bsxfun(@times, t, zinv));

%%%%DIAGNOSTIC TRUTH%%%
if exist('DIAG_TRUTH', 'var')
    CHAT = K_Expand(C) + sigma^2 * eye(N);
    T = CHAT  \ Y;
	disp('DIAG_TRUTH: t');
    norm(T-t)
    pause;
end

eigmats.U = U;
eigmats.UT = UT;
eigmats.zinv = zinv;
eigmats.t = t;

%Compute negative log-marginal likelihood
lh = 1/2 * (M*sum(log(z + sigma^2)) + sum(Y(:).*t(:)) + M*N*log(2*pi));

%%%%DIAGNOSTIC TRUTH%%%
if exist('DIAG_TRUTH', 'var')
    LH = 1/2 * (log(det(CHAT)) +  trace(Y'*T) +  N*log(2*pi));
	disp('DIAG_TRUTH: lh');
    norm(lh - LH)
    pause;
end

%Compute pdlh
pdlh = cell(D, 1);
tmp_diagUTDKU = Z;
tmp_dC = C;
for i = 1:D
    pdlh{i} = zeros(mtheta(i), ptheta(i));
    for j = 1:mtheta(i)
        for k = 1:ptheta(i)
            tmp_dC{i} = dC{i}{j, k};
            tmp_diagUTDKU{i} = diag(UT{i}*dC{i}{j, k}*U{i});
            
            tr = M * zinv' * K_expand(tmp_diagUTDKU);
            tT_P_t =  K_TMP(tmp_dC, t);
            tT_P_t = sum(t(:) .* tT_P_t(:));
            
            pdlh{i}(j, k) = 1/2 * (tr - tT_P_t);
            
            %%%%DIAGNOSTIC TRUTH%%%
            if exist('DIAG_TRUTH', 'var')
                TMP_DC = K_Expand(tmp_dC);
                TR = trace(CHAT \ TMP_DC);
                disp('DIAG_TRUTH: Gradient Theta tr');
                norm(tr - TR)
                
                disp('DIAG_TRUTH: Gradient Theta tT_P_t');
                TT_P_T = trace(T' * TMP_DC * T);
                norm(tT_P_t - TT_P_T)
                pause;
            end
        end
    end
    %Reset diagonal
    tmp_diagUTDKU{i} = Z{i};
    %Reset matrix
    tmp_dC{i} = C{i};
end

%Compute pdlhsig
pdlhsig = sigma*(sum(zinv) - sum(t(:).*t(:)));

