function ggpr = trainGGPR(trainX, trainY, maxiter)

%Gaussian process regression
ggpr.D = 2;
ggpr.X{1} = 1;
ggpr.X{2} = trainX;
ggpr.Y = trainY;

ggpr.covs{1} = str2func('cov_sym_alpha');
ggpr.covs{2} = str2func('cov_sym_se');

ggpr.theta  = {1; 1*ones(1, size(ggpr.X{2}, 2))};
ggpr.maxiter = maxiter;
ggpr.a_fac = 1.05;
ggpr.a_start = .1;

ggpr.asig = .001;
ggpr.a_sig_fac = 1.01;
ggpr.sigma  = .05;
ggpr.save_eigmats = 1;
[ggpr] = std_call_ggpr(ggpr, {});
ggpr.eigmats = {};
ggpr.maxiter = 0;
