function testY = testGGPR(testX, ggpr)

Xq{1} = 1;
Xq{2} = testX;
[tmp, testY] = std_call_ggpr(ggpr, Xq);
