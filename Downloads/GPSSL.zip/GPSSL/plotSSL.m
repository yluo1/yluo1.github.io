function plotSSL(truthY, trainY, testY)

[thetaTruth, phiTruth] = cart2sph(truthY(:,1),truthY(:,2),truthY(:,3));
thetaTruth = pi/2 - thetaTruth;

[thetaTrain, phiTrain] = cart2sph(trainY(:,1),trainY(:,2),trainY(:,3));
thetaTrain = pi/2 - thetaTrain;

[thetaTest, phiTest] = cart2sph(testY(:,1),testY(:,2),testY(:,3));
thetaTest = pi/2 - thetaTest;



fontsize_label = 22;
fontsize_gca = 16;


fig = figure('Units','normalized','Position',[0 0 1 1]);
plot(  thetaTruth, phiTruth,  'go', ...
    thetaTrain, phiTrain,  'b+', ...
    thetaTest, phiTest, 'rx', ...
    'linewidth', 2, 'markersize', 10);

axis tight;

lh = legend('Truth', 'Train', 'Test');
set(lh,'fontsize', 24);
set(gca, 'fontsize', fontsize_gca);


xlabel('Azimuth', 'fontsize', fontsize_label);
ylabel('Elevation', 'fontsize', fontsize_label);
title('Mercator Directions', 'fontsize', fontsize_label);

set(fig, 'color', 'w');