Gaussian Process Model for Sound-Source Localization
Author: Yuancheng Luo, 3/27/2014

Description: Train a conditional Gaussian process model on CIPIC subject left and right ear binaural features (HRTF avg. mag. ratio and mag. pair feats.) to predict HRTF measurement directions (sound-source along unit sphere)

trainSSL: Loads dat/subj_1.mat and output GPR model to out/ggpr_subj_1.mat

testSSL: Loads out/ggpr_subj_1.mat, generate WGN source-signal, convolve with left and right ear HRTFs along target direction, compute short-time Fourier transforms, extract binaural features, predict sound-source direction via GPR model.


If you use this code, please consider citing

Yuancheng Luo, Dmitry N. Zotkin, and Ramani Duraiswami, "Gaussian Process Models for HRTF based 3D Sound Localization", International Conference on Acoustics, Speech, and Signal Processing, 2014, Florence, Italy.
