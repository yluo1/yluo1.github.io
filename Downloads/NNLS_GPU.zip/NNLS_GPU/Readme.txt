Author: 	Yuancheng Luo
E-mail: 	yluo1@mail.umd.edu
Date: 	2010-06-25
Modified: 	2016-11-11

============================================================================
Non-negative Least Squares on the GPU:

The package contains code for solving a set of Ax=b systems on CUDA enabled NVIDIA GPUs where x is constrained to be non-negative and the dimensions of A, x, b are 512x512, 512x1, 512x1. The work is based on the "active-set" method originally proposed by Lawson and Hanson (1974). We use an efficient update and downdate method to solve for the unconstrained least-squares sub-problems at each iteration and parallel techniques for accelerating the algorithm.

For a link to the home-page and paper references, visit
http://www.umiacs.umde.edu/~yluo1/Projects/NNLS.html

============================================================================
Update: 2016-11-11
For later CUDA versions that support threadfence_block(), use utils_2016.cu. Thanks Qianqian Fang <q.fang@neu.edu>  for discovering this.

============================================================================
Output:

gpu_result.txt	Text file containing the system id solved, number of column updates, number of column updates+downdates, and the error norm-2. The solutions x, Ax, and b are written to file.

sysA: A binary file containing matrices A
sysB: A binary file containing vectors b

============================================================================
Documentation:

nnls.cu

__global__ void NNLS_MGS_GR_512(		float *d_A, float *d_At, float *d_x, float *d_b,
							float *d_R, int *nIters, int *lsIters)

float *d_A: 	pointer to linear array of elements in matrices A on the device to read from
float *d_At:	pointer to linear array of elements in matrices A transpose on the device to read from
float *d_x:		pointer to linear array for vector x to write to
float *d_b:		pointer to linear array of elements in vectors b to read from
float *d_R:		pointer to linear array for temporary matrices R to read/write to
int	*nIters:	pointer to linear array for the number of column updates per system
int	*lsIters:	pointer to linear array for the number of column updates+downdates per system

Description:
The CUDA function maps each system to a thread-block and asynchronously solves for non-negative solutions x. 

The ith system (0 is first system) to solve is contained between:

d_A[(i*512*512], 	d_A[(i+1)*512*512-1]
d_At[i*512*512],	d_At[(i+1)*512*512-1]
d_x[i*512], 		d_x[(i+1)*512-1] 
d_b[i*512], 		d_b[(i+1)*512-1]
nIters[i]
lsIters[i]

------------------------------------------------------------------------------

headers.h

GPU_USE:		[0,1,...] if platform contains multiple GPUs
NSYS: 		Constant for the number of systems to solve
MAX_ITER_NNLS:	Maximum number of update steps
MAX_ITER_LS:	Maximum number of update+downdate steps
TOL_TERMINATION:	Zero used to check termination condition
TOL_0:		Zero used in downdate step
