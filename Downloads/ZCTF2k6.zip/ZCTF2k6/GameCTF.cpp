/*
Game- CTF 2k6: See Readme file

Last Modded: 5/15/06
*/

#include "GameCTF.h"

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////Init functions//////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

void GameCTF::init(){//function start
	//Define constants for display, input, load texture, sound, level files

	//////////////////////////////////////////////////////////////////
	//////////////////////////Load Files//////////////////////////////
	//////////////////////////////////////////////////////////////////

	///////////////Load textures
	ExternalFiles::defaultTextures[0].LoadTGA("Textures/CTF2k6/wall.tga");
	ExternalFiles::defaultTextures[1].LoadTGA("Textures/CTF2k6/unit.tga");
	ExternalFiles::defaultTextures[2].LoadTGA("Textures/CTF2k6/basePanel.tga");
	ExternalFiles::defaultTextures[3].LoadTGA("Textures/CTF2k6/particle.tga");
	//////////init textures
	for(int a=0;a<4;++a){
		glBindTexture(GL_TEXTURE_2D, ExternalFiles::defaultTextures[a].texID);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB,
			ExternalFiles::defaultTextures[a].width, ExternalFiles::defaultTextures[a].height,
			0, GL_RGB, GL_UNSIGNED_BYTE,
			ExternalFiles::defaultTextures[a].imageData);

		gluBuild2DMipmaps(GL_TEXTURE_2D, 3,
				ExternalFiles::defaultTextures[a].width, ExternalFiles::defaultTextures[a].height,
				GL_RGB, GL_UNSIGNED_BYTE, ExternalFiles::defaultTextures[a].imageData); 
		ExternalFiles::defaultTextureIds[a]=ExternalFiles::defaultTextures[a].texID;
	}

	ExternalFiles::loadDefaultDocuments("Readme.txt");
	/////////////////Load Sounds

	ExternalFiles::defaultSounds[0].load("Sound/background.wav");
	ExternalFiles::defaultSounds[0].play(true);

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////Define constants////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////

	srand(time(NULL));

	Mouse::sensitivity=2.5;
	//Define display constants
	Display::statsOn=true;

	Display::tWinCamX=0;
	Display::tWinCamY=2;
	Display::tWinCamZ=0;

	Display::defaultLightPos[0]=0;
	Display::defaultLightPos[1]=100;
	Display::defaultLightPos[2]=0;
	Display::defaultLightPos[3]=1;
	Display::defaultAmbientLight[0]=1.0f;
	Display::defaultAmbientLight[1]=1.0f;
	Display::defaultAmbientLight[2]=1.0f;

	Display::defaultMaterialSpecular[0]=1.0f;
	Display::defaultMaterialSpecular[1]=1.0f;
	Display::defaultMaterialSpecular[2]=1.0f;
	Display::defaultMaterialDiffuse[0]=1.0f;
	Display::defaultMaterialDiffuse[1]=1.0f;
	Display::defaultMaterialDiffuse[2]=1.0f;
	Display::defaultMaterialAmbient[0]=1.0f;
	Display::defaultMaterialAmbient[1]=1.0f;
	Display::defaultMaterialAmbient[2]=1.0f;

	Display::fogColor[0]=.4;
	Display::fogColor[1]=.4;
	Display::fogColor[2]=.4;
	Display::fogColor[3]=1.0f;
	Display::fogDensity=1.0f;
	Display::clearColor[0]=Display::fogColor[0];
	Display::clearColor[1]=Display::fogColor[1];
	Display::clearColor[2]=Display::fogColor[2];
	Display::fogStart=.1;
	Display::fogEnd=3.0f;

	////////Flexible display properties
	Display::wireFrameOnOff=false;
	Display::normDisplayOnOff=true;
	Display::enableHeadLight=false;
	Display::enableFog=true;
	Display::winMaxCut=Display::fogEnd*2;
	Display::goFullScreen(false);
	Display::winCamSpeed=1;
	Display::winMinCut=.001;
	Display::winInc=.01;

	followMode=true;
	memorySaveDisplay=true;
	memorySavePartitions=4;
	Display::cameraViewMode=1;
	Display::tWinCamDistFromTarget=.1;

	if(Display::specMode&&!followMode) Display::cameraViewMode=0;

	Display::initModelView();//initialize display mode
	introInit();//initialize intro objects
	
	currentScreen=0;
	
}//function end


void GameCTF::gameInit(int inputMapWidth,int inputMapHeight,int inputMapLength,int inputMapComplexity,
					   int inputTotalTeams,int inputUnitsPerTeam,float speedMultiplier){//function start
	//make gamefield, team, AI matricies, units, globals
	int a,b;

	for(a=0;a<MAXMESSAGES;++a) Display::stringStatList[a]=NULL;

	////////////////////////////////////////////////////////////////////////////
	///////////////////////create game map//////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	gameField.GameCTFMapGenerate(inputMapWidth,inputMapHeight,inputMapLength,inputMapComplexity,
		(float)inputMapWidth,(float)inputMapHeight,(float)inputMapLength,
		0,6,
		.15f,.5f,0.0f,
		memorySavePartitions);
	printf("Basic gamefield done\n");
	
	////////////////////////////////////////////////////////////////////////////
	///////////////////////create teams/////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	totalTeams=inputTotalTeams;
	unitsPerTeam=inputUnitsPerTeam;
	if(totalTeams>MAXTEAMS){
		printf("gameInit():max teams exceeded\n");
		getchar();
		exit(0);
	}
	if(unitsPerTeam>MAXUNITSPERTEAM){
		printf("gameInit():max units per team exceeded\n");
		getchar();
		exit(0);
	}
	
	float teamColors[][3]=	{{1.0f,0.3f,0.3f},
							 {0.5f,0.5f,1.0f},
							 {0.5f,1.0f,0.5f},
							 {1.0f,1.0f,0.5f},
							 {1.0f,0.5f,1.0f},
							 {0.5f,1.0f,1.0f},
							 {0.9f,0.9f,0.9f},
							 {0.1f,0.1f,0.1f},
							 {0.2f,0.5f,0.7f}};//unique teams colors
	int teamIds[MAXTEAMS];
	for(a=0;a<totalTeams;++a){
		teamIds[a]=a;//must be conseq and start from 0
		gameTeams[a].init(teamIds[a],teamColors[a],unitsPerTeam,&gameField,totalTeams);
	}
	printf("Teams initialized\n");

	gameField.GameCTFMapAssignBoundaries(totalTeams,teamIds,teamColors);//generate boundaries in map
	gameField.GameCTFMapFinalColorPass();//finalize colors

	totalUnits=0;
	for(a=0;a<totalTeams;++a){//init flags, teams, etc
		//set flags
		gameFlags[a].init(teamIds[a],a,
			teamColors[a],
			.01,.02,
			&gameField);

		gameTeams[a].setHomeTeamFlagPointer(&gameFlags[a]);//pass flag pointer to current team
		for(b=0;b<totalTeams;++b){//pass flag pointer to all other teams
			if(b!=a) gameTeams[b].setVisitorTeamFlagPointer(&gameFlags[a]);
		}

		for(b=0;b<gameTeams[a].teamTotalUnits;++b){//make units
			gameUnits[totalUnits].init(b,teamIds[a],totalUnits,
				.05,true,10,
				teamColors[a],
				.5,speedMultiplier,.1,
				&gameField);

			gameTeams[a].setHomeTeamUnitPointers(&gameUnits[totalUnits]);//pass unit pointer to current team
			for(int c=0;c<totalTeams;++c){//pass unit pointers to all other teams
				if(c!=a) gameTeams[c].setVisitorTeamUnitPointers(&gameUnits[totalUnits]);
			}
			currentSelectedUnit=totalUnits;
			++totalUnits;
		}
		gameTeams[a].generateAIForceMapBaseDistance();
	}
	printf("gameInit units/flags set\n");
	////////////////////////////////////////////////////////////////////////////
	///////////////////////create display lists/////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	gameField.GameCTFMakeDisplayLists(totalTeams,teamIds,teamColors,memorySaveDisplay);
	printf("gameInit Display lists done\n");

	////////////////////////////////////////////////////////////////////////////
	///////////////////////load strings into display buffer/////////////////////
	////////////////////////////////////////////////////////////////////////////
	Display::stringStatList[totalTeams]="Hit!";
	Display::stringStatPositions[totalTeams][0]=500;
	Display::stringStatPositions[totalTeams][1]=720;
	Display::stringStatList[totalTeams+1]="Team has your flag!";
	Display::stringStatPositions[totalTeams+1][0]=410;
	Display::stringStatPositions[totalTeams+1][1]=700;
	Display::stringStatList[totalTeams+2]="Tagged!";
	Display::stringStatPositions[totalTeams+2][0]=476;
	Display::stringStatPositions[totalTeams+2][1]=680;
	Display::stringStatList[totalTeams+3]="You have the flag, return to your base!";
	Display::stringStatPositions[totalTeams+3][0]=345;
	Display::stringStatPositions[totalTeams+3][1]=660;

	lastGoodCameraRoom=gameUnits[currentSelectedUnit].currentRoom;
	gameInitialized=true;
	Display::cameraViewMode=0;
}//function end


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////Intro functions//////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////


void GameCTF::introInit(){//function start
//intro object initialize
	gameIntro.init();
}//function end

void GameCTF::introRun(){//function start
	//startup screen
	gameIntro.update();
	gameIntro.display();

	if(Keyboard::specialKeyArray[GLUT_KEY_F1]){
		if(gameInitialized){
			currentScreen=1;
			Keyboard::specialKeyArray[GLUT_KEY_F1]=false;
			if(!Display::specMode){
				Mouse::changeMouseMovementMode(1);
				Mouse::sensitivity=.1;
			}
		}
	}

	if(gameIntro.enterGameMode){//just got out of winmode
		currentScreen=1;
		Display::specMode=gameIntro.inputSpecMode;
		winScore=gameIntro.inputWinScore;
		gameInit(gameIntro.inputWidth,gameIntro.inputHeight,gameIntro.inputLength,gameIntro.inputComplexity,
			gameIntro.inputTotalTeams,gameIntro.inputUnitsPerTeam,gameIntro.inputSpeed/100.0f);//init game

			Mouse::changeMouseMovementMode(1);
			Mouse::sensitivity=.1;


	}
}//function end

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////Game run functions//////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

void GameCTF::run(){//function start
	//control screen display

	switch(currentScreen){
	case 0: 
		introRun();
		break;
	case 1: 
		gameRun();
		break;
	case 2:
		gameDisplayWinner();
		break;
	}

}//function end


void GameCTF::gameRun(){//function start
//runner function

	glLoadIdentity();

	if(!Display::specMode||followMode) gameRunUserUpdateCamera();//center around unit
	Display::updateModelCamera();//update  camera

	gameRunDisplay();//display

	//////////game code
	gameRunUserInput();	//process user input
	gameRunUpdateTeams();//update teams
	gameRunUpdateUnits();

	gameRunCheckCollisions();//check game collisions
	gameRunUpdateChanges();
	gameRunUpdateFlags();//update

	gameRunCameraCollisions();//update camera collision

}//function end

void GameCTF::gameRunUpdateTeams(){//function start
//update team objects
	for(int a=0;a<totalTeams;++a){
		gameTeams[a].update();
		if(gameTeams[a].score>=winScore){
			currentScreen=2;
			winner=a;
		}
	}
}//function end

void GameCTF::gameRunUpdateUnits(){//function start
//update playable units baesd on team AI
	for(int a=0;a<totalUnits;++a){
		if(!(currentSelectedUnit==a&&!Display::specMode)){//determine next best move
			//////////////////////////////////////////////////////
			/////////////////////AI movement//////////////////////
			//////////////////////////////////////////////////////

			float temp[]={gameUnits[a].lastVel[0],gameUnits[a].lastVel[1],gameUnits[a].lastVel[2]};
			Matrix::MatrixVecNormalize(temp);
			float safetyCoord[3]={	gameUnits[a].posX+temp[0]*gameUnits[a].maxSpeed,
									gameUnits[a].posY+temp[1]*gameUnits[a].maxSpeed,
									gameUnits[a].posZ+temp[2]*gameUnits[a].maxSpeed};
	
			float *coord;
			float radiusOfVariation=0;
			int coordRoom;//room that coord is in
			bool stateChase=false;//true=chase, false=evade
			if(!gameUnits[a].isCarryingFlag){//is not a flag carrier

				if(gameTeams[gameUnits[a].teamId].AIForceMapEnabledDetailCoords[gameUnits[a].currentRoom]){
					//special coords in place
					coord=gameTeams[gameUnits[a].teamId].getDetailTargetRoomCoord(gameUnits[a].currentRoom);	
					stateChase=true;
				}else{//normal coords
					coordRoom=gameTeams[gameUnits[a].teamId].generateAIPathCoordsLocal(gameUnits[a].currentRoom);
					coord=gameTeams[gameUnits[a].teamId].getNormalTargetRoomCoord(gameUnits[a].currentRoom);
					radiusOfVariation=gameField.gameMap.mapNodes[coordRoom].radius*.6;
				}
			}else{//is a flag carrier
				coordRoom=gameTeams[gameUnits[a].teamId].generateAIPathCoordsFlagCarrierLocal(gameUnits[a].currentRoom);
				coord=gameTeams[gameUnits[a].teamId].getFlagRunnerTargetRoomCoord(gameUnits[a].currentRoom);
				radiusOfVariation=gameField.gameMap.mapNodes[coordRoom].radius*.6;
				int homeFlagRoom=gameField.flagRooms[gameUnits[a].teamId];
				if(gameUnits[a].currentRoom==homeFlagRoom||coordRoom==homeFlagRoom)//if coord room is not flag room
					stateChase=true;
			}
			gameUnits[a].updateAITarget(coord,&safetyCoord[0],radiusOfVariation,stateChase);
			gameUnits[a].updateAIMovement();

			//////////////////////////////////////////////////////
			///////////////////////AI weapons/////////////////////
			//////////////////////////////////////////////////////
			if(GameCTFCCNSTS::weaponsEnabled){//run if enabled
				float unitPosition[3]={gameUnits[a].posX,gameUnits[a].posY,gameUnits[a].posZ};
				float weaponCoord[3];
				bool hasTarget=gameTeams[gameUnits[a].teamId].getWeaponTarget(unitPosition,weaponCoord);
				gameUnits[a].updateAIWeaponTarget(hasTarget,weaponCoord);
			}
		}
		gameUnits[a].updateNextStep();		
	}

}//function end

void GameCTF::gameRunUpdateFlags(){//function start
	//control flag behavior

	for(int a=0;a<MAXTEAMS;++a){
		if(gameFlags[a].taken){//flag is taken
			//run flag with unit
			int b=gameFlags[a].possessionObjectId;
			if(gameUnits[b].alive){//flag runner is still alive
				gameFlags[a].posX=gameUnits[b].posX;
				gameFlags[a].posY=gameUnits[b].posY;
				gameFlags[a].posZ=gameUnits[b].posZ;
				gameFlags[a].currentRoom=gameUnits[b].currentRoom;
			}else{//flag runner is dead
				gameFlags[a].taken=false;
				gameFlags[a].setDefaultSpawnLocation();
			}
		}
		gameFlags[a].rot=((int)gameFlags[a].rot+1)%360;
	}
}//function end

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
////////////////////Collision functions///////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void GameCTF::gameRunCheckCollisions(){//function start
	//collision detection between object and walls
	int roomList[10];
	int roomIndex;	
	for(int a=0;a<totalUnits;++a){
		if(gameUnits[a].alive){
			/////////////////////poly collision
			roomList[0]=gameUnits[a].currentRoom;
			for(roomIndex=1;roomIndex<gameField.gameMap.mapNodes[roomList[0]].totalEdges+1;++roomIndex)
				roomList[roomIndex]=gameField.gameMap.mapNodes[roomList[0]].edges[roomIndex-1][0];
			gameRunCheckCollisionsRecur(a,0,15,roomList,roomIndex);

			
			////////////////////unit collision
			for(int b=a+1;b<totalUnits;++b){
				if(gameUnits[b].alive){
					if(gameUnits[a].teamId!=gameUnits[b].teamId){
						float diffX=gameUnits[a].posX-gameUnits[b].posX;
						float diffY=gameUnits[a].posY-gameUnits[b].posY;
						float diffZ=gameUnits[a].posZ-gameUnits[b].posZ;
						if(diffX*diffX+diffY*diffY+diffZ*diffZ<=mymax(gameUnits[a].radius*gameUnits[a].radius,gameUnits[b].radius*gameUnits[b].radius)){
							//units have collided so kill both
							gameUnits[a].hasDied=true;
							gameUnits[b].hasDied=true;
						}
					}
				}
			}
			
			if(gameUnits[a].weaponOn){//weapon collision
				float currentUnitPos[3]={gameUnits[a].posX,gameUnits[a].posY,gameUnits[a].posZ};
				for(int b=0;b<totalUnits;++b){
					if(b!=a){
						float dist=Matrix::MatrixPointDistSquaredFromSegment(gameUnits[b].posX,gameUnits[b].posY,gameUnits[b].posZ,currentUnitPos,gameUnits[a].weaponTargetCoord);
						if(dist<=2*gameUnits[b].radius*gameUnits[b].radius){
							gameUnits[b].hasDied=true;
							if(a==currentSelectedUnit) Display::stringStatColors[totalTeams][3]=1.0f;
						}
					}
				}
			}

			//////////////////flag collision
			for(int c=0;c<totalTeams;++c){
				if(!gameFlags[c].taken){
					if(gameUnits[a].currentRoom==gameFlags[c].currentRoom){
						float diffX=gameUnits[a].posX-gameFlags[c].posX;
						float diffY=gameUnits[a].posY-gameFlags[c].posY;
						float diffZ=gameUnits[a].posZ-gameFlags[c].posZ;
						if(diffX*diffX+diffY*diffY+diffZ*diffZ<=mymax(gameUnits[a].radius*gameUnits[a].radius,gameFlags[c].radius*gameFlags[c].radius)){
							if(gameUnits[a].teamId!=gameTeams[c].teamId){//visitor flag collision
								gameUnits[a].flagCarrier[c]=true;
								gameUnits[a].isCarryingFlag=true;
								gameFlags[c].taken=true;
								gameFlags[c].possession=gameUnits[a].teamId;
								gameFlags[c].possessionObjectId=a;
								gameTeams[gameUnits[a].teamId].possessedFlags[c]=true;
								gameTeams[gameUnits[a].teamId].possessedFlagCarrier[c]=gameUnits[a].unitId;
							}else{//home team flag collision
								if(gameUnits[a].isCarryingFlag){//flag carrier ran into hometeam flag
									//has scored
									gameUnits[a].hasDied=true;
									++gameTeams[gameUnits[a].teamId].score;
								}
							}
						}
					}
				}
			}
		}
	}

}//function end

void GameCTF::gameRunCheckCollisionsRecur(int currentUnit,int currentDepth,int maxDepth,int roomList[10],int roomIndex){
	//function start
	//collision detection.

	for(int cRoom=0;cRoom<roomIndex;++cRoom){
			int b;
			for(b=0;b<gameField.gameRooms[roomList[cRoom]].polyCount;++b){
				//set perm points as position of sphere COM and sphere's next step position based on current velocity
				float currentPointPerm[3]={gameUnits[currentUnit].posX,gameUnits[currentUnit].posY,gameUnits[currentUnit].posZ};
				float nextPointPerm[3]={gameUnits[currentUnit].posX+gameUnits[currentUnit].vel[0],
										gameUnits[currentUnit].posY+gameUnits[currentUnit].vel[1],
										gameUnits[currentUnit].posZ+gameUnits[currentUnit].vel[2]};

					//determine tangent point on the sphere to current poly
					float currentPoint[3],nextPoint[3];
					for(int k=0;k<3;++k){
						currentPoint[k]=currentPointPerm[k]-gameField.gameRooms[roomList[cRoom]].poly[b].polyNormal[k]*gameUnits[currentUnit].radius;
						nextPoint[k]=nextPointPerm[k]-gameField.gameRooms[roomList[cRoom]].poly[b].polyNormal[k]*gameUnits[currentUnit].radius;
					}
					
					//check if COM to sphere tangent point has intersected poly
					if(gameField.gameRooms[roomList[cRoom]].poly[b].polyCollide(currentPointPerm,nextPoint)){
						//has collided
						gameUnits[currentUnit].blocked=true;
						//collision response (sliding)
						float destDistanceFromPlane=fabs(gameField.gameRooms[roomList[cRoom]].poly[b].polyPointDistance(nextPoint))+.001;

						//extended point projected back to get close to poly without intersection
						float projectedNextPoint[3]={nextPoint[0]+destDistanceFromPlane*gameField.gameRooms[roomList[cRoom]].poly[b].polyNormal[0],
													 nextPoint[1]+destDistanceFromPlane*gameField.gameRooms[roomList[cRoom]].poly[b].polyNormal[1],
													 nextPoint[2]+destDistanceFromPlane*gameField.gameRooms[roomList[cRoom]].poly[b].polyNormal[2]};	

						int d,e;
						for(d=0;d<roomIndex;++d){
							for(e=0;e<gameField.gameRooms[roomList[d]].polyCount;++e){
								if(!(d==cRoom&&e==b)){//don't check the same poly again
									if(gameField.gameRooms[roomList[d]].poly[e].polyCollide(currentPointPerm,projectedNextPoint))
										break;//new point is bad so must recur again
								}
							}
							if(e<gameField.gameRooms[roomList[d]].polyCount) break;//bad pt
						}
						
						gameUnits[currentUnit].vel[0]=projectedNextPoint[0]-currentPoint[0];
						gameUnits[currentUnit].vel[1]=projectedNextPoint[1]-currentPoint[1];
						gameUnits[currentUnit].vel[2]=projectedNextPoint[2]-currentPoint[2];

						if(d<roomIndex){//bad point so recur with new vel
							if(currentDepth+1<maxDepth)
								gameRunCheckCollisionsRecur(currentUnit,currentDepth+1,maxDepth,roomList,roomIndex);
						}
						
					}
			}
	}
}//function end

void GameCTF::gameRunCameraCollisions(){//function start
	if(Display::cameraViewMode==1){//3d person view on
		Display::winCameraDistFromTargetFactor=1;
		int roomList[10];
		int roomIndex;	
		
		float currentPoint[3]={gameUnits[currentSelectedUnit].posX,gameUnits[currentSelectedUnit].posY,gameUnits[currentSelectedUnit].posZ};
		float nextPoint[3]={Display::winCameraMode1Pos[0],
							Display::winCameraMode1Pos[1],
							Display::winCameraMode1Pos[2]};
		
		roomList[0]=lastGoodCameraRoom;
		for(roomIndex=1;roomIndex<gameField.gameMap.mapNodes[roomList[0]].totalEdges+1;++roomIndex)
		roomList[roomIndex]=gameField.gameMap.mapNodes[roomList[0]].edges[roomIndex-1][0];


		bool hasIntersected=false;
		float closestIntersectionDist=9999999;

		for(int cRoom=0;cRoom<roomIndex;++cRoom){
			int b;
			for(b=0;b<gameField.gameRooms[roomList[cRoom]].polyCount;++b){

				float intersect[3];
				if(gameField.gameRooms[roomList[cRoom]].poly[b].polyCollide(currentPoint,nextPoint,intersect)){
					hasIntersected=true;
					float dist=(intersect[0]-Display::winCamX)*(intersect[0]-Display::winCamX)+(intersect[1]-Display::winCamY)*(intersect[1]-Display::winCamY)+(intersect[2]-Display::winCamZ)*(intersect[2]-Display::winCamZ);
					if(closestIntersectionDist>dist){
						closestIntersectionDist=dist;
					}
				}
			}
		}
		if(hasIntersected){
			Display::winCameraDistFromTargetFactor=(sqrt(closestIntersectionDist))/Display::tWinCamDistFromTarget;
		}
	}
}//function end

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
////////////////////Display functions/////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void GameCTF::gameRunDisplay(){//function start
//all drawing and displaying done here
	//////////////////display map
	if(!Display::wireFrameOnOff){
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, ExternalFiles::defaultTextureIds[0]);
	}
	else glDisable(GL_TEXTURE_2D);

	int nearestNode=gameField.nearestNode(Display::winCamX,Display::winCamY,Display::winCamZ);

	/////////display world
	if(memorySaveDisplay) gameRunDisplaySaveMode(nearestNode);//faster drawing mode
	else gameRunDisplayFullMode();//display entire map

	//////////////display units
	gameRunDisplayUnits();

	////////////display minimap
	if(miniMapOn) gameRunDisplayMinimap(nearestNode);
	
	/////////////////////////////////////string messages
	////////////put hit message into display string buffer
	Display::stringStatList[totalTeams]="Hit!";
	if(Display::stringStatColors[totalTeams][3]>.01){
		for(int a=0;a<3;++a) Display::stringStatColors[totalTeams][a]=gameTeams[gameUnits[currentSelectedUnit].teamId].teamColor[a];
		Display::stringStatColors[totalTeams][3]*=.99;
	}
	Display::stringStatList[totalTeams+1]="Team has your flag!";
	////////put flag taken message in display string buffer
	if(gameFlags[gameUnits[currentSelectedUnit].teamId].taken){
		for(int a=0;a<3;++a) Display::stringStatColors[totalTeams+1][a]=gameTeams[gameFlags[gameUnits[currentSelectedUnit].teamId].possession].teamColor[a];
		Display::stringStatColors[totalTeams+1][3]=1;
	}else Display::stringStatColors[totalTeams+1][3]*=.95;
	////////put flag taken message in display string buffer
	Display::stringStatList[totalTeams+2]="Tagged";
	if(!gameUnits[currentSelectedUnit].alive){
		for(int a=0;a<3;++a) Display::stringStatColors[totalTeams+2][a]=gameTeams[gameUnits[currentSelectedUnit].teamId].teamColor[a];
		Display::stringStatColors[totalTeams+2][3]=(float)gameUnits[currentSelectedUnit].spawnDelay/SPAWNDELAY;
	}else 	Display::stringStatColors[totalTeams+2][3]=0;
	/////////put flag return message in display string buffer
	Display::stringStatList[totalTeams+3]="You have the flag, return to your base!";
	if(gameUnits[currentSelectedUnit].isCarryingFlag){
		for(int a=0;a<3;++a) Display::stringStatColors[totalTeams+3][a]=gameTeams[gameUnits[currentSelectedUnit].teamId].teamColor[a];
		Display::stringStatColors[totalTeams+3][3]=1.0f;
	}else 	Display::stringStatColors[totalTeams+3][3]*=.95;

	glDisable(GL_TEXTURE_2D);

}//function end

void GameCTF::gameRunDisplayUnits(){//function start
//display object unit
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glDepthMask(false);
	for(int a=0;a<totalUnits;++a){
		if(a==currentSelectedUnit) gameUnits[a].display(true);
		else gameUnits[a].display(false);
	}
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_TEXTURE_2D);
	for(int b=0;b<totalTeams;++b) gameFlags[b].display();
	glDepthMask(true);
	glDisable(GL_BLEND);

}//function end

void GameCTF::gameRunDisplaySaveMode(int node){//function start
	//draw segmented field
	glCallList(gameField.gameMapDisplayListPartialMap+node);//display entire map
}//function end

void GameCTF::gameRunDisplayFullMode(){//function start
	//draw entire map
	glCallList(gameField.gameMapDisplayListBigMap);
}//function end

void GameCTF::gameRunDisplayMinimap(int node){//function start
//draw the minimap of the whole maze in node mode. Draw close range stuff also

	//////////fake a sub-window
	glPushMatrix();
	glDepthMask(GL_FALSE);
	glLoadIdentity();
	float scaleFac=.05f;

	float cord[4]={0,.01,.05,1};
	Matrix::MatrixRotateXAxis(Display::winXAxisAngle*PI/180.0,cord);
	Matrix::MatrixRotateYAxis(-Display::winYAxisAngle*PI/180.0,cord);
	
	float miniMapLocation[3]={Display::winCamX*scaleFac,Display::winCamY*scaleFac,Display::winCamZ*scaleFac};
	
	//position minimap
	glScalef(.1f,.1f,.1f);

	gluLookAt(miniMapLocation[0]+cord[0],miniMapLocation[1]+cord[1],miniMapLocation[2]+cord[2],
		miniMapLocation[0],miniMapLocation[1],miniMapLocation[2],
		Display::winUpY[0],Display::winUpY[1],Display::winUpY[2]);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);

	/////////draw minimap here

	glScalef(scaleFac,scaleFac,scaleFac);
	glCallList(gameField.gameMapDisplayListMinimap);
	int a,b;
    b=-1;
	for(a=0;a<totalUnits;++a){
		if(gameUnits[a].teamId!=b){
			glColor4f(gameUnits[a].color[0]/2,gameUnits[a].color[1]/2,gameUnits[a].color[2]/2,.5f);
			b=gameUnits[a].teamId;
		}
		if(gameUnits[a].alive){			
			Display::drawSphere(gameUnits[a].posX,gameUnits[a].posY,gameUnits[a].posZ,
								.015,5,5);
		}
	}
	for(a=0;a<totalTeams;++a){
		glColor4f(gameFlags[a].color[0]/1.5,gameFlags[a].color[1]/1.5,gameFlags[a].color[2]/1.5,.5f);
		Display::drawCone(gameFlags[a].posX,gameFlags[a].posY,gameFlags[a].posZ,-90,1,0,0,.025,.1,5,5);
	}
	glTranslatef(Display::winCamX,Display::winCamY,Display::winCamZ);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glDisable(GL_BLEND);

	glPopMatrix();
	glDepthMask(GL_TRUE);

}//function end

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
////////////////////Winner functions/////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void GameCTF::gameDisplayWinner(){//function start
	gameInitialized=false;
	glLoadIdentity();

	if(!Display::specMode) gameRunUserUpdateCamera();//center around unit
	Display::updateModelCamera();//update  camera
	gameRunDisplay();//display
	gameRunCameraCollisions();
	gameRunUserInput();

	glPushMatrix();
	Display::initOrthoView();
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
	glDisable(GL_TEXTURE_2D);
	
	glColor4f(	.5+.5*gameTeams[winner].teamColor[0],
				.5+.5*gameTeams[winner].teamColor[1],
				.5+.5*gameTeams[winner].teamColor[2],
				1);
	Display::drawString("Team has won!",400,400,GLUT_BITMAP_HELVETICA_18);
	Display::drawString("Hit F1 for menu",400,500,GLUT_BITMAP_HELVETICA_18);

	glEnable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	Display::resetPerspectiveProjection();
	glPopMatrix();
}//function end

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
////////////////////Other functions/////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void GameCTF::gameRunUpdateChanges(){//function start
	for(int a=0;a<totalUnits;++a) 	gameUnits[a].updateCurrentStep();

	if(Display::specMode&&!gameUnits[currentSelectedUnit].alive) currentSelectedUnit=(currentSelectedUnit+1)%totalUnits;
	
	if(gameUnits[currentSelectedUnit].alive) lastGoodCameraRoom=gameUnits[currentSelectedUnit].currentRoom;

}//function end


void GameCTF::gameRunUserInput(){//function start
//process user keyboard input
	Keyboard::processDefaultKeys();//update default keys. [dummy]
	gameKeys();//process game specific keys
	if(Display::specMode){
		if(!followMode) Movement::CameraFirstUpdate();//Spectator mode
	}else{
		if(gameUnits[currentSelectedUnit].alive)
			gameUnits[currentSelectedUnit].unitUserUpdate();//user input keys
	}

}//function end

void GameCTF::gameRunUserUpdateCamera(){//function start
//update Display class's camera position and settings
	Display::tWinCamX=gameUnits[currentSelectedUnit].posX;
	Display::tWinCamY=gameUnits[currentSelectedUnit].posY;
	Display::tWinCamZ=gameUnits[currentSelectedUnit].posZ;
}//function end

void GameCTF::gameKeys(){//function start
//update game keys based on currentScreen

	switch(currentScreen){
	case 0:
		break;
	case 1:
		if(Keyboard::normalKeyArray[(int)'p']||Keyboard::normalKeyArray[(int)'P']){//reroll map
			gameReset();
			Keyboard::normalKeyArray[(int)'p']=false;
			Keyboard::normalKeyArray[(int)'P']=false;
		}
		if(Keyboard::normalKeyArray[(int)'\t']){//toogle minimap
			miniMapOn=!miniMapOn;
			Keyboard::normalKeyArray[(int)'\t']=false;
		}
		if(Keyboard::normalKeyArray[(int)'.']){//change cam distance from target
			if(Display::tWinCamDistFromTarget<.5) Display::tWinCamDistFromTarget*=1.1;
		}else if(Keyboard::normalKeyArray[(int)',']){
			if(Display::tWinCamDistFromTarget>0) Display::tWinCamDistFromTarget*=.9;
		}
		if(Keyboard::normalKeyArray[(int)'`']||Keyboard::normalKeyArray[(int)'~']){//cycle through unit
			int a;
			for(a=currentSelectedUnit+1;a<currentSelectedUnit+totalUnits;++a){
				if(gameUnits[a%totalUnits].teamId==gameUnits[currentSelectedUnit].teamId) break;
			}
			if(a<currentSelectedUnit+totalUnits) currentSelectedUnit=a%totalUnits;
			Keyboard::normalKeyArray[(int)'`']=Keyboard::normalKeyArray[(int)'~']=false;
			
		}
		if(Keyboard::specialKeyArray[GLUT_KEY_F1]){
			currentScreen=0;	
			Keyboard::specialKeyArray[GLUT_KEY_F1]=false;
			Mouse::changeMouseMovementMode(0);
			Mouse::sensitivity=2.5;
		}

	break;
	case 2:

		if(Keyboard::normalKeyArray[(int)'\t']){
			miniMapOn=!miniMapOn;
			Keyboard::normalKeyArray[(int)'\t']=false;
		}
		if(Keyboard::normalKeyArray[(int)'.']){
			if(Display::tWinCamDistFromTarget<.5) Display::tWinCamDistFromTarget*=1.1;
		}else if(Keyboard::normalKeyArray[(int)',']){
			if(Display::tWinCamDistFromTarget>0) Display::tWinCamDistFromTarget*=.9;
		}
		if(Keyboard::specialKeyArray[GLUT_KEY_F1]){
			currentScreen=0;	
			Keyboard::specialKeyArray[GLUT_KEY_F1]=false;
			Mouse::changeMouseMovementMode(0);
			Mouse::sensitivity=2.5;
		}

	break;
	};

}//function end

void GameCTF::gameReset(){//function start
	//restart program
	printf("\n");
	gameInit(gameIntro.inputWidth,gameIntro.inputHeight,gameIntro.inputLength,gameIntro.inputComplexity,
			gameIntro.inputTotalTeams,gameIntro.inputUnitsPerTeam,gameIntro.inputSpeed/100.0f);//init game


}//function end