/*
ParticleFireworks class: Class inherits particle  class. Particles explode outwards and decelerate due air resistance.
Last Modded: 5/15/06

*/
#include "Particle.h"

ParticleFireworks::ParticleFireworks(){//dummy constructor

}//contructor end


void ParticleFireworks::update(float particleOrigin[3],float vo[3]){
	if(isAlive){
		for(int a=0;a<3;++a){
			pos[a]+=vel[a];
			vel[a]+=acel[a];
			acel[a]=-vel[a]*airResist;
		}
		life-=decayRate;
		if(life<=0){
			life=0;
			isAlive=false;
		}
	}else{//reset particle
		life=iLife;
		isAlive=true;
		for(int b=0;b<3;++b){
			pos[b]=iPos[b]+particleOrigin[b];
			int c=(int)(iVel[b]*10000.0f);
			if(c==0) c=1;
			vel[b]=myrandomposneg()*(rand()%(c))/10000.0f*explosionPower+vo[b];

			acel[b]=iAcel[b];
			color[b]=iColor[b];
		}
	}
}

void ParticleFireworks::init(float startLife,float startDecay,float radius,float aResist,
				float x,float y,float z,
				float vox,float voy,float voz,
				float aox,float aoy,float aoz,
				float startColor[3],
				float xPow){//function start
			
	life=iLife=startLife;
	decayRate=startDecay;
	isAlive=false;
	pos[0]=iPos[0]=x;
	pos[1]=iPos[1]=y;
	pos[2]=iPos[2]=z;
	vel[0]=iVel[0]=vox;
	vel[1]=iVel[1]=voy;
	vel[2]=iVel[2]=voz;
	acel[0]=iAcel[0]=aox;
	acel[1]=iAcel[1]=aoy;
	acel[2]=iAcel[2]=aoz;
	color[0]=iColor[0]=startColor[0];
	color[1]=iColor[1]=startColor[1];
	color[2]=iColor[2]=startColor[2];
	size=radius;
	explosionPower=xPow;
	airResist=aResist;

}//function end

void ParticleFireworks::displaySquareFireworkParticle(float baseAlpha){//function start
	if(isAlive){

		//billboard effect
		float modelview[16];
		int i,j;
		glPushMatrix();
		glTranslatef(pos[0],pos[1],pos[2]);
		glGetFloatv(GL_MODELVIEW_MATRIX,modelview);
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++){
				if(i==j) modelview[i*4+j]=1.0;
				else modelview[i*4+j]=0.0;
			}
		}
		glLoadMatrixf(modelview);

		float alpha=life/iLife;
		glColor4f(color[0],
				  color[1],
				  color[2],
				  alpha*baseAlpha);
		glBegin(GL_TRIANGLE_STRIP);
		glTexCoord2d(1,0);
		glVertex3f(size,-size,0);
		glTexCoord2d(1,1);
		glVertex3f(size,size,0);
		glTexCoord2d(0,0);
		glVertex3f(-size,-size,0);
		glTexCoord2d(0,1);
		glVertex3f(-size,size,0);
		glEnd();

		glPopMatrix();

	}
}//function end

void ParticleFireworks::displayPointFireworkParticle(float baseAlpha){//function start
	if(isAlive){
		float alpha=life/iLife;

		glColor4f(1-color[0]*(1-alpha),
				  1-color[1]*(1-alpha),
				  1-color[2]*(1-alpha),
				  alpha*baseAlpha);
		glVertex3f(pos[0],pos[1],pos[2]);
		//no normals
	}
}//function end

