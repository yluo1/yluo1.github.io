/*
Dlg Class: Dialogue object classes used for graphic interfaces
Contains variables for position, size, and colors. Acts as an inheritable class
for all Dlg objects.

Last Modded: 5/15/06
*/
#include "Dlg.h"

Dlg::Dlg(){//function start
}//function end

void Dlg::display(){//function start
}//function end

void Dlg::init(int x,int y,int *length,int *height,float colors[4]){//function start
	posX=x;
	posY=y;
	sizeX=length;
	sizeY=height;
	for(int a=0;a<4;++a) color[a]=colors[a];
	initialized=true;
}//function end

void Dlg::update(){//function start
}//function end

