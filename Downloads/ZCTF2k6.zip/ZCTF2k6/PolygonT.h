#ifndef POLYGONT
#define POLYGONT

#include <stdio.h>
#include "GLUT/glut.h"
#include "Matrix.h"
#include "ccnst.h"

class PolygonT{//class start
////////polygons are triangles only
public:

	float vertexCoords[3][3];//coordinates of 3 verticies of triangle
	float vertexNormals[3][3];//normals of the 3 verticies
	float polyNormal[3];//normal of plane
	int polyNormalPosnegs[3];//signs of normals
	bool polyNormalsFixed;//true if normals are fixed to point towards some origin
	float polyDistance;//distance of poly from 0,0,0
	float texCoords[3][2];//texture coordinates of 3 verticies of triangle

	float polyColors[4];
	float vertexColors[3][4];

	bool isCCW;//true if is counter clockwise
	
	/////functions
	
	PolygonT();
	void setPosition(float verticies[3][3],float relativeNormalPoint[3]);
	void calcNormals();
	void fixPolyNormalRelativity(float pt[3]);
	bool polyCollide(float currentPoint[3],float nextPoint[3]);
	bool polyCollide(float currentPoint[3],float nextPoint[3],float intersect[3]);
	//intersect is a blankarray which will have the intersection point if returned true
	int polySides(float currentPoint[3]);
	bool polyIn(float point[3]);
	void display();//must be within glBegin triangles
	void displayNormals();
	float polyPointDistance(float currentPoint[3]);//return distance from point to poly
	
};//class end

#endif