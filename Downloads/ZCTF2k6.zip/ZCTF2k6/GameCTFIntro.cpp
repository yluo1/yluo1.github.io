/*
GameCTFIntro class: Class contains dlg objects for intro menus and display.

Last Modded: 5/15/06
*/
#include "GameCTFIntro.h"

GameCTFIntro::GameCTFIntro(){

}

void GameCTFIntro::init(){//function start
	//initialize panel variables
	float basel0Color[]={1.0f,1.0f,1.0f,1.0f};
	float basel1Color[]={0.0f,1.0f,1.0f,.25f};
	float basel2Color[]={0.5f,1.0f,1.0f,0.5f};
	float basel3Color[]={0.5f,0.75f,.5f,0.55f};
	float basel4Color[]={0.25,0.5f,.5f,.75f};
	float basel5Color[]={0.0f,1.0f,1.0f,.75f};
	float basel6Color[]={0.0f,1.0f,6.0f,.30f};
	float basel7Color[]={0.5f,1.0f,0.8f,1.0f};
	float basel8Color[]={0.5f,1.0f,0.8f,0.75f};
	float basel9Color[]={0.0f,3.0f,3.0f,.30f};
	float basel10Color[]={0.0f,0.2f,0.2f,.40f};

	gamePanelBase[0].init(0,0,new int(1024),new int(768),basel0Color,2,1.0f);
	gamePanelBase[1].init(420,350,new int(200),new int(100),basel1Color,-1,0);
	gamePanelBase[2].init(350,450,new int(335),new int(100),basel1Color,-1,0);
	gamePanelBase[3].init(375,550,new int(295),new int(100),basel1Color,-1,0);
	gamePanelBase[4].init(400,650,new int(245),new int(100),basel1Color,-1,0);

	gamePanelBase[5].init(300,325,new int(1024-600),new int(430),basel9Color,-1,.2);

	gameAboutBox.init(1024/8,300,new int(1024*.75),new int(768/2),basel8Color,ExternalFiles::defaultDocuments[0]);
	gamePanelBack.init(772,768/2+320,new int(1024-900),new int(40),basel2Color,-1,.35f);

	gameInputBasePanel.init(1024/8,300,new int(1024*.75),new int(768/2),basel4Color,-1,basel4Color[3]);
	gameInputBasePanel2.init(1024/8,320,new int(1024*.75*.95),new int(768/2*.9),basel10Color,-1,basel10Color[3]);
	gameInputBoxes[0].init(270,350,new int(200),new int(20),basel3Color,1,"5");
	gameInputBoxes[1].init(270,375,new int(200),new int(20),basel3Color,1,"2");
	gameInputBoxes[2].init(270,400,new int(200),new int(20),basel3Color,1,"5");
	gameInputBoxes[3].init(270,425,new int(200),new int(20),basel3Color,4,"100");
	
	gameInputBoxes[4].init(270,475,new int(200),new int(20),basel3Color,1,"2");
	gameInputBoxes[5].init(270,500,new int(200),new int(20),basel3Color,2,"5");

	gameInputBoxes[6].init(270,625,new int(200),new int(20),basel3Color,2,"5");

	gameInputBoxes[7].init(635,350,new int(200),new int(20),basel3Color,3,"75");

	gameInputStartPanel.init(772,620,new int(1024-920),new int(35),basel5Color,-1,.35f);

	gameInputCheckBox[0].init(270,550,new int(20),new int(20),basel7Color,false);
	gameInputCheckBox[1].init(270,575,new int(20),new int(20),basel7Color,GameCTFCCNSTS::weaponsEnabled);

	gameOptionsInputCheckBox[0].init(270,350,new int(20),new int(20),basel7Color,Display::fullScreenOnOff);
	gameOptionsInputCheckBox[1].init(270,375,new int(20),new int(20),basel7Color,true);

	currentIntroScreen=0;
}//function end

void GameCTFIntro::update(){//function start
	//update all intro dialgoue objects 
	enterGameMode=false;
	Keyboard::processDefaultKeys();
	
	for(int a=0;a<MAXMESSAGES;++a) Display::stringStatList[a]=NULL;


	gamePanelBase[0].update();
	if(currentIntroScreen==0) {//main intro screen
		for(int a=1;a<6;++a) gamePanelBase[a].update();

		if(gamePanelBase[3].mouseOver&&gamePanelBase[3].mouseButtonState==0){//about button pressed
			currentIntroScreen=1;
			gameAboutBox.color[3]=0;
		}else if(gamePanelBase[1].mouseOver&&gamePanelBase[1].mouseButtonState==0){//play button pressed
			currentIntroScreen=2;
			gameInputBasePanel.color[3]=0;
		}else if(gamePanelBase[2].mouseOver&&gamePanelBase[2].mouseButtonState==0){//options button pressed
			currentIntroScreen=3;
			gameInputBasePanel.color[3]=0;
		}else if(gamePanelBase[4].mouseOver&&gamePanelBase[4].mouseButtonState==0){//exit button pressed
			exit(0);
		}
	}else if(currentIntroScreen==1){//about page
		gameAboutBox.update();
		gamePanelBack.update();
		if(gamePanelBack.mouseOver&&gamePanelBack.mouseButtonState==0)//back button pressed
			currentIntroScreen=0;
	}else if(currentIntroScreen==2){//play screen
		gameInputBasePanel.update();
		gameInputBasePanel2.update();
		gamePanelBack.update();
		gameInputStartPanel.update();

		for(int a=0;a<8;++a) gameInputBoxes[a].update();
		for(int b=0;b<2;++b) gameInputCheckBox[b].update();
		GameCTFCCNSTS::weaponsEnabled=gameInputCheckBox[1].isChecked;

		if(gameInputStartPanel.mouseOver&&gameInputStartPanel.mouseButtonState==0){//start button pressed
			//validate inputs
			enterGameMode=validateInputs();
		}

		if(gamePanelBack.mouseOver&&gamePanelBack.mouseButtonState==0)//back button pressed
			currentIntroScreen=0;
	}else if(currentIntroScreen==3){//options screen
		for(int a=0;a<2;++a) gameOptionsInputCheckBox[a].update();
		
		Display::goFullScreen(gameOptionsInputCheckBox[0].isChecked);
		if(gameOptionsInputCheckBox[1].isChecked&&!gameOptionsInputCheckBox[1].lastCheckedState)
		ExternalFiles::defaultSounds[0].play(true);
		else if(!gameOptionsInputCheckBox[1].isChecked&&gameOptionsInputCheckBox[1].lastCheckedState)
		ExternalFiles::defaultSounds[0].stop();
		gameInputBasePanel.update();
		gameInputBasePanel2.update();
		gamePanelBack.update();

		if(gamePanelBack.mouseOver&&gamePanelBack.mouseButtonState==0)//back button pressed
			currentIntroScreen=0;

	}

}//function end


bool GameCTFIntro::validateInputs(){//function start
//return true if input is successful, false if not
	int b;
	if(!gameInputBoxes[0].textToNumber(&b)) return false;
	else inputWidth=b;
	if(!gameInputBoxes[1].textToNumber(&b)) return false;
	else inputHeight=b;
	if(!gameInputBoxes[2].textToNumber(&b)) return false;
	else inputLength=b;
	if(!gameInputBoxes[3].textToNumber(&b)) return false;
	else inputComplexity=b;
	if(!gameInputBoxes[4].textToNumber(&b)) return false;
	else inputTotalTeams=b;
	if(!gameInputBoxes[5].textToNumber(&b)) return false;
	else inputUnitsPerTeam=b;
	if(!gameInputBoxes[6].textToNumber(&b)) return false;
	else inputWinScore=b;
	if(!gameInputBoxes[7].textToNumber(&b)) return false;
	else inputSpeed=b;

	inputSpecMode=gameInputCheckBox[0].isChecked;
	GameCTFCCNSTS::weaponsEnabled=gameInputCheckBox[1].isChecked;
	return true;
}//function end

void GameCTFIntro::display(){//function start
	//display intro menu/objects
	glPushMatrix();
	Display::initOrthoView();
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
	glEnable(GL_TEXTURE_2D);
	
	gamePanelBase[0].display();//display base panel

	if(currentIntroScreen==0){//base screen
		gamePanelBase[5].display();

		for(int a=1;a<5;++a) gamePanelBase[a].display();

	}else if(currentIntroScreen==1){//about screen
		gameAboutBox.display();
		gamePanelBack.display();
		Display::drawString("Back",815,768/2+348,GLUT_BITMAP_HELVETICA_18);

	}else if(currentIntroScreen==2){//play screen

		gameInputBasePanel.display();
		gameInputBasePanel2.display();
		for(int a=0;a<8;++a) gameInputBoxes[a].display();
		for(int b=0;b<2;++b) gameInputCheckBox[b].display();
		glColor4f(.75,1.0,.75,.75);

		Display::drawString("Map Size",150,340,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Width (2-8)",150,365,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Height (2-8)",150,390,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Length (2-8)",150,415,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Complexity",150,440,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Teams (2-6)",150,490,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Units (1-30)",150,515,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Spectate",150,565,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Weapons Enabled",150,590,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Win Score",150,640,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Speed (50-100)",500,365,GLUT_BITMAP_HELVETICA_12);
		gameInputStartPanel.display();
		Display::drawString("Start",800,645,GLUT_BITMAP_HELVETICA_18);

		gamePanelBack.display();
		Display::drawString("Back",815,768/2+348,GLUT_BITMAP_HELVETICA_18);

	}else if(currentIntroScreen==3){//options screen
		gameInputBasePanel.display();
		gameInputBasePanel2.display();
		for(int b=0;b<2;++b) gameOptionsInputCheckBox[b].display();
		Display::drawString("Options",150,340,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Enable Full Screen",150,365,GLUT_BITMAP_HELVETICA_12);
		Display::drawString("Enable Sound",150,390,GLUT_BITMAP_HELVETICA_12);
		gamePanelBack.display();
		Display::drawString("Back",815,768/2+348,GLUT_BITMAP_HELVETICA_18);
	}

	
	glEnable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	Display::resetPerspectiveProjection();
	glPopMatrix();
}//function end