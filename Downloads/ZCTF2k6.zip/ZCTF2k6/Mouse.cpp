/*
Mouse class: 
Track position and past positions of mouse on screen. Track button clicks
and button states.

All variables and functions are public static.
Last Modded: 5/11/06
*/

#include "Mouse.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////Mouse Variables//////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//enable mouse
bool Mouse::MouseOnOff=true;
//mouse current and previous position
int Mouse::x=0;
int Mouse::y=0;
int Mouse::lastX=0;
int Mouse::lastY=0;
//mouse difference from last position
int Mouse::diffX=0;
int Mouse::diffY=0;
//mouse center of screen
int Mouse::centerX=Display::winX/2;
int Mouse::centerY=Display::winY/2;
//mouse sensitivity
float Mouse::sensitivity=.0002;
//mouse states
int Mouse::mouseState=1;
int Mouse::lastMouseState=1;
int Mouse::mouseButton;
//mouse warp to point
bool Mouse::warpOn=false;
//mouse movement mode (0=slide, 1=fps)
int Mouse::mouseMovementMode=0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////Map Functions//////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Mouse::changeMouseCords(int x1,int y1,int button,int state){//function start
	lastMouseState=mouseState;
	mouseState=state;
	mouseButton=button;
	
	lastX=x;
	lastY=y;
	x=x1;
	y=y1;
	diffX=-(x-lastX);
	diffY=-(y-lastY);

	
	if(mouseMovementMode==1){
		if(warpOn==false){
			warpOn=true;
			glutWarpPointer(Mouse::centerX,Mouse::centerY);	
			return;
		}
		warpOn=false;
		Display::updateMousePointer();
	}
}//function end

void Mouse::changeMouseCords(int x1,int y1){//function start
//update mouse coordinates
	lastX=x;
	lastY=y;
	x=x1;
	y=y1;
	diffX=-(x-lastX);
	diffY=-(y-lastY);

	
	if(mouseMovementMode==1){
		if(warpOn==false){
			warpOn=true;
			glutWarpPointer(Mouse::centerX,Mouse::centerY);	
			return;
		}
		warpOn=false;
		Display::updateMousePointer();
	}


}//function end

void Mouse::changeMouseMovementMode(int mode){//function start
//change from fps hidden mouse to normal menu mouse
	mouseMovementMode=mode;
	if(mode==0){
		glutSetCursor(GLUT_CURSOR_INHERIT); 
	}else if(mode==1){
		glutSetCursor(GLUT_CURSOR_NONE); 
		#ifdef __CARBON__
		CGSetLocalEventsSuppressionInterval(0);
		#endif
	}
}//function end