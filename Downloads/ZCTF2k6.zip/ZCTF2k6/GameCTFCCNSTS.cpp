/*
GameCTFCCNSTS class: Class contains global constants

Last Modded: 5/15/06

*/
#include "GameCTFCCNSTS.h"

bool GameCTFCCNSTS::weaponsEnabled=true;