/*
ParticleElectron class: Class inherits particle class. Contains floating particles about an origin.

Last Modded: 5/15/06
*/
#include "Particle.h"

ParticleElectrons::ParticleElectrons(){//dummy constructor
	isAlive=false;
}//contructor end

void ParticleElectrons::update(){
	if(isAlive){
		for(int a=0;a<3;++a){
			pos[a]-=inVector[a]*Matrix::sincosTable[particleCycle[a]];
			particleCycle[a]=(particleCycle[a]+1)%Matrix::sincosN;

		}

	}
}

void ParticleElectrons::init(float startLife,float startDecay,float radius,float orbitDist,
				float startColor[3]){//function start
			
	life=iLife=startLife;
	decayRate=startDecay;
	isAlive=true;

	color[0]=iColor[0]=startColor[0];
	color[1]=iColor[1]=startColor[1];
	color[2]=iColor[2]=startColor[2];
	size=radius;
	orbitalDistance=orbitDist;
	if(!Matrix::sincosTableLoaded) Matrix::loadSincosTable(100);
	
	vel[0]=iVel[0]=0;
	vel[1]=iVel[1]=0;
	vel[2]=iVel[2]=0;
	acel[0]=iAcel[0]=0;
	acel[1]=iAcel[1]=0;
	acel[2]=iAcel[2]=0;

	//select random x and y pos and determine z
	pos[0]=(rand()%(int)(orbitalDistance*10000))/10000.0f;
	pos[1]=(rand()%((int)(sqrt(orbitalDistance*orbitalDistance-pos[0]*pos[0])*10000)))/10000.0f;
	pos[2]=(sqrt(orbitalDistance*orbitalDistance-pos[0]*pos[0]-pos[1]*pos[1])*10000)/10000.0f;

	for(int a=0;a<3;++a){
		if(rand()%2==0) pos[a]*=-1;
		inVector[a]=pos[a]/Matrix::sincosN;
		particleCycle[a]=rand()%(Matrix::sincosN);
	}

}//function end

void ParticleElectrons::displayPointElectronParticle(float baseAlpha){
	if(isAlive){
		glColor4f(color[0],color[1],color[2],life/iLife*(baseAlpha));
		glVertex3f(pos[0]+origin[0],pos[1]+origin[1],pos[2]+origin[2]);
		//no normals
	}
}

void ParticleElectrons::displaySquareElectronParticle(float baseAlpha){
	if(isAlive){
	
		//billboard effect
		float modelview[16];
		int i,j;
		glPushMatrix();
		glGetFloatv(GL_MODELVIEW_MATRIX,modelview);
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++){
				if(i==j) modelview[i*4+j]=1.0;
				else modelview[i*4+j]=0.0;
			}
		}
		glLoadMatrixf(modelview);

		glColor4f(color[0],color[1],color[2],life/iLife*(baseAlpha));
		glBegin(GL_TRIANGLE_STRIP);
		glTexCoord2d(1,0);
		glVertex3f(pos[0]+size+origin[0],pos[1]-size+origin[1],pos[2]+origin[2]);
		glTexCoord2d(1,1);
		glVertex3f(pos[0]+size+origin[0],pos[1]+size+origin[1],pos[2]+origin[2]);
		glTexCoord2d(0,0);
		glVertex3f(pos[0]-size+origin[0],pos[1]-size+origin[1],pos[2]+origin[2]);
		glTexCoord2d(0,1);
		glVertex3f(pos[0]-size+origin[0],pos[1]+size+origin[1],pos[2]+origin[2]);
		glEnd();

		glPopMatrix();

	}

}