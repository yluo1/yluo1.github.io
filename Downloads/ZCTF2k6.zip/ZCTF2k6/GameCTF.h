#ifndef GAMECTFF
#define GAMECTFF

#include "GLUT/glut.h"
#include <Stdio.h>

#include "ccnst.h"
#include "Math.h"
#include "Mouse.h"
#include "Display.h"
#include "Keyboard.h"
#include "Movement.h"
#include "Time.h"
#include "ExternalFiles.h"

#include "GameCTFMap.h"
#include "GameCTFTeam.h"
#include "GameCTFObject.h"
#include "GameCTFCCNSTS.h"
#include "GameCTFIntro.h"


class GameCTF{//class start
private:

	/////////////////////////////////////////////////////////////
	////////////////////////Game Variables///////////////////////
	/////////////////////////////////////////////////////////////

	short currentScreen;//0: intro screen, 1:game screen
	bool miniMapOn;//0 off, 1 on
	int totalTeams;//total number of teams 
	int unitsPerTeam;//total number of units per team
	bool memorySaveDisplay;//true if faster display mode enabled
	int memorySavePartitions;//number of portal space partitions per room
	bool followMode;//true if spec mode and track unit is on
	int currentSelectedUnit;//track id of selected unit under play control
	int totalUnits;//total number of units
	int lastGoodCameraRoom;//last good display game room
	bool gameInitialized;//true if game is initialized
	int winScore,winner;
	
	/////////////////////intro object////////////////////////////
	GameCTFIntro gameIntro;

	/////////////////////////////////////////////////////////////
	/////////////////////Game Objects////////////////////////////
	/////////////////////////////////////////////////////////////
	GameCTFMap gameField;//game map field
	GameCTFTeam gameTeams[MAXTEAMS];//team objects that are in game
	GameCTFObjectUnit gameUnits[MAXTEAMS*MAXUNITSPERTEAM];//global game units
	GameCTFObjectFlag gameFlags[MAXTEAMS];//global game flags

	/////////////////////////////////////////////////////////////
	/////////////////////Game functions//////////////////////////
	/////////////////////////////////////////////////////////////

	void introRun();//intro screen
	void introInit();//init intro objects
	void gameInit(int inputMapWidth,int inputMapHeight,int inputMapLength,int inputMapComplexity,
					   int inputTotalTeams,int inputUnitsPerTeam,float speedMultiplier);//loading and calculating map, units, regions
	
	void gameRun();//game screen run
	void gameRunDisplay();//game default display function
	void gameRunDisplaySaveMode(int node);//game memory save display function
	void gameRunDisplayFullMode();//
	void gameRunDisplayMinimap(int node);
	void gameRunDisplayUnits();
	void gameRunUpdateFlags();
	void gameRunUpdateTeams();
	void gameRunUpdateUnits();
	void gameKeys();//check game keys
	void gameReset();//restart game
	void gameRunCheckCollisions();
	void gameRunCheckCollisionsRecur(int currentUnit,int currentDepth,int maxDepth,int roomList[10],int roomIndex);
	void gameRunCameraCollisions();
	void gameRunUpdateChanges();

	void gameRunUserInput();//process all user related input
	void gameRunUserUpdateCamera();//update camera based on unit position

	void gameDisplayWinner();
public:
	void init();//loading textures, sound, constants
	void run();//base function to call

};//class end

#endif