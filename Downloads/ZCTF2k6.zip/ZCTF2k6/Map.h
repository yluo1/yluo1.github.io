#ifndef MAPP
#define MAPP

#include <stdlib.h>
#include <stdio.h>
#include <Math.h>


#include "Node.h"
#include "ccnst.h"
#include "time.h"
#include "display.h"
#include "Vertex.h"

#define MAXMAPDIMS 30
#define MAXVERTICES MAXAR*4

class Map{//class start
private:	
	
	static int dirs[6][3];//reference directions
	static int cubeDirs[8][3];
	static float texCorners[4][2];
	//max dims of nodes array
	int mapDimX;
	int mapDimY;
	int mapDimZ;
	int mapComplexity;//complexity of maze
	//[0]:nodeID, [1-6]:tracker number
	int mapMaze6WayMap[MAXMAPDIMS][MAXMAPDIMS][MAXMAPDIMS][7];//track potential edges
	float mapSizeR,mapSizeC,mapSizeD;//physical size limits
	float mapWallRadius;
	float mapWallDistortion;

	void mapMaze6Way();
	void mapMaze6WayRecur(int x,int y,int z);//x,y,z: current positions in array
	void mapMaze6WayForceEdges(int x,int y,int z);//force links into map
	void mapNodesBi(int n1,int n2);//make nodes bi-directional
	void mapNodeCompress();//compress nodes
	void mapVerticesBi(int n1,int n2);//make vertices connect bidirectional
	void mapVerticesRemoveEdge(int n1,int n2);//remove vertices connections on n1 and n2
	//add texturecordinate for vertex triangle configuration
	void mapVertexTextureCoordAdd(int n1,int n2,int n3,float pos1[2],float pos2[2],float pos3[2]);
	void mapMazeNodePrune(int threshold);//threshold = minimum connections for cut
	void mapMazeToNode();//convert into nodes

public:

	Node mapNodes[MAXAR];//Map description
	int mapMaxNodes;//maximum number of nodes
	Vertex *mapVertices;//Walls: triangle structure [n....n+2 is a wall]
	short *vertexGroups;
	int totalVertices;

	Map::Map();//constructor
	//mDim: max dimensions of maze 1-100, complexity: map complexity, ways: mEdges per node
	//size is the world bounds of map
	void mapMaze(int mDimX,int mDimY,int mDimZ,int complexity,int ways,float maxPhysicalSizeR,float maxPhysicalSizeC,float maxPhysicalSizeD,float wallRad,float wallDistortion);
	void mapMaze6WayNodeToVertices();//convert mapmaze and nodes to vertices
	void mapMazeSpliceVertices();//cut all triangle into 3rds
	void display();
	void displayVertices();
	void reset();
	void deleteVertices();
};//class end

#endif