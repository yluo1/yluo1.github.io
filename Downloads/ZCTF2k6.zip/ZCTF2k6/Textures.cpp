/*
Textures class: Creates a texture object that stores color and data info. Contains functions
for displaying textures onto sample text screen. Contains static functions for loading
different formats of image data.

Last Modded: 5/15/06
*/
#include "Textures.h"

float Textures::threshold=100;

Textures::Textures(){//constructor start
}//constructor end


void Textures::drawRGBArray(int x,int y){//function start
	x=x*(Display::winX/1024.0);
	y=y*(Display::winY/768.0);
	Display::setOrthographicProjection();
	glRasterPos2d(x,y+height);
	glDrawPixels(width,height,GL_RGB,GL_UNSIGNED_BYTE,imageData);
	Display::resetPerspectiveProjection();	
}//end of drawRGBArray function

void Textures::LoadBMP(char *filename){//function start
	delete(imageData);
	printf("loading %s, filesize=%d\n",filename,strlen(filename));
	GLubyte BMPFileHeader[14];
	GLubyte BMPInfoHeader[40];
//	GLubyte BMPColorTable[4];
	GLubyte BMPTempData[4];

	unsigned int cByte=0;//current byte
	unsigned int infoSize=0;
	unsigned int bitCount=0;
	unsigned int planes=0;
	unsigned int compression=0;
	unsigned int imageSize=0;
	unsigned int xPixPerM=0;
	unsigned int yPixPerM=0;
	unsigned int colorsUsed=0;
	unsigned int importantColors=0;
	unsigned int bytesPerPixel;
	width=0;
	height=0;
	
	FILE *file=fopen(filename,"rb");
	if(file==NULL){
		fclose(file);
		printf("bad file read\n");
		return;
	}
	fread(BMPFileHeader,1,sizeof(BMPFileHeader),file);
	fread(BMPInfoHeader,1,sizeof(BMPInfoHeader),file);
	
	int a,b,c;
	cByte=0;
	for(a=0;a<4;++a,++cByte) infoSize+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get infoSize
	for(a=0;a<4;++a,++cByte) width+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get width
	for(a=0;a<4;++a,++cByte) height+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get height
	for(a=0;a<2;++a,++cByte) planes+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get planes;
	for(a=0;a<2;++a,++cByte) bitCount+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get bitCount
	for(a=0;a<4;++a,++cByte) compression+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get compression
	for(a=0;a<4;++a,++cByte) imageSize+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get image size
	for(a=0;a<4;++a,++cByte) xPixPerM+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get xPixPerM
	for(a=0;a<4;++a,++cByte) yPixPerM+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get yPixPerM 
	for(a=0;a<4;++a,++cByte) colorsUsed+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get colorsUsed 
	for(a=0;a<4;++a,++cByte) importantColors+=BMPInfoHeader[cByte]*(int)pow(256.0,a);//get importantColors 
	
	bpp=bitCount;
	bytesPerPixel=bpp/8;

	padding=0;
	if((float)(width*bytesPerPixel/4*4)!=(float)(width*bytesPerPixel/4.0*4.0)) 
		padding=(width*bytesPerPixel/4+1)*4-width*bytesPerPixel;

	imageSize=(width*bytesPerPixel+padding)*height;
	imageData=new GLubyte[imageSize];

	printf("width=%d height=%d planes=%d bitcount=%d\ncompression=%d imagesize=%d xPixPerM=%d yPixPerM=%d padding=%d\n",
		width,height,planes,bitCount,compression,imageSize,xPixPerM,yPixPerM,padding);

	if(bpp!=24||compression!=0||infoSize!=40){
		printf("file format not specified\n");
		return;
	}

	cByte=0;
	for(a=0;a<height;++a){
		for(b=0;b<width;++b){
			fread(BMPTempData,1,bytesPerPixel,file);
			for(c=0;c<3;++c) rgbArrayDef[a][b][c]=BMPTempData[c];

			c=rgbArrayDef[a][b][0];//swap r and b
			rgbArrayDef[a][b][0]=rgbArrayDef[a][b][2];
			rgbArrayDef[a][b][2]=c;
			for(c=0;c<3;++c,++cByte) imageData[cByte]=rgbArrayDef[a][b][c];
		}

		if(padding>0){
			fread(BMPTempData,1,padding,file);
			for(b=0;b<padding;++b,++cByte) imageData[cByte]=BMPTempData[b];
		}
	}
	fclose(file);
	printf("cbyte=%d\n",cByte);

}//function end

void Textures::LoadTGA(char *filename){		//function start
	delete(imageData); 
	GLubyte		TGAheader[12]={0,0,2,0,0,0,0,0,0,0,0,0};	// Uncompressed TGA Header
	GLubyte		TGAcompare[12];								// Used To Compare TGA Header
	GLubyte		header[6];									// First 6 Useful Bytes From The Header
	GLuint		bytesPerPixel;								// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint		imageSize;									// Used To Store The Image Size When Setting Aside Ram
	GLuint		temp;										// Temporary Variable
	GLuint		type=GL_RGBA;								// Set The Default GL Mode To RBGA (32 BPP)

	FILE *file = fopen(filename, "rb");						// Open The TGA File

	if(	file==NULL ||										// Does File Even Exist?
		fread(TGAcompare,1,sizeof(TGAcompare),file)!=sizeof(TGAcompare) ||	// Are There 12 Bytes To Read?
		memcmp(TGAheader,TGAcompare,sizeof(TGAheader))!=0				||	// Does The Header Match What We Want?
		fread(header,1,sizeof(header),file)!=sizeof(header))				// If So Read Next 6 Header Bytes
	{
		fclose(file);										// If Anything Failed, Close The File
		printf("bad read\n");
		return;										// Return False
	}
	//////////////////MUST BE POWER OF 2!!!!! POS
	 width  = header[1] * 256 + header[0];			// Determine The TGA Width	(highbyte*256+lowbyte)
	 height = header[3] * 256 + header[2];			// Determine The TGA Height	(highbyte*256+lowbyte)
    
 	if(	 width	<=0	||								// Is The Width Less Than Or Equal To Zero
		 height	<=0	||								// Is The Height Less Than Or Equal To Zero
		(header[4]!=24 && header[4]!=32))	{				// Is The TGA 24 or 32 Bit
		fclose(file);										// If Anything Failed, Close The File
			printf("bad read\n");
		return;										// Return False
	}

	 bpp	= header[4];							// Grab The TGA's Bits Per Pixel (24 or 32)
	bytesPerPixel	=  bpp/8;						// Divide By 8 To Get The Bytes Per Pixel
	imageSize		=  width* height*bytesPerPixel;	// Calculate The Memory Required For The TGA Data

	 imageData=(GLubyte *)malloc(imageSize);		// Reserve Memory To Hold The TGA Data

	if(	 imageData==NULL ||							// Does The Storage Memory Exist?
		fread( imageData, 1, imageSize, file)!=imageSize) {	// Does The Image Size Match The Memory Reserved?
		if( imageData!=NULL)						// Was Image Data Loaded
			free( imageData);						// If So, Release The Image Data

		fclose(file);										// Close The File
		printf("bad read\n");
		return;										// Return False
	}

	for(GLuint i=0; i<int(imageSize); i+=bytesPerPixel)	{	// Loop Through The Image Data
															// Swaps The 1st And 3rd Bytes ('R'ed and 'B'lue)
		temp= imageData[i];							// Temporarily Store The Value At Image Data 'i'
		 imageData[i] =  imageData[i + 2];	// Set The 1st Byte To The Value Of The 3rd Byte
		 imageData[i + 2] = temp;					// Set The 3rd Byte To The Value In 'temp' (1st Byte Value)
	}

	GLuint a,b,c;
	for(a=0;a<height;++a){//Load into rgb reference array
		for(b=0;b<width;++b){
			for(c=0;c<3;++c) rgbArrayDef[a][b][c]=(GLuint)imageData[3*width*a+3*b+c];
		}
	}
	

	fclose (file);											// Close The File
	if (bpp==24)		 {							// Was The TGA 24 Bits
		type=GL_RGB;										// If So Set The 'type' To GL_RGB
	}
	
	// Build A Texture From The Data	
	glGenTextures(1, &texID);					// Generate OpenGL texture IDs	

	return;											// Texture Building Went Ok, Return True
}//function end
