#ifndef GAMECTFTEAMM
#define GAMECTFTEAMM

#include "Display.h"
#include "GameCTFMap.h"
#include "GameCTFCCNSTS.h"
#include "GameCTFObject.h"
#include "String.h"

#define AI_STATE_ATTACK 0
#define AI_STATE_DEFEND 1
#define AI_STATE_COVER 2


class GameCTFTeam{//function start
public:
	float teamColor[3];
	int teamId;
	int teamTotalUnits;
	int totalTeams;
	int score;

	GameCTFObjectUnit *homeTeamUnits[MAXTEAMUNITS];
	GameCTFObjectFlag *homeTeamFlag;
	GameCTFObjectUnit *visitorTeamUnits[MAXTEAMS][MAXTEAMUNITS];
	GameCTFObjectFlag *visitorTeamFlags[MAXTEAMS];

	bool possessedFlags[MAXTEAMS];//true if team unit has flag
	int possessedFlagCarrier[MAXTEAMS];//refer to unit that controls the flag

	int AIState;

	//ForceMaps: Lower sums = higher priority
	float AIForceMapCoords[MAXROOMS][3];
	float AIForceMapFlagRunnerCoords[MAXROOMS][3];
	float AIForceMapDetailCoords[MAXROOMS][3];
	bool AIForceMapEnabledDetailCoords[MAXROOMS];

	int AIForceMapToFlag[MAXROOMS];
	int AIForceMapToHomeFlag[MAXROOMS];
	int AIForceMapTeamRepel[MAXROOMS];
	int AIForceMapVistorAttract[MAXROOMS];
	int AIForceMapFlagRunnerToHome[MAXROOMS];
	int AIForceMapFlagRunnerRepel[MAXROOMS];
	int AIForceMapBaseDistance[MAXROOMS];

	int AIForceMapSize;//total room map size

	GameCTFMap *gameMapRef;//map pointer reference

	GameCTFTeam();
	void init(int id, float color[3],int totalUnits,GameCTFMap *mapRef,int totalNTeams);

	//set pointers for units and flags
	void setHomeTeamUnitPointers(GameCTFObjectUnit *unit);
	void setHomeTeamFlagPointer(GameCTFObjectFlag *flag);
	void setVisitorTeamUnitPointers(GameCTFObjectUnit *unit);
	void setVisitorTeamFlagPointer(GameCTFObjectFlag *flag);

	void update();
	
	//return pointer to specific [3] coord arrays
	float *getNormalTargetRoomCoord(int room);
	float *getFlagRunnerTargetRoomCoord(int room);
	float *getDetailTargetRoomCoord(int room);
	bool getWeaponTarget(float position[3],float *coord);//find target for weapon

	//change AI states of all units
	void changeAIStates(int newState);

	///generate AI Force maps
	void generateAIForceMapToVisitorFlags();
	void generateAIForceMapToHomeFlag(int strength);
	void generateAIForceMapFlagRunnerToHome();
	void generateAIForceMapFlagRunnerRepel();
	void generateAIForceMapTeamRepel();
	void generateAIForceMapVisitorAttract(int strength);
	void generateAIForceMapDefendAttract(int maxDistance);

	//create map for distance from default home flag
	void generateAIForceMapBaseDistance();

	//return target room from cRoom
	int generateAIPathCoordsLocal(int cRoom);
	int generateAIPathCoordsFlagCarrierLocal(int cRoom);
};//function end

#endif