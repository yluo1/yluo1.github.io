#ifndef DEMOSS
#define DEMOSS

#include "GameCTF.h"
class Demos{//start of Demos class
	public:

	//CTF 2k6
	static GameCTF CTFGame;
	static bool CTF2k6FirstRun;
	static void runCTF2k6();


};//end of Demos class

#endif