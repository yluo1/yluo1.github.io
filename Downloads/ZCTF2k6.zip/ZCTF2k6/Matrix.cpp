/*
Matrix Class: 
Contains functions for math trasformations via matricies,
vector specific functions, quaternion math, general linera algebra.
All variables and functions are public static.

Last Modded: 5/11/06
*/
#include "Matrix.h"

void Matrix::MatrixTranslate(float x,float y,float z,float cord[4]){//function start
	//POSTCONDITION: cord contain resultant matrix
	float translationMatrix[4][4]={{1,0,0,x},
									{0,1,0,y},
									{0,0,1,z},
									{0,0,0,1}};
	float vectorMatrix[4][4]={{cord[0],1,1,1},
							{cord[1],1,1,1},
							{cord[2],1,1,1},
							{1,1,1,1}};
	float destMatrix[4][4];
	MatrixMathMultiply(translationMatrix,vectorMatrix,destMatrix,1);
	for(int a=0;a<4;++a) cord[a]=destMatrix[a][0];
}//function end

void Matrix::MatrixScale(float x,float y,float z,float cord[4]){//function start
	//POSTCONDITION: cord contain resultant matrix
	float scaleMatrix[4][4]={{x,0,0,0},
							{0,y,0,0},
							{0,0,z,0},
							{0,0,0,1}};
	float vectorMatrix[4][4]={{cord[0],1,1,1},
							{cord[1],1,1,1},
							{cord[2],1,1,1},
							{1,1,1,1}};
	float destMatrix[4][4];
	MatrixMathMultiply(scaleMatrix,vectorMatrix,destMatrix,1);
	for(int a=0;a<4;++a) cord[a]=destMatrix[a][0];
}//function end

void Matrix::MatrixRotateXAxis(float deg,float cord[4]){//function start
	//POSTCONDITION: cord contain resultant matrix
	float rotMatrix[4][4]={{1,0,0,0},
							{0,(float)cos(deg),-(float)sin(deg),0},
							{0,(float)sin(deg),(float)cos(deg),0},
							{0,0,0,1}};
	float vectorMatrix[4][4]={{cord[0],1,1,1},
							{cord[1],1,1,1},
							{cord[2],1,1,1},
							{1,1,1,1}};
	float destMatrix[4][4];
	MatrixMathMultiply(rotMatrix,vectorMatrix,destMatrix,1);
	for(int a=0;a<4;++a) cord[a]=destMatrix[a][0];
}//function end

void Matrix::MatrixRotateYAxis(float deg,float cord[4]){//function start
	//POSTCONDITION: cord contain resultant matrix
	float rotMatrix[4][4]={{(float)cos(deg),0,(float)sin(deg),0},
							{0,1,0,0},
							{-(float)sin(deg),0,(float)cos(deg),0},
							{0,0,0,1}};
	float vectorMatrix[4][4]={{cord[0],1,1,1},
							{cord[1],1,1,1},
							{cord[2],1,1,1},
							{1,1,1,1}};
	float destMatrix[4][4];
	MatrixMathMultiply(rotMatrix,vectorMatrix,destMatrix,1);
	for(int a=0;a<4;++a) cord[a]=destMatrix[a][0];
}//function end

void Matrix::MatrixRotateZAxis(float deg,float cord[4]){//function start
	//POSTCONDITION: cord contain resultant matrix
	float rotMatrix[4][4]={{(float)cos(deg),-(float)sin(deg),0,0},
							{(float)sin(deg),(float)cos(deg),0,0},
							{0,0,1,0},
							{0,0,0,1}};
	float vectorMatrix[4][4]={{cord[0],1,1,1},
							{cord[1],1,1,1},
							{cord[2],1,1,1},
							{1,1,1,1}};
	float destMatrix[4][4];
	MatrixMathMultiply(rotMatrix,vectorMatrix,destMatrix,1);
	for(int a=0;a<4;++a) cord[a]=destMatrix[a][0];
}//function end

void Matrix::MatrixMathMultiply(float mathMatrix1[4][4],float mathMatrix2[4][4],float destMatrix[4][4],int dCols){//function start
	//POSTCONDITION: cord contain resultant matrix 
	int a,b,c;
	float sum;
	for(a=0;a<4;++a){//going across row
		for(b=0;b<dCols;++b){//go across col
			sum=0;
			for(c=0;c<4;++c){//row/col ref
				sum+=mathMatrix1[a][c]*mathMatrix2[c][b];
			}
			destMatrix[a][b]=sum;
		}
	}
}//function end



void Matrix::MatrixVecCrossProduct(float vec1[3],float vec2[3]){//function start
		//POSTCONDITION: vec2 contain crossproduct vector
	float x,y,z;
	x=vec1[1]*vec2[2]-vec1[2]*vec2[1];
	y=vec1[2]*vec2[0]-vec1[0]*vec2[2];
	z=vec1[0]*vec2[1]-vec1[1]*vec2[0];
	vec2[0]=x;
	vec2[1]=y;
	vec2[2]=z;
}//function end

void Matrix::MatrixVecNormalize(float vec[3]){////function start
	//POSTCONDITION: vec contain normal vector
	float n=(float)sqrt(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
	if(n!=0){
		vec[0]=vec[0]/n;
		vec[1]=vec[1]/n;
		vec[2]=vec[2]/n;
	}
}//function end

float Matrix::MatrixDotProduct(float vec1[3],float vec2[3]){//function start
	return vec1[0]*vec2[0]+vec1[1]*vec2[1]+vec1[2]*vec2[2];
}//function end

float Matrix::MatrixMagnitude(float vec[3]){//start of MatrixMagnitude function
	return (float)sqrt(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
}//end of MatrixMagnitude function	

void Matrix::MatrixFigureRotation(float vec1[3],float vec2[3],float results[4]){//function start
	//POSTCONDITION: results[0-2]=vector [3]=rot angle
	
	results[3]=(float)acos(MatrixDotProduct(vec1,vec2)/(MatrixMagnitude(vec1)*MatrixMagnitude(vec2)));
	MatrixVecCrossProduct(vec1,vec2);
	MatrixVecNormalize(vec2);
	results[0]=vec2[0];
	results[1]=vec2[1];
	results[2]=vec2[2];
	//printf("%f %f %f %f\n",results[3],results[0],results[1],results[2]);
}//function end

void Matrix::MatrixMakeVectors(float centerCord[3],float cord1[3],float cord2[3]){//start of MatrixMakeVector function
	//POSTCONDITION: cord1, cord2 contain new vectors
	for(int a=0;a<3;++a){
		cord1[a]-=centerCord[a];
		cord2[a]-=centerCord[a];
	}
}//end of MatrixMakeVector function


float Matrix::MatrixVecAngle(float vec1[3],float vec2[3]){//function start
	//find angle between two vectors
	return (float)acos(MatrixDotProduct(vec1,vec2)/(MatrixMagnitude(vec1)*MatrixMagnitude(vec2)));
}//function end

short Matrix::Matrix3VerticesCCW(float vertex1[3],float vertex2[3], float vertex3[3]){//function start
	//use Pluecker cordinates
	
	float u1[3]={vertex2[0]-vertex1[0],vertex2[1]-vertex1[1],vertex2[2]-vertex1[2]};
	float u2[3]={vertex3[0]-vertex1[0],vertex3[1]-vertex1[1],vertex3[2]-vertex1[2]};

	float vec1[3]={vertex1[0],vertex1[1],vertex1[2]};
	float vec2[3]={vertex2[0],vertex2[1],vertex2[2]};
	float vec3[3]={vertex3[0],vertex3[1],vertex3[2]};
	
	Matrix::MatrixVecCrossProduct(vec1,vec2);

	Matrix::MatrixVecCrossProduct(vec1,vec3);


	float z=Matrix::MatrixDotProduct(u1,vec3);
	float x=Matrix::MatrixDotProduct(u2,vec2);
	if(z*x>0) return 1;
	else if(z*x<0) return -1;
	else return 0;
}//function end

float Matrix::MatrixNonsqrtDist(float x1,float y1,float z1, float x2,float y2,float z2){//function start
	//return distance between two points is non sqrt mode
	return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2);
}//function end

float Matrix::MatrixDist(float x1,float y1,float z1, float x2,float y2,float z2){//function start
	//return distance between points
	return (float)sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2));
}//function end

float Matrix::MatrixPointDistSquaredFromSegment(float x,float y,float z, float segPt1[3],float segPt2[3]){//function start
    float p[3]={x,y,z};
	float v[3]={segPt2[0]-segPt1[0],segPt2[1]-segPt1[1],segPt2[2]-segPt1[2]};
    float w[3]={p[0]-segPt1[0],p[1]-segPt1[1],p[2]-segPt1[2]};

    float c1=Matrix::MatrixDotProduct(w,v);
    if(c1<=0) return MatrixNonsqrtDist(p[0],p[1],p[2],segPt1[0],segPt1[1],segPt1[2]);

    float c2=Matrix::MatrixDotProduct(v,v);
    if(c2<=c1) return MatrixNonsqrtDist(p[0],p[1],p[2],segPt2[0],segPt2[1],segPt2[2]);
    float b=c1/c2;
	float pb[3]={segPt1[0]+b*v[0],segPt1[1]+b*v[1],segPt1[2]+b*v[2]};
    return  MatrixNonsqrtDist(p[0],p[1],p[2],pb[0],pb[1],pb[2]);
}//function end


void Matrix::QuaternionToMatrix(float quat[4], float matrix[4][4]){
	//POSTCONDITION: matrix contains the conversion
	//PRECONDITION: QUAT is in w,x,y,z form
	int a,b;
	float mm[4][4]={{1-(2*quat[2]*quat[2]+2*quat[3]*quat[3]),2*quat[1]*quat[2]+2*quat[0]*quat[3],2*quat[1]*quat[3]-2*quat[0]*quat[2],0},
					{2*quat[1]*quat[2]-2*quat[0]*quat[3],1-(2*quat[1]*quat[1]+2*quat[3]*quat[3]),2*quat[2]*quat[3]-+2*quat[0]*quat[1],0},
					{2*quat[1]*quat[3]+2*quat[0]*quat[2],2*quat[2]*quat[3]-2*quat[0]*quat[1],1-(2*quat[1]*quat[1]+2*quat[2]*quat[2]),0},
					{0,0,0,1}};
	for(a=0;a<4;++a){//transpose and set matrix
		for(b=0;b<4;++b) matrix[b][a]=mm[a][b];
	}
}

void Matrix::QuaternionMultiply(float quat1[4], float quat2[4]){
	//POSTCONDITION: quat2 contains the concatenation
	//PRECONDITION: QUAT is in w,x,y,z form
	int a;
	float quat3[4]={quat1[0]*quat2[0]-quat1[1]*quat2[1]-quat1[2]*quat2[2]-quat1[3]*quat2[3],
					quat1[0]*quat2[1]+quat1[1]*quat2[0]+quat1[2]*quat2[3]-quat1[3]*quat2[2],
					quat1[0]*quat2[2]-quat1[1]*quat2[3]+quat1[2]*quat2[0]+quat1[3]*quat2[1],
					quat1[0]*quat2[3]+quat1[1]*quat2[2]-quat1[2]*quat2[1]+quat1[3]*quat2[0]};
	

	for(a=0;a<4;++a) quat2[a]=quat3[a];//copy into final quat
	
	QuaternionNormalize(quat2);
}

void Matrix::QuaternionNormalize(float quat1[4]){
	int a;
	float n=(float)sqrt(quat1[0]*quat1[0]+quat1[1]*quat1[1]+quat1[2]*quat1[2]+quat1[3]*quat1[3]);
	for(a=0;a<4;++a) quat1[a]/=n;
}

float Matrix::MathLogisticsCurve(float upBound,float interval1, float interval2,float currentInterval,float steepness, float closeToBound){
	return (float)(upBound/(upBound+pow(100,steepness)/pow(100,(currentInterval-interval1)/(interval2-interval1)*(steepness*closeToBound))));
}

float* Matrix::sincosTable;
bool Matrix::sincosTableLoaded=false;
int Matrix::sincosN=0;
void Matrix::loadSincosTable(int n){//function start
//n is the number of sub intervals
	sincosTableLoaded=true;
	sincosN=n;
	delete [] sincosTable;
	sincosTable=new float[n];
	for(int a=0;a<n;++a){
		sincosTable[a]=(float)sin(2.0*PI/n*a);
	}
}//function end

bool Matrix::MatrixCompare(float *x1,float *x2, int size){//function start
	for(int a=0;a<size;++a){
		if(fabs(*(x1+a)-*(x2+a))>FLOATROUND) return false;
	}
	return true;
}//function end
