/*
GameCTFTeam class: Class contains team color, Id, number of units, total number of teams in game, and score.
Pointer variables to team units, flags, and opposing team units and flags.
Other variables track AI forcemaps for determining next position.

Last Modded: 5/15/06
*/
#include "GameCTFTeam.h"

GameCTFTeam::GameCTFTeam(){

}

void GameCTFTeam::init(int id, float color[3],int totalUnits,GameCTFMap *mapRef,int totalNTeams){//function start
	//reset pointers, set colors and id, set map pointer
	int a,b;

	teamColor[0]=color[0];
	teamColor[1]=color[1];
	teamColor[2]=color[2];
	teamId=id;
	teamTotalUnits=totalUnits;
	totalTeams=totalNTeams;
	score=0;

	//reset pointers
	homeTeamFlag=NULL;
	for(a=0;a<MAXTEAMUNITS;++a) homeTeamUnits[a]=NULL;
	for(a=0;a<MAXTEAMS;++a){
		for(b=0;b<MAXTEAMUNITS;++b) visitorTeamUnits[a][b]=NULL;
		visitorTeamFlags[a]=NULL;
	}

	//reset any flag carriers
	for(a=0;a<MAXTEAMS;++a){
		possessedFlags[a]=false;
		possessedFlagCarrier[a]=0;
	}

	//set pointers and allocate AIForceMap space
	gameMapRef=mapRef;

	AIForceMapSize=(*gameMapRef).gameMap.mapMaxNodes;

	//set initial values
	for(a=0;a<AIForceMapSize;++a){
		AIForceMapToFlag[a]=0;
		AIForceMapTeamRepel[a]=0;
		AIForceMapVistorAttract[a]=0;
		AIForceMapFlagRunnerToHome[a]=0;
		AIForceMapFlagRunnerRepel[a]=0;
		AIForceMapToHomeFlag[a]=0;
		AIForceMapEnabledDetailCoords[a]=false;
	}

	//set AI state
	AIState=AI_STATE_ATTACK;

}

void GameCTFTeam::setHomeTeamUnitPointers(GameCTFObjectUnit *unit){
	homeTeamUnits[(*unit).unitId]=unit;
}

void GameCTFTeam::setHomeTeamFlagPointer(GameCTFObjectFlag *flag){
	homeTeamFlag=flag;
}
void GameCTFTeam::setVisitorTeamUnitPointers(GameCTFObjectUnit *unit){
	visitorTeamUnits[(*unit).teamId][(*unit).unitId]=unit;
}
void GameCTFTeam::setVisitorTeamFlagPointer(GameCTFObjectFlag *flag){
	visitorTeamFlags[(*flag).teamId]=flag;
}

void GameCTFTeam::update(){//function start
	//determine best AI state
	int a;

	//reset all AIForceMaps
	for(a=0;a<AIForceMapSize;++a){
		AIForceMapTeamRepel[a]=0;
		AIForceMapToFlag[a]=0;
		AIForceMapVistorAttract[a]=0;
		AIForceMapFlagRunnerRepel[a]=0;
		AIForceMapFlagRunnerToHome[a]=0;
		AIForceMapToHomeFlag[a]=0;
		AIForceMapEnabledDetailCoords[a]=false;
	}

	//calculate AIForceMaps
	if(AIState==AI_STATE_ATTACK){
		generateAIForceMapToVisitorFlags();
		generateAIForceMapTeamRepel();//generate team repel force map
		generateAIForceMapDefendAttract(5);//attract to units closer to flag

	}else if(AIState==AI_STATE_COVER){
		generateAIForceMapFlagRunnerToHome();
		generateAIForceMapFlagRunnerRepel();
		generateAIForceMapVisitorAttract(AIForceMapSize);
	}

	if((*homeTeamFlag).taken){
		generateAIForceMapToHomeFlag(3);
	}
	
	//check flag status
	int hasAnyFlags=0;
	for(a=0;a<totalTeams;++a){
		if(possessedFlags[a]==true){
			int b=possessedFlagCarrier[a];
			if((*homeTeamUnits[b]).alive){//flag runner is still alive
				++hasAnyFlags;
			}else{//flag runner is dead
				possessedFlags[a]=false;			
			}
		}
	}
	if(hasAnyFlags==0) changeAIStates(AI_STATE_ATTACK);
	else changeAIStates(AI_STATE_COVER);


	/////////////////pass labels to display stat strings
	if(AIState==AI_STATE_ATTACK) Display::stringStatList[teamId]="Team on Attack\n";
	else if(AIState==AI_STATE_COVER) Display::stringStatList[teamId]="Team on Cover\n";
	for(a=0;a<3;++a) Display::stringStatColors[teamId][a]=teamColor[a];
	Display::stringStatColors[teamId][3]=1.0f;

	Display::intStatList[teamId]=score;
	Display::intStatPositions[teamId][0]=950;
	Display::intStatPositions[teamId][1]=50+(teamId+1)*50;
	Display::stringStatPositions[teamId][0]=700;
	Display::stringStatPositions[teamId][1]=50+(teamId+1)*50;
	

}//funtion end

void GameCTFTeam::changeAIStates(int newState){//function start
	AIState=newState;
}//funtion end

float* GameCTFTeam::getNormalTargetRoomCoord(int room){//function start
	//return pointer to normalForceMap coord
	return &AIForceMapCoords[room][0];
}//function end

float* GameCTFTeam::getFlagRunnerTargetRoomCoord(int room){//function start
	//return pointer to flagRunnerlForceMap coord
	return &AIForceMapFlagRunnerCoords[room][0];
}//function end

float *GameCTFTeam::getDetailTargetRoomCoord(int room){
	//return detail coord, check if a specific coord exists first
	return &AIForceMapDetailCoords[room][0];
}
bool GameCTFTeam::getWeaponTarget(float position[3],float *coord){//function start
	//coord is reference to array to put target coord
	float distSq=99999;
	bool state=false;
	int accuracy=350;
	for(int a=0;a<totalTeams;++a){
		if(a!=teamId){
			for(int b=0;b<teamTotalUnits;++b){
				if((*visitorTeamUnits[a][b]).alive){
					float dx=(position[0]-(*visitorTeamUnits[a][b]).posX);
					float dy=(position[1]-(*visitorTeamUnits[a][b]).posY);
					float dz=(position[2]-(*visitorTeamUnits[a][b]).posZ);
					float ds=dx*dx+dy*dy+dz*dz;
					if(ds<SENSEDISTANCE*SENSEDISTANCE){
						if(ds<distSq){
							distSq=ds;
							*coord=		(*visitorTeamUnits[a][b]).posX+myrandomposneg()*rand()%accuracy/100.0f*ds;
							*(coord+1)=	(*visitorTeamUnits[a][b]).posY+myrandomposneg()*rand()%accuracy/100.0f*ds;
							*(coord+2)=	(*visitorTeamUnits[a][b]).posZ+myrandomposneg()*rand()%accuracy/100.0f*ds;
							state=true;
						}
					}
				}
			}	
		}
	}
	return state;
}//function end

/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
///////////////////////////ForceMaps/////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

void GameCTFTeam::generateAIForceMapBaseDistance(){//function start
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int cTrk;
	int a;

	for(a=0;a<AIForceMapSize;++a) trker[a]=false;

	//seed home flag room
	cTrk=0;
	currentPts[cTrk]=(*homeTeamFlag).currentRoom;
	AIForceMapBaseDistance[currentPts[cTrk]]=0;
	trker[currentPts[cTrk]]=true;
	//enable detail flag points
	AIForceMapEnabledDetailCoords[currentPts[cTrk]]=true;
	AIForceMapDetailCoords[currentPts[cTrk]][0]=(*homeTeamFlag).posX;
	AIForceMapDetailCoords[currentPts[cTrk]][1]=(*homeTeamFlag).posY;
	AIForceMapDetailCoords[currentPts[cTrk]][2]=(*homeTeamFlag).posZ;
	++cTrk;

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapBaseDistance[d]=AIForceMapBaseDistance[b]+1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapBaseDistance exceeded cTrk\n");
				break;
			}
		}
	}
}//function end

void GameCTFTeam::generateAIForceMapToVisitorFlags(){//function start
	///make a basic attraction map with visitor flags as source
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int cTrk;
	int a;

	for(a=0;a<AIForceMapSize;++a) trker[a]=false;

	//set seeded pts
	cTrk=0;
	for(a=0;a<MAXTEAMS;++a){
		if(visitorTeamFlags[a]!=NULL){
			currentPts[cTrk]=(*visitorTeamFlags[a]).currentRoom;
			AIForceMapToFlag[currentPts[cTrk]]=0;
			trker[currentPts[cTrk]]=true;
			//enable detail flag points
			AIForceMapEnabledDetailCoords[currentPts[cTrk]]=true;
			AIForceMapDetailCoords[currentPts[cTrk]][0]=(*visitorTeamFlags[a]).posX;
			AIForceMapDetailCoords[currentPts[cTrk]][1]=(*visitorTeamFlags[a]).posY;
			AIForceMapDetailCoords[currentPts[cTrk]][2]=(*visitorTeamFlags[a]).posZ;
			++cTrk;
		}
	}

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapToFlag[d]=AIForceMapToFlag[b]+1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapToFlag exceeded cTrk\n");
				break;
			}
		}

	}

}//function end

void GameCTFTeam::generateAIForceMapToHomeFlag(int strength){//function start
//make a basic attraction map with home flag as source
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int roomStrength[MAXROOMS];
	int cTrk;
	int a;

	for(a=0;a<AIForceMapSize;++a) trker[a]=false;

	//seed home flag room
	cTrk=0;
	currentPts[cTrk]=(*homeTeamFlag).currentRoom;
	AIForceMapToHomeFlag[currentPts[cTrk]]=-1000000;
	trker[currentPts[cTrk]]=true;
	roomStrength[currentPts[cTrk]]=0;
	//enable detail flag points
	AIForceMapEnabledDetailCoords[currentPts[cTrk]]=true;
	AIForceMapDetailCoords[currentPts[cTrk]][0]=(*homeTeamFlag).posX;
	AIForceMapDetailCoords[currentPts[cTrk]][1]=(*homeTeamFlag).posY;
	AIForceMapDetailCoords[currentPts[cTrk]][2]=(*homeTeamFlag).posZ;
	++cTrk;

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]&&roomStrength[d]+1<strength){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapToHomeFlag[d]=AIForceMapToHomeFlag[b]+500;
				roomStrength[d]=roomStrength[b]+1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapToHomeFlag exceeded cTrk\n");
				break;
			}
		}
	}
}//function end

void GameCTFTeam::generateAIForceMapTeamRepel(){//function start
	//avoid taking similar paths as ally units
	//set repel rooms by strength and untRoomCoord
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int cTrk;
	int a,b;

	for(a=0;a<AIForceMapSize;++a){
		trker[a]=false;
		AIForceMapTeamRepel[a]=99999;
	}

	//block ally pts
	for(a=0;a<teamTotalUnits;++a){
		if((*homeTeamUnits[a]).alive){
			b=(*homeTeamUnits[a]).currentRoom;
			trker[b]=true;
			AIForceMapTeamRepel[b]=999999;
		}
	}

	//set seed pts to visitor flags
	cTrk=0;
	for(a=0;a<MAXTEAMS;++a){
		if(visitorTeamFlags[a]!=NULL){
			currentPts[cTrk]=(*visitorTeamFlags[a]).currentRoom;
			AIForceMapTeamRepel[currentPts[cTrk]]=0;
			trker[currentPts[cTrk]]=true;
			++cTrk;
		}
	}

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapTeamRepel[d]=AIForceMapTeamRepel[b]+20;
				++cTrk;
			}
			if(cTrk>=MAXROOMS){
				printf("GameCTFTeam generateAIForceMapTeamRepel exceeded cTrk\n");
				break;
			}
		}
	}


}//function end

void GameCTFTeam::generateAIForceMapVisitorAttract(int strength){//function start
	//if your team has a flag, try to run into that team's own units
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int attractStrength[MAXROOMS];
	int cTrk;
	int a,b;

	for(a=0;a<AIForceMapSize;++a){
		trker[a]=false;
		attractStrength[a]=0;
		AIForceMapVistorAttract[a]=0;
	}

	//set seeded pts
	cTrk=0;
	for(b=0;b<totalTeams;++b){
		if(b!=teamId){
			if(possessedFlags[b]){
				for(a=0;a<MAXTEAMUNITS;++a){
					if((visitorTeamUnits[b][a])==NULL){
						break;
					}else if((*visitorTeamUnits[b][a]).alive){
						currentPts[cTrk]=(*visitorTeamUnits[b][a]).currentRoom;
						trker[currentPts[cTrk]]=true;
						AIForceMapVistorAttract[currentPts[cTrk]]=-AIForceMapSize;
						//enable detail unit points
						AIForceMapEnabledDetailCoords[currentPts[cTrk]]=true;
						AIForceMapDetailCoords[currentPts[cTrk]][0]=(*visitorTeamUnits[b][a]).posX;
						AIForceMapDetailCoords[currentPts[cTrk]][1]=(*visitorTeamUnits[b][a]).posY;
						AIForceMapDetailCoords[currentPts[cTrk]][2]=(*visitorTeamUnits[b][a]).posZ;
						++cTrk;
					}
				}
			}
		}
	}

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]&&attractStrength[d]+1<strength){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapVistorAttract[d]=AIForceMapVistorAttract[b]+1;
				attractStrength[d]=attractStrength[b]+1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapVistorAttract exceeded cTrk\n");
				break;
			}
		}

	}

}//function end

void GameCTFTeam::generateAIForceMapDefendAttract(int maxDistance){//function start
//if any visitor unit gets within maxDistance of flag, then give chase
//max distance is the maximum distance a unit is from home flag
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int attractStrength[MAXROOMS];
	int cTrk;
	int a,b,c;

	for(a=0;a<AIForceMapSize;++a){
		trker[a]=false;
		AIForceMapVistorAttract[a]=0;
	}

	//set seeded pts
	cTrk=0;
	for(b=0;b<totalTeams;++b){
		if(b!=teamId){
			for(a=0;a<MAXTEAMUNITS;++a){
				if((visitorTeamUnits[b][a])==NULL){
					break;
				}else if((*visitorTeamUnits[b][a]).alive){
					c=(*visitorTeamUnits[b][a]).currentRoom;
					if(AIForceMapBaseDistance[c]<maxDistance){
						currentPts[cTrk]=c;
						trker[currentPts[cTrk]]=true;
						attractStrength[currentPts[cTrk]]=maxDistance-AIForceMapBaseDistance[c];
						AIForceMapVistorAttract[currentPts[cTrk]]=-AIForceMapSize;
	
						//enable detail unit points
						AIForceMapEnabledDetailCoords[currentPts[cTrk]]=true;
						AIForceMapDetailCoords[currentPts[cTrk]][0]=(*visitorTeamUnits[b][a]).posX;
						AIForceMapDetailCoords[currentPts[cTrk]][1]=(*visitorTeamUnits[b][a]).posY;
						AIForceMapDetailCoords[currentPts[cTrk]][2]=(*visitorTeamUnits[b][a]).posZ;
						++cTrk;
					}
				}
			}
		}
	}

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]&&attractStrength[d]>0){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapVistorAttract[d]=AIForceMapVistorAttract[b]+1;
				attractStrength[d]=attractStrength[b]-1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapDefendAttract exceeded cTrk\n");
				break;
			}
		}

	}

}//function end

void GameCTFTeam::generateAIForceMapFlagRunnerToHome(){//function start
	///make attraction to hometeam flag spawn location
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int cTrk;
	int a;

	for(a=0;a<AIForceMapSize;++a) trker[a]=false;

	//set seeded pts
	cTrk=0;
	currentPts[cTrk]=(*gameMapRef).flagRooms[teamId];
	AIForceMapFlagRunnerToHome[currentPts[cTrk]]=0;
	trker[currentPts[cTrk]]=true;
	++cTrk;

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapFlagRunnerToHome[d]=AIForceMapFlagRunnerToHome[b]+1;
				++cTrk;
			}
			if(cTrk>MAXROOMS){
				printf("GameCTFTeam generateAIForceMapFlagRunnerToHome exceeded cTrk\n");
				break;
			}
		}

	}

}//function end

void GameCTFTeam::generateAIForceMapFlagRunnerRepel(){//function start
	bool trker[MAXROOMS];
	int currentPts[MAXROOMS];
	int cTrk;
	int a,b;

	for(a=0;a<AIForceMapSize;++a){
		trker[a]=false;
		AIForceMapFlagRunnerRepel[a]=99999;
	}

	//block opponent pts
	for(b=0;b<totalTeams;++b){
		if(b!=teamId){
			for(a=0;a<MAXTEAMUNITS;++a){
				if(visitorTeamUnits[b][a]==NULL) break;
				else if((*visitorTeamUnits[b][a]).alive){
					int visCRoom=(*visitorTeamUnits[b][a]).currentRoom;
					int visLRoom=(*visitorTeamUnits[b][a]).lastRoom;
					trker[visCRoom]=true;
					trker[visLRoom]=true;
					AIForceMapFlagRunnerRepel[visCRoom]=999999;
					AIForceMapFlagRunnerRepel[visLRoom]=999999;
				}
			}
		}
	}

	//set seed pt to home point
	cTrk=0;
	currentPts[cTrk]=(*gameMapRef).flagRooms[teamId];
	AIForceMapFlagRunnerRepel[currentPts[cTrk]]=0;
	trker[currentPts[cTrk]]=true;
	++cTrk;

	for(a=0;a<cTrk;++a){
		int b=currentPts[a];
		for(int c=0;c<(*gameMapRef).gameMap.mapNodes[b].totalEdges;++c){
			int d=(*gameMapRef).gameMap.mapNodes[b].edges[c][0];
			if(!trker[d]){
				trker[d]=true;
				currentPts[cTrk]=d;
				AIForceMapFlagRunnerRepel[d]=AIForceMapFlagRunnerRepel[b]+20;
				++cTrk;
			}
			if(cTrk>=MAXROOMS){
				printf("GameCTFTeam generateAIForceMapFlagRunnerRepel exceeded cTrk\n");
				break;
			}
		}
	}

}//function end

int GameCTFTeam::generateAIPathCoordsLocal(int cRoom){//function start
	if((*gameMapRef).gameMap.mapNodes[cRoom].active){
		int c=AIForceMapToFlag[cRoom]+AIForceMapTeamRepel[cRoom]+AIForceMapVistorAttract[cRoom]+AIForceMapToHomeFlag[cRoom];//find smallest sum
		int d=cRoom;//track best room
		for(int b=0;b<(*gameMapRef).gameMap.mapNodes[cRoom].totalEdges;++b){
			int e=(*gameMapRef).gameMap.mapNodes[cRoom].edges[b][0];
			int sum=AIForceMapToFlag[e]+AIForceMapTeamRepel[e]+AIForceMapVistorAttract[e]+AIForceMapToHomeFlag[e];
			if(sum<c){
				c=sum;
				d=e;
			}

		}
		//set target coord
		AIForceMapCoords[cRoom][0]=(*gameMapRef).gameMap.mapNodes[d].posX;	
		AIForceMapCoords[cRoom][1]=(*gameMapRef).gameMap.mapNodes[d].posY;
		AIForceMapCoords[cRoom][2]=(*gameMapRef).gameMap.mapNodes[d].posZ;
		return d;
	}
	return 0;
	//return the room that AIForceMapCoords reference
}//function end

int GameCTFTeam::generateAIPathCoordsFlagCarrierLocal(int cRoom){
	if((*gameMapRef).gameMap.mapNodes[cRoom].active){
		int c=AIForceMapFlagRunnerToHome[cRoom]+AIForceMapFlagRunnerRepel[cRoom];//find smallest sum
		int d=cRoom;//track best room
		for(int b=0;b<(*gameMapRef).gameMap.mapNodes[cRoom].totalEdges;++b){
			int e=(*gameMapRef).gameMap.mapNodes[cRoom].edges[b][0];
			int sum=AIForceMapFlagRunnerToHome[e]+AIForceMapFlagRunnerRepel[e];
			if(sum<c){
				c=sum;
				d=e;
			}

			
		}
		//set target coord
		AIForceMapFlagRunnerCoords[cRoom][0]=(*gameMapRef).gameMap.mapNodes[d].posX;	
		AIForceMapFlagRunnerCoords[cRoom][1]=(*gameMapRef).gameMap.mapNodes[d].posY;
		AIForceMapFlagRunnerCoords[cRoom][2]=(*gameMapRef).gameMap.mapNodes[d].posZ;
		return d;
	}
	return 0;
}
