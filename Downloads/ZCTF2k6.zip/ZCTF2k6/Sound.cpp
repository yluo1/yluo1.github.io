/*
Sound class: Contains variables for buffer and source position and velocity.

Last Modded: 5/15/06

*/
#include "Sound.h"

Sound::Sound(){//constructor start
}//constructor end

void Sound::init(){//function start
	alutInit(NULL, 0);
	alGetError();

}//function end




void Sound::load(char *name){//function start
	ALenum format;
	ALsizei size;
	ALvoid* data;
	ALsizei freq;
	char al_bool;

	// load wav data into buffers
	alGenBuffers(1,&buffer);

	//check for errors
	if(alGetError()!=AL_NO_ERROR){
		printf("Sound error\n");
		return;
	}

	#ifdef __CARBON__
		alutLoadWAVFile(name, &format, &data, &size, &freq);
	#else
    alutLoadWAVFile((ALbyte*)name,&format,&data,&size,&freq,&al_bool);
	#endif

	alBufferData(buffer,format,data,size,freq);
    alutUnloadWAV(format,data,size,freq);

	// bind buffer data with sources
	alGenSources(1,&source);

	//check for errors
	if(alGetError()!=AL_NO_ERROR){
		printf("Sound error\n");
		return;
	}

	alSourcei(source,AL_BUFFER,buffer);
	alSourcef(source,AL_PITCH,1.0);
	alSourcef(source,AL_GAIN,20.0);
	alSourcefv(source,AL_POSITION,sourcePos);
	alSourcefv(source,AL_VELOCITY,sourceVel);
	alSourcei(source,AL_LOOPING,AL_FALSE);

	//check for errors
	if(alGetError()!=AL_NO_ERROR) {
		printf("Sound error\n");
	}

}//function end



void Sound::remove(){//function start
	// frees memory allocated to Buffers and Sources for current sound file
	alDeleteBuffers(1,&buffer);
	alDeleteSources(1,&source);
	alutExit();
}//function end


void Sound::play(bool loop){//function start
//play current sound file. loop if true
	if(loop) alSourcei(source,AL_LOOPING,AL_TRUE);
	else alSourcei(source,AL_LOOPING,AL_FALSE);
	// play sound
	alSourcePlay(source);
}//function end

void Sound::stop(){//function start
//stop current sound file
	alSourceStop(source);
}//function end
