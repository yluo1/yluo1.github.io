/*
DlgInputBox class: Inputbox class inherits Dlg class. Contains pointer variables to string data.
Contains variables for string length, max string length, priority, current character cursor position,
and if cursor is enabled. 

Last Moded: 5/15/06
*/
#include "Dlg.h"

DlgInputBox::DlgInputBox(){//function start
}//function end

void DlgInputBox::display(){//function start
	if(initialized){
		int a;
		glBlendFunc (GL_SRC_ALPHA, GL_SRC_ALPHA); 
		glColor4f(color[0],color[1],color[2],color[3]);

		glBegin(GL_QUADS);///////draw bounding box
		for(a=0;a<4;++a) glVertex2i(posCorners[a][0],posCorners[a][1]);
		glEnd();
	

		////////draw text
		glColor4f(.5+.5*color[0],.5+.5*color[1],.5+.5*color[2],.5+.5*color[3]);
		glRasterPos2f(posCorners[3][0],posCorners[3][1]-5*Display::winDisplayYFactor);
		for(a=0;a<currentCharPosition;++a){
			if(a>=maxTextLength) break;
			char cc=text[a];
			if(cc>='a'&&cc<='z') cc-='z'-'Z';
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12 ,cc);
		}
		if(hasPriority){
			if(cursorFlash) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12 ,'|');
			else glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12 ,' ');
		}
		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
	}

}//function end

void DlgInputBox::init(int x,int y,int *length,int *height,float colors[4],int maxTextLen,char *initialText){//function start
	posX=x;
	posY=y;
	sizeX=length;
	sizeY=height;
	for(int a=0;a<4;++a) color[a]=baseColor[a]=colors[a];
	color[3]=0;

	initialized=true;
	maxTextLength=maxTextLen;

	if(text!=NULL) delete [] text;
	text=new char[maxTextLen];
	int b;
	for(b=0;b<(signed int)strlen(initialText);++b) text[b]=initialText[b];
	currentCharPosition=b;

	mouseOver=false;
	mouseButtonState=1;

}//function end

void DlgInputBox::update(){//function start
	if(initialized){

		posCorners[0][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[0][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[1][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[1][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[2][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[2][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		posCorners[3][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[3][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		

		mouseButtonState=Mouse::mouseState;
		int x=Mouse::x;
		int y=Mouse::y;
		if(x>=posCorners[0][0]&&x<=posCorners[2][0]&&y>=posCorners[0][1]&&y<=posCorners[2][1]){
			mouseOver=true;
		}else mouseOver=false;

		if(mouseButtonState==0){
			if(mouseOver) hasPriority=true;
			else hasPriority=false;
		}

		if(hasPriority){
			for(int a=0;a<256;++a){
				if(Keyboard::normalKeyArray[a]){
					Keyboard::normalKeyArray[a]=false;
					if(a==8||a==127) currentCharPosition-=(currentCharPosition>0);//backspace
					else if(currentCharPosition<maxTextLength){
						text[currentCharPosition++]=a;	
					}
				}
			}
		}

		color[3]+=(baseColor[3]-color[3])/20.0f;
		cursorFlash=!cursorFlash;
	}
}//function end

bool DlgInputBox::textToNumber(int *dest){//function start
	if(currentCharPosition==0) return false;
	*dest=0;
	for(int a=0;a<currentCharPosition;++a){
		if(text[a]<'0'||text[a]>'9') return false;
		*dest=*dest*10+text[a]-'0';
	}
	return true;
}//function end