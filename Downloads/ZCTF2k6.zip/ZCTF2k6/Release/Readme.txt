ZCTF 2006
Project xkorgine, coded by Mike Luo a.k.a. (fluo,laxkor,nonnaci or |L|)
Music: Prophecy - Iron Cathedral
Site-http://wam.umd.edu/~yluo1
Introduction: 
ZCTF (zeta capture the flag) is a capture the flag clone written as a demo for to showcase the Xkorgine engine. ZCTF is also a test simulation of a refined CTF AI algorithm from the game Ka-Tounen-Soudai, written by myself a year back. Finally, this product serves as a precursor to the continual development of project Xkorgine. Since a large portion of the engine code was written during development, project Xkorgine could not have gotten as far as it did without ZCTF.

Game play:
Many of the standalone CTF rules have been changed in ZCTF. Although the objective of capturing the enemy flags remains the same, ZCTF can incorporate multiple teams in a single game. Furthermore, the game field has been replaced by randomly generated 3D maze-like setting coupled with 360 degrees of movement. The concept of jails has also been removed and instead, collisions between players will result in the temporary deaths of both parties. Other means of tagging are also incorporated into the game play but must be enabled separately. Scoring lies entirely in one�s ability to bring an opponent�s flag not just to their territory, but also to their own flag. Once a team has scored, the flag runner temporary dies and the flags reset.

Players have the option of a first or third person view perspective of their controlling unit. Two types of spectator mode are also added to allow the computer to fight itself. A mini-map can also be toggled on/off to give players an idea of where they are in the world. Players can also cycle through their team units to take control whenever desired. To control a unit, a mouse is needed to give a �pointing direction� and a keyboard for the actual movement.

Mini-map:
Lines indicate paths of the maze field that one can take. The moving color dots represent units on the radar while the cones represent flags. Your position is indicated by crosshair in the middle of the screen. Try to play with the minimap on as it helps to know what's comming towards you and where openings lie.

Flags:
Flags in the game are represented by distinctive wireframe and semi-solid spheres generally larger than normal units. They tend to not move unless you touch them in which case you become the flagrunner and take upon the duty of returning the flag to your own. When you become the flag runner, the colors around you change to match the flag's translucent field making the field easier to see. If tagged in the process, the field vanishes and the flag is automatically placed back at its spawn point. Successfully bringing a flag back to your own will increase your score and cause you to respawn also.

Tagging:
Running into an enemy unit will instantly kill put both you until the spawn delay resets. Other means of tagging are seen in the "arsenal" category and are usually achieved via projectile objects.

Messages: Note that messages are color based

	Team on Attack-Your team is going for the flag
	Team on Cover-Your team has a flag and is trying to cover it from enemies
	Team has your flag-Enemy has your flag so look for him
	Tagged-You've been tagged aka, waiting for respawn
	Hit-Your weapons are enabled and you shot something

Default Keys:
	A-Strafe Left
	D-Strafe Right
	W-Accelerate Forwards
	S-Accelerate Backwards
	C-Strafe Downwards
	Space-Strafe Upwards
	Tab-Toggle Mini-map
	`-Switch Team Units
	F1-Toggle Menu
	F3-Toggle First and Third Person View	
	P-Reroll map

	Click-Fire Normal Rail if enabled

Final:
I intended on adding more �weapons� and other arsenals to the play menu. Since the particle engine I�ve written for this remains relatively untapped, I plan to add more effects in future updates as well as greater variety of sounds. Finally, I would also like to incorporate multiplayer functionality in the future