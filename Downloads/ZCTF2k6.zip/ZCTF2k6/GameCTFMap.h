#ifndef GAMECTFMAPP
#define GAMECTFMAPP

#include "Map.h"
#include "Display.h"
#include "Matrix.h"

#include "GameCTFRoom.h"
#include "GameCTFCCNSTS.h"

class GameCTFMap{//class start
public:
	Map gameMap;//Game field blueprint
	GameCTFRoom gameRooms[MAXROOMS];
	
	short gameMapTotalRooms;
	int totalPolygons;
	int displayDepth;
	bool hasMapGenerated;

	////display lists
	GLuint gameMapDisplayListBigMap;
	GLuint gameMapDisplayListPartialMap;
	GLuint gameMapDisplayListMinimap;

	int flagRooms[MAXTEAMS];

	////////////////Functions
	GameCTFMap();
	void GameCTFMapGenerate(int totalRow,int totalCols,int totalDepths,int complexity,
		float maxPhysicalSizeR,float maxPhysicalSizeC,float maxPhysicalSizeD,
		int triangleSplice,int mazeMethod,
		float wallRadius,float wallDistortion,float vertexDistortion,
		int maxDisplayDepth);

	void GameCTFMapAssignBoundaries(int nTeams,int teamIds[], float teamColors[][3]);
	void GameCTFMapFinalColorPass();

	////display functions
	void GameCTFDisplayWireFrame();
	void GameCTFDisplayNodes();
	void GameCTFDisplayTriangles();
	void GameCTFDisplayTrianglesNormals();
	int GameCTFDisplayPartial(int currentNode);
	void GameCTFDisplayMinimap(int depth,int nTeams,int teamIds[], float teamColors[][3],int currentTeam,int currentNode);
	bool *GameCTFDisplayMinimapTracker;
	void GameCTFMakeDisplayLists(int nTeams,int teamIds[],float teamColors[][3],bool memSaveOn);
	
	//////misc functions
	int nearestNode(float x,float y,float z);//return nearest node from point
	int nearestAdjacentNode(float x,float y,float z, int currentNode);//return nearest adjacent node from current point

	void reset();
private:
	void GameCTFRoomsGenerate();
	void GameCTFDistortVertices(float radius,float percent);
};//class end
#endif