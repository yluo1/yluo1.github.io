#ifndef MATRIXX
#define MATRIXX

#include <Math.h>
#include <Stdio.h>
#include "ccnst.h"
#include "GLUT/glut.h"

class Matrix{//start of Matrix class
public:
	static float *sincosTable;
	static bool sincosTableLoaded;
	static int sincosN;
	static void loadSincosTable(int n);
	
	static void MatrixTranslate(float x,float y,float z,float cord[4]);
	static void MatrixScale(float x,float y,float z,float cord[4]);
	static void MatrixRotateXAxis(float deg,float cord[4]);
	static void MatrixRotateYAxis(float deg,float cord[4]);
	static void MatrixRotateZAxis(float deg,float cord[4]);
	static void MatrixMathMultiply(float mathMatrix1[4][4],float mathMatrix2[4][4],float destMatrix[4][4],int dCols);
	static void MatrixVecCrossProduct(float vec1[3],float vec2[3]);
	static void MatrixVecNormalize(float vec[3]);
	static float MatrixDotProduct(float vec1[3],float vec2[3]);
	static float MatrixMagnitude(float vec[3]);
	static void MatrixFigureRotation(float vec1[3],float vec2[3],float results[4]);
	static void MatrixMakeVectors(float centerCord[3],float cord1[3],float cord2[3]);
	static float MatrixVecAngle(float vec1[3],float vec2[3]);
	static short Matrix3VerticesCCW(float vertex1[3],float vertex2[3], float vertex3[3]);
	static float MathLogisticsCurve(float upBound,float interval1, float interval2,float currentInterval,float steepness,float closeToBound);
	static float MatrixNonsqrtDist(float x1,float y1,float z1, float x2,float y2,float z2);
	static float MatrixDist(float x1,float y1,float z1, float x2,float y2,float z2);
	static float MatrixPointDistSquaredFromSegment(float x,float y,float z, float segPt1[3],float segPt2[3]);
	
	static void QuaternionToMatrix(float quat[4], float matrix[4][4]);
	static void QuaternionMultiply(float quat1[4], float quat2[4]);
	static void QuaternionNormalize(float quat1[4]);

	static bool MatrixCompare(float *x1,float *x2, int size);

};//end of Matrix class

#endif