#ifndef MENUU
#define MENUU

class Menu{//class start
	public:
	static int value;
};//class end

#endif