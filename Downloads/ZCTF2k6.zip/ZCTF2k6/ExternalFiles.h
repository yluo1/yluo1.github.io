#ifndef EXTERNALFILESS 
#define EXTERNALFILESS

#include "Textures.h"
#include "Sound.h"
#include "GLUT/glut.h"

#define MAXTEXTURES 10
#define MAXDOCUMENTS 10

class ExternalFiles{//class start
public:
	static GLuint defaultTextureIds[MAXTEXTURES];//texture IDs
	static Textures defaultTextures[MAXTEXTURES];//texture objects
	
	static Sound defaultSounds[MAXSOUNDS];//sound objects

	static char *defaultDocuments[MAXDOCUMENTS];//pointer to character array
	static void loadDefaultDocuments(char *name);
	
};//class end
#endif