#ifndef GAMECTFROOMM
#define GAMECTFROOMM

#include <stdlib.h>

#include "Display.h"
#include "Vertex.h"
#include "Matrix.h"
#include "PolygonT.h"
#include "GameCTFCCNSTS.h"


class GameCTFRoom{//class start
private:
	
public:

	PolygonT poly[MAXROOMPOLYS];//polygons defined in room
	int polyCount;//count number of polys
	
	int teamId;//team controlling room
	bool active;//true if room is active

	GameCTFRoom();

	void addPoly(Vertex aVertex,Vertex bVertex, Vertex cVertex,float relativeNormalPoint[3]);
	void displayPolys();
	void displayNormals();
	void reset();
};//class end
#endif