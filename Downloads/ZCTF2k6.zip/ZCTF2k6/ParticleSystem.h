#ifndef PARTICLESYSTEMM
#define PARTICLESYSTEMM

#include "GLUT/glut.h"
#include "Particle.h"
#include "ccnst.h"
#include "ExternalFiles.h"

class ParticleSystem{//class start
	public:
	//particle object arrays
	ParticleFireworks fireworksParticles[MAXFIREWORKSPARTICLES];
	ParticleElectrons electronParticles[MAXELECTRONPARTICLES];
	ParticleBeam beamParticles[MAXBEAMPARTICLES];

	bool particleTypesEnabled[10];//true if enabled

	int maxParticles[10];
	int overallMaxSizes[10];
	int systemLife[10];//-1 be indefinite

	float particleOrigin[3];//x,y,z
	
	/////functions
	ParticleSystem();
	void initElectronSystem(int nParticles,float origin[3],float baseColor[3],float mDist,float orbitDist,float life);
	void initFireworkSystem(int nParticles,float origin[3],float baseColor[3],float mDist,float life);
	void initBeamSystem(int nParticles,float origin[3],float target[3],float baseColor[3],float mDist,float life,float *targetCoord);

	void update(float origin[3],float vo[3]);
	void display(float origin[3],float baseAlpha);
	void reset();
};//class end

#endif