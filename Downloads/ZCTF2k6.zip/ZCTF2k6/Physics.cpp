/*
Physics Class: Contains functions for calculating forces, velocities, accelerations, etc

Last Modded: 5/15/06
*/
#include "Physics.h"

float Physics::cnstDistVelAcc(float vo,float acc,float time){//start of cnstDistVelAcc function
	return vo*time+.5f*acc*time*time;
}//end of cnstDistVelAcc function