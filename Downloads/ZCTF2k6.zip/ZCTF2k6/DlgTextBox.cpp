/*
DlgTextBox class: Textbox class inherits Dlg class. Contains pointer variable to text. Also contains
position variables for arrows, text length, calculated characters/line and the total number of lines to display.

Last Modded 5/15/06
*/
#include "Dlg.h"

DlgTextBox::DlgTextBox(){//function start
}//function end

void DlgTextBox::display(){//function start
	if(initialized){
		int a,b,c,d,e;

		////////draw textbox
		glBlendFunc (GL_SRC_ALPHA, GL_SRC_ALPHA); 
		glColor4f(color[0],color[1],color[2],color[3]);

		glBegin(GL_QUADS);
		for(a=0;a<4;++a) glVertex2i(posCorners[a][0],posCorners[a][1]);
		glEnd();

		//draw scroll arrows
		glColor4f(color[0],color[1],color[2],.5+.5*color[3]);
		glBegin(GL_TRIANGLES);
		for(a=0;a<6;++a) glVertex2i(posArrows[a][0],posArrows[a][1]);
		glEnd();

		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
		glBegin(GL_QUADS);
		glVertex2i(posCorners[0][0],posCorners[0][1]*1.05);
		glVertex2i(posCorners[1][0]*.95,posCorners[1][1]*1.05);
		glVertex2i(posCorners[2][0]*.95,posCorners[2][1]*.95);
		glVertex2i(posCorners[3][0],posCorners[3][1]*.95);
		glEnd();



		glBlendFunc (GL_SRC_ALPHA, GL_ONE); 
		////////draw text
		glColor4f(1,1,1,1);

		b=c=0;
		glRasterPos2f(posX*Display::winDisplayXFactor,posY*Display::winDisplayYFactor+15);
		for(a=charStart;a<len;++a){
			d=a,e=0;
			while(!(text[d]==' '||text[d]=='\n')&&d<len){
				++d;
				++e;
			}
			if(b+e>nCharPerLine||text[a]=='\n'){//new line reached so set new raster position
				++c;
				b=0;
				glRasterPos2f(posX*Display::winDisplayXFactor,posY*Display::winDisplayYFactor+(c+1)*15);
				if(c>nLines) break;
			}
			char cc=text[a];
			if(cc>='a'&&cc<='z') cc-='z'-'Z';
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12 ,cc);
			++b;

		}

		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
	}

}//function end

void DlgTextBox::init(int x,int y,int *length,int *height,float colors[4],char *initialText){//function start
	posX=x;
	posY=y;
	sizeX=length;
	sizeY=height;
	for(int a=0;a<4;++a) color[a]=baseColor[a]=colors[a];
	color[3]=0;
	text=initialText;
	initialized=true;
	mouseOver=false;
	mouseButtonState=1;
	len=(signed int)strlen(text);

}//function end

void DlgTextBox::update(){//function start
	if(initialized){//update if initialized

		posCorners[0][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[0][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[1][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[1][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[2][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[2][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		posCorners[3][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[3][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		
		posArrows[0][0]=posCorners[1][0]-*sizeX*.05f*Display::winDisplayXFactor;
		posArrows[0][1]=posCorners[1][1]+*sizeY*.075f*Display::winDisplayYFactor;
		posArrows[1][0]=posCorners[1][0];
		posArrows[1][1]=posCorners[1][1]+*sizeY*.075f*Display::winDisplayYFactor;
		posArrows[2][0]=posCorners[1][0]-*sizeX*.05f*Display::winDisplayXFactor*.5;
		posArrows[2][1]=posCorners[1][1];

		posArrows[3][0]=posCorners[2][0]-*sizeX*.05f*Display::winDisplayXFactor;
		posArrows[3][1]=posCorners[2][1]-*sizeY*.075f*Display::winDisplayYFactor;
		posArrows[4][0]=posCorners[2][0];
		posArrows[4][1]=posCorners[2][1]-*sizeY*.075f*Display::winDisplayYFactor;
		posArrows[5][0]=posCorners[2][0]-*sizeX*.05f*Display::winDisplayXFactor*.5;
		posArrows[5][1]=posCorners[2][1];

		nCharPerLine=(int)(*sizeX/8*Display::winDisplayXFactor);
		nLines=(*sizeY/15)*Display::winDisplayYFactor;

		mouseButtonState=1;
		
		int x=Mouse::x;
		int y=Mouse::y;
		if(x>=posCorners[0][0]&&x<=posCorners[2][0]&&y>=posCorners[0][1]&&y<=posCorners[2][1]){
			mouseOver=true;
		}else mouseOver=false;
	
		if(x>=posArrows[0][0]&&x<=posArrows[1][0]&&y>=posArrows[2][1]&&y<=posArrows[0][1]){
			mouseButtonState=Mouse::mouseState;
			if(mouseButtonState==0){
				if(charStart-nCharPerLine>0) charStart-=nCharPerLine;
				else charStart=0;
			}
		}else if(x>=posArrows[3][0]&&x<=posArrows[1][0]&&y>=posArrows[3][1]&&y<=posArrows[5][1]){
			mouseButtonState=Mouse::mouseState;
			if(mouseButtonState==0){
				if(charStart+nCharPerLine<len) charStart+=nCharPerLine;
				else charStart=len-1;
			}
		}

		color[3]+=(baseColor[3]-color[3])/20.0f;
	}
}//function end