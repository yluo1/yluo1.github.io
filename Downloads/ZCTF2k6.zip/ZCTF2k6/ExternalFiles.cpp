/*
ExternalFiles class: Class contains global file resources such as textures, sounds, and text documents.

Last Modded: 5/15/06
*/
#include "ExternalFiles.h"

//static vars
GLuint ExternalFiles::defaultTextureIds[MAXTEXTURES];
Textures ExternalFiles::defaultTextures[MAXTEXTURES];
char *ExternalFiles::defaultDocuments[MAXDOCUMENTS];
Sound ExternalFiles::defaultSounds[MAXSOUNDS];

void ExternalFiles::loadDefaultDocuments(char *name){//function start
//load external file and readin to dynamically allocated char array
	FILE *fi=fopen(name,"r");
	char c;
	int len=0;
	while(fscanf(fi,"%c",&c)!=EOF) ++len;
	fclose(fi);
	++len;
	for(int a=0;a<MAXDOCUMENTS;++a){
		if(defaultDocuments[a]==NULL){
			defaultDocuments[a]=new char[len];
			fi=fopen(name,"r");
			int b;
			for(b=0;b<len-1;++b) fscanf(fi,"%c",defaultDocuments[a]+b);
			defaultDocuments[a][b]='\0';
			fclose(fi);
			break;
		}
	}

}//function end