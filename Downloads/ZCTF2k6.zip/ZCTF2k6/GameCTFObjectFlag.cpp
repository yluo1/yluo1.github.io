/*
GameCTFObjectFlag class: Class contains variables tracking alive status, mass, flag possession,
team possession, and rotation degree for display.

Last Modded: 5/15/06
*/
#include "GameCTFObject.h"

GameCTFObjectFlag::GameCTFObjectFlag(){
	
}
void GameCTFObjectFlag::init(int teamIdNumber,int objectIdNumber,
		float ccolor[3],
		float totalMass,float sizeRadius,
		GameCTFMap *mapPt){//function start

	teamId=teamIdNumber;
	objectId=objectIdNumber;//refers to the id in the global array
	isMovable=true;
	mass=totalMass;
	color[0]=ccolor[0];
	color[1]=ccolor[1];
	color[2]=ccolor[2];
	radius=sizeRadius;
	initialized=true;
	alive=true;
	mapPointer=mapPt;
	taken=false;
	rot=0;

	setDefaultSpawnLocation();
}//function end

void GameCTFObjectFlag::setDefaultSpawnLocation(){//function start
	currentRoom=(*mapPointer).flagRooms[teamId];
	posX=(*mapPointer).gameMap.mapNodes[currentRoom].posX;
	posY=(*mapPointer).gameMap.mapNodes[currentRoom].posY;
	posZ=(*mapPointer).gameMap.mapNodes[currentRoom].posZ;
}//function end



void GameCTFObjectFlag::display(){//function start
	glColor4f(color[0],color[1],color[2],.5);
	glPushMatrix();
	glTranslatef(posX,posY,posZ);
	glRotatef(rot,1,0,0);
	if(!taken) glEnable(GL_CULL_FACE);
	glutWireSphere((GLdouble)radius,(GLint)10,(GLint)10);
	gluSphere(Display::genericSphere,(GLdouble)radius,(GLint)10,(GLint)10);
	glDisable(GL_CULL_FACE);
	glPopMatrix();
}//function end