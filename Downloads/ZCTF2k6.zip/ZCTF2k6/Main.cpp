/*
Project xkorgine:
Last modded: 10/6/05
Description: xkorgine is a 3d/2d engine that provides multiple libraries and 
functions for application building.

See Demos class for specific applications
*/
////////////////////////////////////////////////Libraries
#include <stdio.h>
#include <iostream>
#include "GLUT/glut.h"
#include "ccnst.h"
#include "Math.h"

#include "Display.h"
#include "Mouse.h"
#include "Keyboard.h"
#include "Menu.h"
#include "Demos.h"
#include "Sound.h"


/////////////////////////////////////////////////PERM FUNCTIONS
void forIdle();
void display();
void changeSize(int w,int h);

//lots of keyboard functions
void processSpecialKeys(int key, int x, int y);
void processNormalKeys(unsigned char key, int x, int y);
void processSpecialKeysUp(int key, int x, int y);
void processNormalKeysUp(unsigned char key, int x, int y);

//load mouse functions
void processMouse(int button, int state, int x, int y);//controls movement with passive and active mouse
void processMousePassiveMotion(int x, int y);
void processMouseActiveMotion(int x, int y);
/////////////////////////////////////////////////Globals
float cTime=0;//current time loop tracker
float frameRate;
/////////////////////////////////////////////////Game functions
void Runner();
void RunnerGameMenus();
void RunnerInit();
void RunnerGameText();
void RunnerGameRun();
void RunnerMenu();
//load Menu functions
void processMenus(int value);

float maxFrameCycle=1000.0/GAMESPEED;

////////////////////////////////////////////////Main loop entry point
int main(int argc, char** argv){//main function

	glutInit(&argc,argv);

	//Window functions
	
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

	if(GAMEMODE){
		glutGameModeString("1024:768:32@75" );
		if(glutGameModeGet(GLUT_GAME_MODE_POSSIBLE)){
			glutEnterGameMode();
			
		}else{
			glutInitWindowSize(Display::winX,Display::winY);
			glutCreateWindow("Xkorgine-M.Luo-ZCTF2k6");  
		}
	}else{
		glutInitWindowSize(Display::winX,Display::winY);
		glutCreateWindow("Xkorgine-M.Luo-ZCTF2k6");  
	}

	glutDisplayFunc(display);  
	glutIdleFunc(forIdle);
	
	//keyboard functions
	glutKeyboardFunc(processNormalKeys);
	glutSpecialFunc(processSpecialKeys);
	glutKeyboardUpFunc(processNormalKeysUp);
	glutSpecialUpFunc(processSpecialKeysUp);
	glutSetKeyRepeat(GLUT_KEY_REPEAT_OFF); 
	//Mouse functions
	glutMouseFunc(processMouse);
	glutMotionFunc(processMouseActiveMotion);
	glutPassiveMotionFunc(processMousePassiveMotion);
	glutReshapeFunc(changeSize);

	//menu functions
	RunnerGameMenus();
	//display class
	RunnerInit();
	glutMainLoop(); 
	return 1;
}//end of function

void forIdle(){//start of function
	float c=glutGet(GLUT_ELAPSED_TIME);
	float dTime=c-cTime;
	if(dTime>=maxFrameCycle){//cap fps at maxFrameCycle
		cTime=c;
		frameRate=(int)(1000.0/dTime);//calc framerates

		Runner();

		glutSwapBuffers();//swap double buffers every update
	}

}//end of function

void display(){//start of function
	glFlush();	
}//end of function

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
///////////////////////////Game Runner////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

void Runner(){
	glClearColor(Display::clearColor[0],Display::clearColor[1],Display::clearColor[2],0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	RunnerGameRun();
	RunnerGameText();
}

void RunnerInit(){
	Display::init();
	Matrix::loadSincosTable(100);//load a sin table
	Sound::init();
	
}

void RunnerGameText(){//start of RunnerGameText function
	Display::displayModelStats(frameRate);
}//end of RunnerGameText function

void RunnerGameRun(){//start of RunnerGameRun function
	//main demo runtime function. All demos are called here.
	Demos::runCTF2k6();
}//end of RunnerGameRun function

void RunnerGameMenus(){//start of RunnerGameMenus function

}//end of RunnerGameMenus function

void processSpecialKeys(int key, int x, int y){//start of processSpecialKeys function
//catch special keys and store in static keyboard variables.
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
	Keyboard::update(key,1);

}//end of processSpecialKeys function

void processNormalKeys(unsigned char key, int x, int y) {//start of processNormalKeys function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
	Keyboard::update(key,1);
}//end of processNormalKeys function

void processSpecialKeysUp(int key, int x, int y){//start of processSpecialKeysUp function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
	Keyboard::update(key,0);
}//end of processSpecialKeysUp function

void processNormalKeysUp(unsigned char key, int x, int y){//start of processNormalKeysUp function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
	Keyboard::update(key,0);
}//end of processNormalKeysUp function

void processMouseActiveMotion(int x, int y){//start of function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
}//end of function

void processMouse(int button, int state, int x, int y){//start of function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y,button,state);
}//end of function

void processMousePassiveMotion(int x, int y){//start of function
	if(Mouse::MouseOnOff==true) Mouse::changeMouseCords(x,y);
}//end of function

void changeSize(int w,int h){//start of changeSize function
	Display::changeScreenSize(w,h);
}//end of changeSize function

void processMenus(int value){//start of processMenus function
	Menu::value=value;
}//end of processMenus function