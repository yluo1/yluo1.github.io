/*
DlgPane class: plane class inherits Dlg class. Contains variables for the associated textures and alpha value.

Last Moded: 5/15/06
*/
#include "Dlg.h"

DlgPane::DlgPane(){//function start
}//function end

void DlgPane::display(){//function start
	if(initialized){

		if(textureId>=0){
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, ExternalFiles::defaultTextureIds[textureId]);	

		}else glDisable(GL_TEXTURE_2D);

		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
		glColor4f(color[0],color[1],color[2],color[3]);
		glBegin(GL_QUADS);
		glTexCoord2d(0,1); glVertex2i(posCorners[0][0],posCorners[0][1]);
		glTexCoord2d(1,1); glVertex2i(posCorners[1][0],posCorners[1][1]);
		glTexCoord2d(1,0); glVertex2i(posCorners[2][0],posCorners[2][1]);
		glTexCoord2d(0,0); glVertex2i(posCorners[3][0],posCorners[3][1]);
		glEnd();
	}
}//function end

void DlgPane::init(int x,int y,int *length,int *height,float colors[4],int texId,float minAlpha){//function start
	posX=x;
	posY=y;
	sizeX=length;
	sizeY=height;
	for(int a=0;a<4;++a) color[a]=baseColor[a]=colors[a];
	color[3]=0;
	textureId=texId;
	initialized=true;
	mouseOver=false;
	mouseButtonState=1;
	baseAlpha=minAlpha;
}//function end

void DlgPane::update(){//function start
	if(initialized){
		//update corner coords of pane
		posCorners[0][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[0][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[1][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[1][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[2][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[2][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		posCorners[3][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[3][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		
		mouseButtonState=1;
		
		int x=Mouse::x;
		int y=Mouse::y;
		if(x>=posCorners[0][0]&&x<=posCorners[1][0]&&y>=posCorners[0][1]&&y<=posCorners[3][1]){//if mouse is over pane, set mouseOver
				mouseOver=true;
		}else mouseOver=false;
	
		if(mouseOver){
			color[3]+=(baseColor[3]-color[3])/20.0f;
			mouseButtonState=Mouse::mouseState;
		}
		else color[3]-=(color[3]-baseAlpha)/20.0f;

	}
}//function end

