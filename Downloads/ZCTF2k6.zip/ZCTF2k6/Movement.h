#ifndef MOVEMENTT
#define MOVEMENTT

#include "Display.h"
#include "Keyboard.h"

class Movement{//class start
public:
	//basic first person camera movement functions
	static void CameraFirstStrafeLeft();
	static void CameraFirstStrafeRight();
	static void CameraFirstForewards();
	static void CameraFirstBackwards();
	static void CameraFirstStrafeUp();
	static void CameraFirstStrafeDown();
	static void CameraFirstZoomIn();
	static void CameraFirstZoomOut();

	static void CameraFirstUpdate();//basic first person camera movement update
};//class end

#endif