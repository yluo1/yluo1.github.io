/*
Display class: Contains routines for setting up a 3D modelview world with basic lighting,
materials, screen resolution, and camera views. Also contains primitive drawing functions and text drawing
algorithms. Also contains an ortho view function for setting up a text screen. All variables and 
functions are public static.

Last Modded: 5/17/06
*/
#include "Display.h"

//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////Display Variables////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

//default window resolution
int Display::defaultWinX=800;
int Display::defaultWinY=600;
//current window resolution
int Display::winX=defaultWinX;
int Display::winY=defaultWinY;
//scaling factor of winresolution to written resolution
float Display::winDisplayXFactor=winX/1024.0f;
float Display::winDisplayYFactor=winY/768.0f;
//target camera position
float Display::tWinCamX=0;
float Display::tWinCamY=0;
float Display::tWinCamZ=0;
float Display::tWinZoom=1;
float Display::tWinCamDistFromTarget=.05;
//current camera position
float Display::winCamX=tWinCamX;
float Display::winCamY=tWinCamY;
float Display::winCamZ=tWinCamZ;
//current camera pointer position
float Display::winPCamX=tWinCamX;
float Display::winPCamY=tWinCamY;
float Display::winPCamZ=tWinCamZ;

//other camera properties
int Display::winPerspectiveAngle=100;
float Display::winCamSpeed=.5;//camera following speed
float Display::winZoom=tWinZoom;
float Display::winInc=.01;
float Display::winUpY[3];
float Display::winCamDistFromTarget=tWinCamDistFromTarget;
float Display::winCameraDistFromTargetFactor=1;
float Display::winCameraMode1Pos[3];
//camera rotation angle and norms 
float Display::winXAxisAngle=0;
float Display::winYAxisAngle=0;
float Display::winCamNorm[3];
//camera min and max cuts
float Display::winMinCut=.001;
float Display::winMaxCut=30.0;

//camera control properties
bool Display::wireFrameOnOff=false;
bool Display::statsOn=true;
bool Display::normDisplayOnOff=false;
bool Display::enableHeadLight=true;
bool Display::enableFog=true;
bool Display::fullScreenOnOff=false;
bool Display::zoomOnOff=false;
bool Display::displayListsOnOff=false;
bool Display::vertexArraysOnOff=true;
short Display::cameraViewMode=0;
bool Display::specMode=true;

//display properties
float Display::clearColor[3]={0.0f,0.0f,0.0f};
GLfloat Display::fogColor[4]= {0.2f, 0.6f, 0.7f, 1.0f};
GLfloat Display::fogDensity=.95f;	
GLfloat Display::fogStart=1.0f;	
GLfloat Display::fogEnd=200.0f;	

//default lighting and materials
GLfloat Display::defaultAmbientLight[] = { 0.2f, 0.3f, 0.6f, 1.0f };
GLfloat Display::defaultDiffuseLight[] = { 1.0f, 1.0f, 1.0, 1.0f };
GLfloat Display::defaultSpecularLight[] = { 0.85f, 0.85f, 0.85f, 1.0f };
GLfloat Display::defaultLightPos[]= {100.0f,0.0f,0,1};

GLfloat Display::defaultMaterialSpecular[]={ .8, .8, .8, 1.0 };
GLfloat Display::defaultMaterialDiffuse[]={.8,.8,.8};
GLfloat Display::defaultMaterialAmbient[]={.8,.8,.8};

//reference figure objects
GLUquadric* Display::genericSphere;
GLUquadric* Display::genericCylinder;

//string display to do at end
char *Display::stringStatList[MAXMESSAGES];
int Display::stringStatPositions[MAXMESSAGES][2];
float Display::stringStatColors[MAXMESSAGES][4];
int Display::intStatList[MAXMESSAGES];
int Display::intStatPositions[MAXMESSAGES][2];

//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////Display functions////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

void Display::changeScreenSize(int x,int y){//function start
//change screen resolution
	winX=x;
	winY=y;
	Mouse::centerX=x/2;
	Mouse::centerY=y/2;
	winDisplayXFactor=winX/1024.0f;
	winDisplayYFactor=winY/768.0f;
	Display::initModelView();
}//function end
void Display::setOrthographicProjection(){//start of function
//set view to 2d 0 to winsize dimensions
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, winX, 0, winY);//non -1 to 1 screen view
	glScalef(1, -1, 1);
	glTranslatef(0, -winY, 0);
	glMatrixMode(GL_MODELVIEW);
}//end of function

void Display::resetPerspectiveProjection() {//start of function
//use in conjunction with setOrthoprojection
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();//pop back
	glMatrixMode(GL_MODELVIEW);
}//end of function

void Display::init(){//function start
	//set all one time things here
	genericSphere=gluNewQuadric();
	gluQuadricNormals(genericSphere,GLU_SMOOTH);
	gluQuadricTexture(genericSphere,true);
    gluQuadricOrientation(genericSphere,GLU_OUTSIDE);
	gluQuadricDrawStyle(genericSphere,GLU_FILL);
	glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);
	glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);

	genericCylinder=gluNewQuadric();
	gluQuadricNormals(genericCylinder,GLU_SMOOTH);
	gluQuadricTexture(genericCylinder,true);

	GLfloat pointSizes[2];
	GLfloat pointStep;
	glGetFloatv(GL_POINT_SIZE_RANGE,pointSizes);
	glGetFloatv(GL_POINT_SIZE_GRANULARITY,&pointStep);
	glPointSize(pointSizes[0]+pointStep*20);


}//function end

void Display::initModelView(){//function start
//set modelview mode and onetime runs
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0,0,Display::winX, Display::winY);
	gluPerspective(winPerspectiveAngle,(float)Display::winX/Display::winY,winMinCut,winMaxCut);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_NORMALIZE);	

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
//	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
	
	if(wireFrameOnOff) glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
	else glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

//	glPolygonMode(GL_FRONT, GL_FILL);
	glShadeModel(GL_SMOOTH);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_FALSE);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,GL_TRUE);

	glMatrixMode(GL_MODELVIEW);	
	glLoadIdentity();
	setHeadLighting();
	setBasicMaterials();
	setNormalFog();
	setNormalLighting();

}//function end

void Display::setBasicMaterials(){//function start
	//set material for all surfaces
	glEnable(GL_COLOR_MATERIAL);

	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, defaultMaterialSpecular);
	glMateriali(GL_FRONT_AND_BACK, GL_SHININESS, 128);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,defaultMaterialDiffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,defaultMaterialAmbient);
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE );

}//function end


void Display::setHeadLighting(){//function start

	glPushMatrix();
	glLoadIdentity();
	GLfloat lightPos[]={0,0,2,1};
	GLfloat lightDir[]={0,0,-1.0};
	GLfloat lightSpec[]={1,1,1};
	GLfloat lightAttenuation[]={.002,0,0};
	GLfloat ambientLight[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
	glLightfv(GL_LIGHT0,GL_SPECULAR,lightSpec);
	glLightf(GL_LIGHT0, GL_SPOT_CUTOFF,1.0);
	glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);	
	glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION,lightDir);
	glLightfv(GL_LIGHT0,GL_QUADRATIC_ATTENUATION ,lightAttenuation);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	if(enableHeadLight)	glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);
	glPopMatrix();

}//function end

void Display::setNormalLighting(){//function start
//set default ambient lighting one
	glLightfv(GL_LIGHT1, GL_POSITION, defaultLightPos);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, defaultDiffuseLight);
	glLightfv(GL_LIGHT1, GL_SPECULAR, defaultSpecularLight);
	glLightfv(GL_LIGHT1, GL_AMBIENT, defaultAmbientLight);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);

}//function end

void Display::setNormalFog(){//function start
	//setup stats for normalfog
	if(enableFog){
		glFogi(GL_FOG_MODE, GL_EXP);	
		glFogfv(GL_FOG_COLOR, fogColor);	
		glFogf(GL_FOG_DENSITY, fogDensity);				
		glHint(GL_FOG_HINT, GL_DONT_CARE);		
		glFogf(GL_FOG_START, fogStart);			
		glFogf(GL_FOG_END, fogEnd);				
		glEnable(GL_FOG);
	}else{
		glDisable(GL_FOG);
	}

}//function end

void Display::initOrthoView(){//start of initOrthoView
	glLoadIdentity();
	setOrthographicProjection();//revert to standard cordinates
}//end of initOrthoView function

void Display::drawString(char *c, int x,int y,void *font){//start of drawString function
	//draw a string c onto large screen, 1028x768
	glRasterPos2f(x*winDisplayXFactor,y*winDisplayYFactor);
	for(int a=0;a<(int)strlen(c);++a){
		glutBitmapCharacter(font ,c[a]);
	}	
}//end of drawString function

void Display::drawNumber(int n,int  x,int y,void *font){//function start
	//draw a number b onto large screen, 1024x768
	//x,y cords are in relation with 1024*768 screen size
	char numAr[10];
	int a,b=0,c=0;
	if(n<0){
		n=n*-1;
		glRasterPos2f(x*winDisplayXFactor,y*winDisplayYFactor);
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18 ,'-');
		c=1;
	}
	do{
		a=n-n/10*10;
		n=n/10;
		numAr[b]=a+'0';
		++b;
	}while(n!=0);
	glRasterPos2f((x+13)*winDisplayXFactor,y*winDisplayYFactor);
	for(b=b-1;b>=0;--b,++c){
		glutBitmapCharacter(font,numAr[b]);
	}
}//function end

void Display::drawTriangle(float x1,float y1,float z1,
					   float x2,float y2,float z2,
					   float x3,float y3,float z3,
					   float nx,float ny,float nz){//function start
	glBegin(GL_TRIANGLES);
	glNormal3f(nx,ny,nz);
	glVertex3f(x1,y1,z1);
	glVertex3f(x2,y2,z2);
	glVertex3f(x3,y3,z3);
	glEnd();
}//function end

void Display::drawQuad(float x1,float y1,float z1,
					   float x2,float y2,float z2,
					   float x3,float y3,float z3,
					   float x4,float y4,float z4,
					   float nx,float ny,float nz){//function start
	glBegin(GL_QUADS);
	glNormal3f(nx,ny,nz);
	glVertex3f(x1,y1,z1);
	glVertex3f(x2,y2,z2);
	glVertex3f(x3,y3,z3);
	glVertex3f(x4,y4,z4);
	glEnd();
}//function end

void Display::drawPolygonMap(float xyzCord[][3],short nSides,
						  float normCord[][3]){//function start
	//PRECONDITION: GLBEGIN DECLARED
	//POSTCONDITION: GLEND DECLARED
	for(int a=0;a<nSides;++a){
		glNormal3f(normCord[a][0],normCord[a][1],normCord[a][2]);
		glVertex3f(xyzCord[a][0],xyzCord[a][1],xyzCord[a][2]);
	}

}//function end

void Display::drawPolygon(float xyzCord[][3],short nSides,
						  float nx,float ny, float nz){//function start
	glBegin(GL_POLYGON);
	glNormal3f(nx,ny,nz);
	for(int a=0;a<nSides;++a) glVertex3f(xyzCord[a][0],xyzCord[a][1],xyzCord[a][2]);
	glEnd();
}//function end

void Display::drawCylinder(float x,float y,float z,
						   float rot,float rx,float ry,float rz,
						   float baseRad,float topRad,float height,
						   float nSlice,float nStack){//function start
	//quick draw cylinders
	glPushMatrix();
	glTranslatef(x,y,z);
	glRotatef(rot,rx,ry,rz);
	gluCylinder(genericCylinder,(GLdouble)baseRad,(GLdouble)topRad,(GLdouble)height,(GLint)nSlice,(GLint)nStack);
	glPopMatrix();
}//function end

void Display::drawCone(float x,float y,float z,
						 float rot,float rx,float ry,float rz,
						 GLdouble baseRad, GLdouble height,
						 GLint slices, GLint stacks){//function start
	glPushMatrix();
	glTranslatef(x,y,z);
	glRotatef(rot,rx,ry,rz);
	glutWireCone((GLdouble)baseRad,(GLdouble)height,(GLint)slices,(GLint)stacks);
	glPopMatrix();
}//function end

void Display::drawTorus(float x,float y,float z,
						float rot,float rx,float ry,float rz,
						   float inner, float outer,
						   float nSides,float nSlices){//function start
	glPushMatrix();
	glTranslatef(x,y,z);
	glRotatef(rot,rx,ry,rz);
	glutSolidTorus((GLdouble)inner,(GLdouble)outer,(GLint)nSides,(GLint)nSlices);
	glPopMatrix();
}//function end

void Display::drawTeapot(float x,float y,float z,
						float rot,float rx,float ry,float rz
						  ){//function start
	glPushMatrix();
	glTranslatef(x,y,z);
	glRotatef(rot,rx,ry,rz);
	if(wireFrameOnOff==false) glutSolidTeapot(.25);
	else glutWireTeapot(.25);
	glPopMatrix();
}//function end

void Display::drawSphere(float x,float y,float z,float radius, float slices, float stacks){//function start
	glPushMatrix();
	glTranslatef(x,y,z);
	if(wireFrameOnOff) glutWireSphere((GLdouble)radius,(GLint)slices,(GLint)stacks);
	else gluSphere(genericSphere,(GLdouble)radius,(GLint)slices,(GLint)stacks);
	glPopMatrix();
}//fuction end

bool Display::particleDisplayListInitialized=false;
GLuint Display::particleDisplayList;
void Display::drawParticle(float size){//function start
	/////////////initialize misc display lists
		
		if(!particleDisplayListInitialized){
			glDeleteLists(particleDisplayList,1);
			particleDisplayList=glGenLists(1);
			glNewList(particleDisplayList,GL_COMPILE);
			glBegin(GL_TRIANGLE_STRIP);
			glTexCoord2d(1,0);
			glVertex3f(size,-size,0);
			glTexCoord2d(1,1);
			glVertex3f(size,size,0);
			glTexCoord2d(0,0);
			glVertex3f(-size,-size,0);
			glTexCoord2d(0,1);
			glVertex3f(-size,size,0);
			glEnd();
			glEndList();
			particleDisplayListInitialized=true;
		}
		glCallList(particleDisplayList);

}//function end

void Display::updateModelCamera(){//function start
//update model camera based for first or third person

	glEnable(GL_LIGHTING);
	//Deceleration of camera movement
	winCamX+=(tWinCamX-winCamX)*winCamSpeed;
	winCamY+=(tWinCamY-winCamY)*winCamSpeed;
	winCamZ+=(tWinCamZ-winCamZ)*winCamSpeed;
	winZoom+=(tWinZoom-winZoom)*winCamSpeed;

	//Mouse to Pointer movement
	updateMousePointer();

	if(winXAxisAngle>360) winXAxisAngle=(winXAxisAngle-360);
	else if(winXAxisAngle<0) winXAxisAngle=360+(winXAxisAngle);
	if(winYAxisAngle>360) winYAxisAngle=(winYAxisAngle-360);
	else if(winYAxisAngle<0) winYAxisAngle=360+(winYAxisAngle);


	//Pointer Math Movement
	float cord[4]={0,0,-100000,1};
	Matrix::MatrixRotateXAxis(winXAxisAngle*PI/180.0,cord);
	Matrix::MatrixRotateYAxis(-winYAxisAngle*PI/180.0,cord);

	//Record Pointer Vector
	winPCamX=cord[0];
	winPCamY=cord[1];
	winPCamZ=cord[2];

	//Update Camera up vector
	float v1[4]={0,1,0,1};
	Matrix::MatrixRotateXAxis(winXAxisAngle*PI/180.0,v1);
	Matrix::MatrixRotateYAxis(-winYAxisAngle*PI/180.0,v1);
	Matrix::MatrixVecNormalize(v1);
	winUpY[0]=v1[0];
	winUpY[1]=v1[1];
	winUpY[2]=v1[2];

	if(cameraViewMode==0){//cc
		if(winCamDistFromTarget>=.0001){
			winCamDistFromTarget*=.9;
			//fist person view based on cameraViewMode 2 implementation
			//the wincamerapositino becomes the focal position
			//both pointer and camera positions are calculated

		
			float thirdCamPos[3]={winCamX-winPCamX,winCamY-winPCamY,winCamZ-winPCamZ};
			Matrix::MatrixVecNormalize(thirdCamPos);
			thirdCamPos[0]*=winCamDistFromTarget;
			thirdCamPos[1]*=winCamDistFromTarget;
			thirdCamPos[2]*=winCamDistFromTarget;
			
			gluLookAt(winCamX+thirdCamPos[0],winCamY+thirdCamPos[1],winCamZ+thirdCamPos[2],
				winCamX,winCamY,winCamZ,
				v1[0],v1[1],v1[2]);
		}else if(winCamDistFromTarget<.0001){
			winCamDistFromTarget=0.0f;
		
			//normal 1'st person view
			//Check for zooming functions and call glulookat
			if(zoomOnOff){//zoom on
				winCamNorm[0]=winPCamX-winCamX;
				winCamNorm[1]=winPCamY-winCamY;
				winCamNorm[2]=winPCamZ-winCamZ;
				Matrix::MatrixVecNormalize(winCamNorm);

				gluLookAt(winCamX+winCamNorm[0]*(1-winZoom)*4,winCamY+winCamNorm[1]*(1-winZoom)*4,winCamZ+winCamNorm[2]*(1-winZoom)*4,
					winPCamX,winPCamY,winPCamZ,
					v1[0],v1[1],v1[2]);
			}else{//zoom off
				gluLookAt(winCamX,winCamY,winCamZ,
					winPCamX,winPCamY,winPCamZ,
					v1[0],v1[1],v1[2]);
			}
		}
	
	}
	else if(cameraViewMode==1){
	//third person view
	//the wincamerapositino becomes the focal position
	//both pointer and camera positions are calculated
		winCamDistFromTarget+=(tWinCamDistFromTarget-winCamDistFromTarget)*.1;
		if(winCamDistFromTarget<FLOATROUND) winCamDistFromTarget=FLOATROUND;
		float thirdCamPos[3]={winCamX-winPCamX,winCamY-winPCamY,winCamZ-winPCamZ};
		Matrix::MatrixVecNormalize(thirdCamPos);
		thirdCamPos[0]*=winCamDistFromTarget;
		thirdCamPos[1]*=winCamDistFromTarget;
		thirdCamPos[2]*=winCamDistFromTarget;

		winCameraMode1Pos[0]=winCamX+thirdCamPos[0];
		winCameraMode1Pos[1]=winCamY+thirdCamPos[1];
		winCameraMode1Pos[2]=winCamZ+thirdCamPos[2];

		float camPtModed[3]={winCamX+thirdCamPos[0]*winCameraDistFromTargetFactor*.6,
							 winCamY+thirdCamPos[1]*winCameraDistFromTargetFactor*.6,
							 winCamZ+thirdCamPos[2]*winCameraDistFromTargetFactor*.6};

		gluLookAt(camPtModed[0],camPtModed[1],camPtModed[2],
				winCamX,winCamY,winCamZ,
				v1[0],v1[1],v1[2]);	
	}	
	
}//function end

void Display::updateMousePointer(){//function start
	//update mouse pointer to mouse angle
	if(Mouse::mouseMovementMode==0){//smoothy cursor
		winYAxisAngle+=Mouse::sensitivity*(((float)Mouse::x-Mouse::centerX)/Mouse::centerX);
		winXAxisAngle-=Mouse::sensitivity*(((float)Mouse::y-Mouse::centerY)/Mouse::centerY);

	}else if(Mouse::mouseMovementMode==1){//fps cursor
		winXAxisAngle-=(float)(Mouse::diffY)*Mouse::sensitivity;
		winYAxisAngle+=(float)(Mouse::diffX)*Mouse::sensitivity;
		Mouse::diffX=0;
		Mouse::diffY=0;
	}
}//function end

void Display::displayModelStats(float frameRate){//function start
	//display cordinate, rotation, fps
	if(statsOn){
		glPushMatrix();
		initOrthoView();
		glDisable(GL_LIGHTING);
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glColor4f(1.0f,1.0f,1.0f,.5f); 

		//display fps
		drawString("FPS: ",20,50,GLUT_BITMAP_HELVETICA_18);
		drawNumber((int)frameRate,75,50,GLUT_BITMAP_HELVETICA_18);
	/*	//display camera angles
		drawString("xa:",20,125,GLUT_BITMAP_HELVETICA_12);
		drawString("ya:",20,150,GLUT_BITMAP_HELVETICA_12);
		drawNumber((int)winXAxisAngle,75,125,GLUT_BITMAP_HELVETICA_12);
		drawNumber((int)winYAxisAngle,75,150,GLUT_BITMAP_HELVETICA_12);
		//display camera positions
		drawString("px:",20,175,GLUT_BITMAP_HELVETICA_12);
		drawString("py:",20,200,GLUT_BITMAP_HELVETICA_12);
		drawString("pz:",20,225,GLUT_BITMAP_HELVETICA_12);
		drawNumber((int)(winCamX*1000),75,175,GLUT_BITMAP_HELVETICA_12);
		drawNumber((int)(winCamY*1000),75,200,GLUT_BITMAP_HELVETICA_12);
		drawNumber((int)(winCamZ*1000),75,225,GLUT_BITMAP_HELVETICA_12);
	*/
		//draw crosshair
		drawString("+",507,384,GLUT_BITMAP_HELVETICA_18);

		//////////display all other messages
		for(int a=0;a<MAXMESSAGES;++a){
			if(stringStatList[a]==NULL) break;
			else{
				glColor4f(stringStatColors[a][0],stringStatColors[a][1],stringStatColors[a][2],stringStatColors[a][3]);
				drawString(stringStatList[a],stringStatPositions[a][0],stringStatPositions[a][1],GLUT_BITMAP_HELVETICA_18);
				drawNumber(intStatList[a],intStatPositions[a][0],intStatPositions[a][1],GLUT_BITMAP_HELVETICA_18);
			}
		}


		glEnable(GL_LIGHTING);
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		resetPerspectiveProjection();
		glPopMatrix();
	}
}//function end

void Display::goFullScreen(bool enableFullScreen){//function start


	if(!enableFullScreen&&fullScreenOnOff){
		glutReshapeWindow(defaultWinX,defaultWinY); 
		glutPositionWindow(100,100); 
		Mouse::mouseState=1;
	}else if(enableFullScreen&&!fullScreenOnOff){//go full screen
		glutFullScreen();
		Mouse::mouseState=1;
	}
	fullScreenOnOff=enableFullScreen;
}//function end
