#ifndef GAMECTFCCNSTSS
#define GAMECTFCCNSTSS

#define MAXTEAMS 9
#define MAXUNITSPERTEAM 30
#define MAXROOMS 1000
#define MAXROOMPOLYS 500
#define MAXTEAMUNITS 15

#define WEAPONFIRERATE 40
#define RAILDISTANCE 8
#define SENSEDISTANCE .5

#define SPAWNDELAY 150

class GameCTFCCNSTS{
public:
	static bool weaponsEnabled;
};


#endif