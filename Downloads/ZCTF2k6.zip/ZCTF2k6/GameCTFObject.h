#ifndef GAMECTFOBJECTT
#define GAMECTFOBJECTT

#include "ccnst.h"
#include "Display.h"
#include "Keyboard.h"
#include "ParticleSystem.h"
#include "ExternalFiles.h"

#include "GameCTFCCNSTS.h"
#include "GameCTFMap.h"



class GameCTFObject{//class start
public:
	float posX,posY,posZ;
	float lastPosX,lastPosY,lastPosZ;
	int teamId;
	int objectId;
	bool initialized;
	float radius;//generic size definition
	float maxRadius;
	bool isMovable;//is object stationed or moveable
	int currentRoom;//what room/node object is in
	int lastRoom,tLastRoom;
	float color[3];
	bool displayListInitialized;
	int displayListId;

	//map reference
	GameCTFMap *mapPointer;


	GameCTFObject();

	virtual void display();
	virtual void reset();
	virtual void init();

};//class end

class GameCTFObjectFlag:public GameCTFObject{//class start
public:
	bool alive;
	float mass;

	bool taken;//if flag has been taken

	int possession;//team currently carrying the flag
	int possessionObjectId;
	float rot;

	GameCTFObjectFlag();

	void init(int teamIdNumber,int objectIdNumber,
		float ccolor[3],
		float totalMass,float sizeRadius,
		GameCTFMap *mapPt);
	void setDefaultSpawnLocation();
	void display();

};

class GameCTFObjectUnit:public GameCTFObject{//class start
public:
	////Static stats
	float aggroDefen;//0-1 for aggressive versus defensive style of play
	float maxSpeed;//0-1 for max change movement per iteration [no physics]
	float speedMultiplier;
	float mass;//0-1, affects how unit is retarded by other forces (flat carrying, gravity) [no physics]
	int detailLevel;//0 to # of max splice/stack in sphere
	int unitId;
	////dynamic properties
	float agroBar;//0-1 for aggression points
	float defenBar;//0-1 for defensive points
	float vel[3];//velocity
	float lastVel[3];
	bool moveKeysPushed;
	bool alive;
	bool hasDied;
	float thetaX,thetaZ;

	float currentTarget[3];

	float spawnDelay;

	bool isCarryingFlag;
	bool flagCarrier[MAXTEAMS];//true if carrying a team's flag

	bool blocked;
	int blockDelay;
	
	bool stateChase;

	float variableCoords[3];//varition added onto currentTarget

	//display particle effects
	ParticleSystem unitParticleSystem;
	
	///weapon variables
	float weaponTargetCoord[3];
	bool weaponOn;

	GameCTFObjectUnit();

	void init(int unitIdNumber, int teamIdNumber,int objectIdNumber,
		float sizeRadius,bool canMove,int maxDetail,
		float ccolor[3],
		float agressionDefense, float topSpeed,float totalMass,
		GameCTFMap *mapPt);

	void spawn();

	void findSetCurrentRoom();

	void generateVariationCoords(float variableRadius);
	
	void updateNextStep();
	void updateCurrentStep();
	
	//AI functions
	void updateAITarget(float *coord,float *safetyCoord,float radiusOfVariation,bool state);
	void updateAIMovement();
	void updateAIWeaponTarget(bool presentTarget, float *targetCoord);

	//user movement functions
	void unitUserUpdate();
	void unitMovementCheck();
	void unitStrafeLeft();
	void unitForewards();
	void unitBackwards();
	void unitStrafeRight();
	void unitStrafeUp();
	void unitStrafeDown();


	void display(bool isSelf);
	void reset();
};//class end

#endif