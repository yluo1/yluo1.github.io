/*
Menu Class: 
Track activity of click menus in opengl

*/
#include "Menu.h"
int Menu::value=-1;

