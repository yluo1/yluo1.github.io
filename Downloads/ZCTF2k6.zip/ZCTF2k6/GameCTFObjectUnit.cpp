/*
GameCTFObjectUnit class: Class contains variables tracking playable unit alive status, hasDied,
if keys are being pressed, AI agrodefo factors, mass, max speed, unit/team/object id, velocity,
last velocity recorded, flag carrying state, last collision (blocked) state, AI state chase,
AI variable target coords, a particle System object, and weapon target Coord.

Last Modded: 5/15/06
*/
#include "GameCTFObject.h"

GameCTFObjectUnit::GameCTFObjectUnit(){
	reset();
}


void GameCTFObjectUnit::display(bool isSelf){//function start
	//display object

	float alpha=0;
	if(isSelf){
		alpha=Display::winCamDistFromTarget/0.25f;
		if(alpha>1) alpha=1;
	}else{
		alpha=1.0f;
	}

	if(alpha>0){
		if(alive){//draw it
			glBindTexture(GL_TEXTURE_2D, ExternalFiles::defaultTextureIds[1]);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glColor4f(color[0],color[1],color[2],alpha);
			glEnable(GL_CULL_FACE); 
			if(!displayListInitialized){
				displayListInitialized=true;
				displayListId=glGenLists(1);
				glNewList(displayListId,GL_COMPILE);
				gluSphere(Display::genericSphere,(GLdouble)radius,(GLint)detailLevel,(GLint)detailLevel);
				glEndList();

				glPushMatrix();
				glTranslatef(posX,posY,posZ);
				glCallList(displayListId);
				glPopMatrix();
			}else{
				glPushMatrix();

				float v1[3]={posX-lastPosX,posY-lastPosY,posZ-lastPosZ};
				Matrix::MatrixVecNormalize(v1);
		
				thetaX+=v1[0]*maxSpeed*500;


	
				if(thetaX<90||thetaX>270) thetaZ+=v1[2]*maxSpeed*500;
				else thetaZ-=v1[2]*maxSpeed*500;

				if(thetaX>=360) thetaX=0;
				else if(thetaX<=0) thetaX=360;

				if(thetaZ>=360) thetaZ=0;
				else if(thetaZ<=0) thetaZ=360;

				glTranslatef(posX,posY,posZ);
				glRotatef(thetaZ,1,0,0);
				glRotatef(thetaX,0,0,1);
			
				glCallList(displayListId);
				glPopMatrix();
				
			}
			glDisable(GL_CULL_FACE); 
		}
	}

	float origin[3]={posX,posY,posZ};
	unitParticleSystem.display(origin,alpha);
}//function end

void GameCTFObjectUnit::init(int unitIdNumber, int teamIdNumber,int objectIdNumber,
		float sizeRadius,bool canMove,int maxDetail,
		float ccolor[3],
		float agressionDefense, float topSpeed,float totalMass,
		GameCTFMap *mapPt){//function start
	//setup unit

	unitId=unitIdNumber;//refers to a unit id on a team
	teamId=teamIdNumber;
	objectId=objectIdNumber;//refers to the id in the global array
	detailLevel=maxDetail;
	isMovable=canMove;
	maxRadius=sizeRadius;
	aggroDefen=agressionDefense;
	mass=totalMass;
	speedMultiplier=topSpeed;
	maxSpeed=((rand()%1000)/200000.0f+.005)*speedMultiplier;
	thetaX=thetaZ=0;

	color[0]=ccolor[0];
	color[1]=ccolor[1];
	color[2]=ccolor[2];
	initialized=true;
	alive=true;
	hasDied=false;
	spawnDelay=SPAWNDELAY;
	mapPointer=mapPt;
	blocked=false;

	isCarryingFlag=false;
	for(int a=0;a<MAXTEAMS;++a) flagCarrier[a]=false;

	if(displayListInitialized) glDeleteLists(displayListId,1);
	displayListInitialized=false;

	spawn();

	unitParticleSystem.reset();
	float origin[3]={posX,posY,posZ};
	unitParticleSystem.initElectronSystem(MAXELECTRONPARTICLES,origin,color,.01,1.5*radius,-1);

}//function end

void GameCTFObjectUnit::spawn(){//function start
	//remake unit in new location
	int randomRoom;
	do{//find spawn location
		randomRoom=rand()%((*mapPointer).gameMapTotalRooms);
	}while(!(*mapPointer).gameRooms[randomRoom].active||(*mapPointer).gameRooms[randomRoom].teamId!=teamId);
	currentRoom=randomRoom;
	lastRoom=currentRoom;
	tLastRoom=0;
	posX=currentTarget[0]=(*mapPointer).gameMap.mapNodes[randomRoom].posX;
	posY=currentTarget[1]=(*mapPointer).gameMap.mapNodes[randomRoom].posY;
	posZ=currentTarget[2]=(*mapPointer).gameMap.mapNodes[randomRoom].posZ;
	maxSpeed=((rand()%1000)/200000.0f+.005)*speedMultiplier; 
	radius=(rand()%10000)/100000.0f*(maxRadius/2)+maxRadius/2;
	stateChase=false;
}//function end

void GameCTFObjectUnit::findSetCurrentRoom(){//function start
	//determine where unit room is
	tLastRoom=currentRoom;
	currentRoom=(*mapPointer).nearestAdjacentNode(posX,posY,posZ,currentRoom);
	if(tLastRoom!=currentRoom) lastRoom=tLastRoom;

}//function end

void GameCTFObjectUnit::generateVariationCoords(float variableRadius){//function start
	//create variation in coords
	for(int a=0;a<3;++a) variableCoords[a]=myrandomposneg()*(rand()%10000)/10000.0f*variableRadius;
}//function end

void GameCTFObjectUnit::updateNextStep(){//function start
	//update next step of unit

	//set limitations
	
	//slash velocity if exceeds max
	unitMovementCheck();

}//function end

void GameCTFObjectUnit::updateCurrentStep(){//function start
	//set currentPosition to next position
	if(alive){//is alive
		lastPosX=posX;
		lastPosY=posY;
		lastPosZ=posZ;

		posX+=vel[0];//update position
		posY+=vel[1];
		posZ+=vel[2];
		lastVel[0]=vel[0];//set last velocities
		lastVel[1]=vel[1];
		lastVel[2]=vel[2];
		findSetCurrentRoom();//check if in same room

		vel[0]=0;//reset velocity
		vel[1]=0;
		vel[2]=0;


		if(hasDied){//death related collision
			hasDied=false;
			alive=false;
			currentRoom=0;
			float origin[3]={posX,posY,posZ};
			unitParticleSystem.initFireworkSystem(MAXFIREWORKSPARTICLES,origin,color,.005*radius,spawnDelay);
			unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_ELECTRONS]=false;
			isCarryingFlag=false;
			for(int a=0;a<MAXTEAMS;++a) flagCarrier[a]=false;
		}
	}else{//not alive
		--spawnDelay;
		if(spawnDelay<=0){//alive again so spawn
			spawnDelay=SPAWNDELAY;
			alive=true;
			spawn();
			unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_ELECTRONS]=true;
		}
	}

	//update particle system
	float origin[3]={posX,posY,posZ};
	float vo[3]={vel[0],vel[1],vel[2]};
	unitParticleSystem.update(origin,vo);
}//function end


void GameCTFObjectUnit::updateAITarget(float *coord,float *safetyCoord,float radiusOfVariation,bool state){//function start
	//state true if chase, false if evade
	if(stateChase) blocked=false;

	if(blocked){//is blocked goto safety pt
		currentTarget[0]=*safetyCoord;
		currentTarget[1]=*(safetyCoord+1);
		currentTarget[2]=*(safetyCoord+2);
		--blockDelay;
		if(blockDelay<=0) blocked=false;
	}else{
		if(stateChase){//chase so no variable coords
			currentTarget[0]=*coord;
			currentTarget[1]=*(coord+1);
			currentTarget[2]=*(coord+2);
		}else{//evade so variable coords
			currentTarget[0]=*coord+variableCoords[0];
			currentTarget[1]=*(coord+1)+variableCoords[1];
			currentTarget[2]=*(coord+2)+variableCoords[2];
		}
		blockDelay=30;
	}

	if((!stateChase&&state!=stateChase)||tLastRoom!=currentRoom){
		generateVariationCoords(radiusOfVariation);
	}
	stateChase=state;

}//function end


void GameCTFObjectUnit::updateAIMovement(){//function start
	float pt[3]={currentTarget[0]-posX,currentTarget[1]-posY,currentTarget[2]-posZ};
	float normPt=sqrt(pt[0]*pt[0]+pt[1]*pt[1]+pt[2]*pt[2]);
	if(normPt==0) normPt=FLOATROUND;
	vel[0]+=pt[0]/normPt*maxSpeed;
	vel[1]+=pt[1]/normPt*maxSpeed;
	vel[2]+=pt[2]/normPt*maxSpeed;
	if(vel[0]>pt[0]) vel[0]=pt[0];
	if(vel[1]>pt[1]) vel[1]=pt[1];
	if(vel[2]>pt[2]) vel[2]=pt[2];
}//function end

void GameCTFObjectUnit::updateAIWeaponTarget(bool presentTarget,float *targetCoord){//function start
	if(alive&&presentTarget&&!unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_BEAM]){
		float origin[3]={posX,posY,posZ};
		float target[3]={*targetCoord,*(targetCoord+1),*(targetCoord+2)};
		float tFinal[3];
		unitParticleSystem.initBeamSystem(MAXBEAMPARTICLES,origin,target,color,RAILDISTANCE,WEAPONFIRERATE,tFinal);
		weaponTargetCoord[0]=tFinal[0];
		weaponTargetCoord[1]=tFinal[1];
		weaponTargetCoord[2]=tFinal[2];
		weaponOn=true;
	}else if(unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_BEAM]){
		weaponOn=false;
	}
}//function end

void GameCTFObjectUnit::unitMovementCheck(){//function start
	//check if vel is over the max speed

	if(vel[0]>maxSpeed) vel[0]=maxSpeed;
	else if(vel[0]<-maxSpeed) vel[0]=-maxSpeed;
	if(vel[1]>maxSpeed) vel[1]=maxSpeed;
	else if(vel[1]<-maxSpeed) vel[1]=-maxSpeed;
	if(vel[2]>maxSpeed) vel[2]=maxSpeed;
	else if(vel[2]<-maxSpeed) vel[2]=-maxSpeed;

}//function end

/////////////////////////////////////////////////////////////////////////  
/////////////////////////user movement functions///////////////////////// 
/////////////////////////////////////////////////////////////////////////  

void GameCTFObjectUnit::unitStrafeLeft(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-posX,-posY,-posZ,pt);
	if(Display::winXAxisAngle>90&&Display::winXAxisAngle<270) 
		Matrix::MatrixRotateYAxis(PI/2.0,pt);
	else Matrix::MatrixRotateYAxis(-PI/2.0,pt);
	float normPt=sqrt(pt[0]*pt[0]+pt[2]*pt[2]);
	//update cords
	vel[0]+=(-pt[0]/normPt)*maxSpeed;
	vel[2]+=(-pt[2]/normPt)*maxSpeed;
	moveKeysPushed=true;

}//function end
void GameCTFObjectUnit::unitStrafeRight(){//function start

	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-posX,-posY,-posZ,pt);
	if(Display::winXAxisAngle>90&&Display::winXAxisAngle<270) 
		Matrix::MatrixRotateYAxis(-PI/2.0,pt);
	else Matrix::MatrixRotateYAxis(PI/2.0,pt);

	float normPt=sqrt(pt[0]*pt[0]+pt[2]*pt[2]);
	//update cords
	vel[0]+=(-pt[0]/normPt)*maxSpeed;
	vel[2]+=(-pt[2]/normPt)*maxSpeed;
	moveKeysPushed=true;

}//function end
void GameCTFObjectUnit::unitForewards(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-posX,-posY,-posZ,pt);
	float normPt=sqrt(pt[0]*pt[0]+pt[1]*pt[1]+pt[2]*pt[2]);
	//update cords
	vel[0]+=(pt[0]/normPt)*maxSpeed;
	vel[1]+=(pt[1]/normPt)*maxSpeed;
	vel[2]+=(pt[2]/normPt)*maxSpeed;
	moveKeysPushed=true;

}//function end

void GameCTFObjectUnit::unitBackwards(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-posX,-posY,-posZ,pt);
	float normPt=sqrt(pt[0]*pt[0]+pt[1]*pt[1]+pt[2]*pt[2]);
	//update cords
	vel[0]+=(-pt[0]/normPt)*maxSpeed;
	vel[1]+=(-pt[1]/normPt)*maxSpeed;
	vel[2]+=(-pt[2]/normPt)*maxSpeed;
	moveKeysPushed=true;
}//function end

void GameCTFObjectUnit::unitStrafeUp(){//function start
	vel[1]+=maxSpeed;
	moveKeysPushed=true;
}//function end

void GameCTFObjectUnit::unitStrafeDown(){//function start
	vel[1]-=maxSpeed;
	moveKeysPushed=true;
}//function end


void GameCTFObjectUnit::unitUserUpdate(){////function start
//update unit movement to keybinds
//check for clicks
	moveKeysPushed=false;
	if(Keyboard::specialKeyArray[GLUT_KEY_LEFT]) unitStrafeLeft();
	if(Keyboard::specialKeyArray[GLUT_KEY_UP]) unitForewards();
	if(Keyboard::specialKeyArray[GLUT_KEY_DOWN]) unitBackwards();
	if(Keyboard::specialKeyArray[GLUT_KEY_RIGHT]) unitStrafeRight();

	if(Keyboard::normalKeyArray[(int)'a'])  unitStrafeLeft();
	if(Keyboard::normalKeyArray[(int)'w'])  unitForewards();
	if(Keyboard::normalKeyArray[(int)'s'])  unitBackwards();
	if(Keyboard::normalKeyArray[(int)'d'])  unitStrafeRight();

	if(Keyboard::normalKeyArray[(int)'A'])  unitStrafeLeft();
	if(Keyboard::normalKeyArray[(int)'W'])  unitForewards();
	if(Keyboard::normalKeyArray[(int)'S'])  unitBackwards();
	if(Keyboard::normalKeyArray[(int)'D'])  unitStrafeRight();

	if(Keyboard::normalKeyArray[(int)'C']) unitStrafeDown();
	if(Keyboard::normalKeyArray[(int)'c']) unitStrafeDown();
	if(Keyboard::normalKeyArray[(int)' ']) unitStrafeUp();

	if(GameCTFCCNSTS::weaponsEnabled){
	//compile differently for mac mouse input
		#ifdef __CARBON__
		if(Mouse::mouseState==1&&Mouse::lastMouseState==0&&!unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_BEAM]){
		#else
		if(Mouse::mouseState==0&&!unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_BEAM]){
		#endif
			float targetCoord[3];
			float origin[3]={posX,posY,posZ};
			float target[3]={Display::winPCamX*.001,Display::winPCamY*.001,Display::winPCamZ*.001};
			unitParticleSystem.initBeamSystem(MAXBEAMPARTICLES,origin,target,color,RAILDISTANCE,WEAPONFIRERATE,targetCoord);
			weaponTargetCoord[0]=targetCoord[0];
			weaponTargetCoord[1]=targetCoord[1];
			weaponTargetCoord[2]=targetCoord[2];
			weaponOn=true;
		}else if(unitParticleSystem.particleTypesEnabled[PARTICLE_TYPE_BEAM]){
			Mouse::lastMouseState=1;
			weaponOn=false;
		}
	}
}//function end

void GameCTFObjectUnit::reset(){//function start
	initialized=false;
	currentRoom=-1;
	unitParticleSystem.reset();
}//function end
