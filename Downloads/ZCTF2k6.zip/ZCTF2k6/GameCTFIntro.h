#ifndef GAMECTFINTROO
#define GAMECTFINTROO

#include <stdlib.h>

#include "Dlg.h"
#include "Keyboard.h"
#include "ccnst.h"
#include "Sound.h"

#include "GameCTFCCNSTS.h"

class GameCTFIntro{//class start
public:
	/////////////////////////////////////////////////////////////
	//////////////////////Intro objects//////////////////////////
	/////////////////////////////////////////////////////////////
	
	//Dlg objects
	DlgPane gamePanelBase[6];
	DlgPane gamePanelBack;
	DlgTextBox gameAboutBox;
	DlgInputBox gameInputBoxes[8];
	DlgPane gameInputBasePanel;
	DlgPane gameInputBasePanel2;
	DlgPane gameInputStartPanel;
	DlgCheckBox gameInputCheckBox[2];
	DlgCheckBox gameOptionsInputCheckBox[2];

	short currentIntroScreen;//track which intro screen user is on
	bool enterGameMode;//true = exit out of intro screen and goto intro screen

	int inputWidth,inputHeight,inputLength,inputComplexity,inputTotalTeams,inputUnitsPerTeam,
		inputWinScore,inputSpeed;
	bool inputSpecMode;//input to reference by other classes

	GameCTFIntro();
	void init();
	void update();
	void display();
	bool validateInputs();//return true if all inputs are valid and set them to input* variables
};//class end

#endif
