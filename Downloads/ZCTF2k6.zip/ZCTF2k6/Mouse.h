#ifndef MOUSEE

#define MOUSEE
#include "ccnst.h"
#include "Display.h"
#include <stdio.h>



////////////////////////////////////////////////

class Mouse{//class start
	public:
	static int x,y;//position of mouse
	static int lastX,lastY;
	static int centerX,centerY;//center of screen
	static int diffX,diffY;
	static float sensitivity;
	static bool MouseOnOff;
	static int mouseState;
	static int lastMouseState;
	static int mouseButton;
	static int mouseMovementMode;

	//udpate mouse functions
	static void changeMouseCords(int x1,int y1,int button,int state);
	static void changeMouseCords(int x1,int y1);
	static void changeMouseMovementMode(int mode);

	private:
	static bool warpOn;
};//class end

#endif