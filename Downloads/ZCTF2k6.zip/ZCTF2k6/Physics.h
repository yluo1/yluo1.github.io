#ifndef PHYSICSS

#define PHYSICSS
#include "ccnst.h"

class Physics{//class start
public:
	static float cnstDistVelAcc(float vo, float acc, float time);
};//class end


#endif