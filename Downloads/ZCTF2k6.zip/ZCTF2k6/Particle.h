/*
Particle class defines different types of particles in the graphics engine


 */
#ifndef PARTICLEE
#define PARTICLEE

#include <stdio.h>
#include <stdlib.h>

#include "GLUT/glut.h"
#include "ccnst.h"
#include "Matrix.h"
#include "Display.h"

class Particle{//class start
public:

	//track basic physics movement attributes
	//track initials
	float iPos[3];
	float iVel[3];
	float iAcel[3];
	float iColor[3];
	//track currents
	float pos[3];
	float vel[3];
	float acel[3];
	float color[3];
	
	//other attributes
	float size;//radius
	float life;
	float iLife;
	float decayRate;
	float airResist;

	bool isAlive;
	
	///////functions
	Particle();

	void init(float startLife,float startDecay,float radius,
				float x,float y,float z,
				float vox,float voy,float voz,
				float aox,float aoy,float aoz,
				float startColor[3]);
	void update(float particleOrigin[3]);
	void displayPointParticle(float baseAlpha);
	void displaySquareParticle(float baseAlpha);
	
};//class end

class ParticleElectrons:public Particle{//class start
public:
	int particleCycle[3];//cycle of repetition
	float inVector[3];//inwards vector for electrons
	float origin[3];//center that particles are spinning about
	float orbitalDistance;//orbit distance from center

	//functions
	ParticleElectrons();
    void init(float startLife,float startDecay,float radius,float orbitDist,
				float startColor[3]);
	void update();
	void displayPointElectronParticle(float baseAlpha);
	void displaySquareElectronParticle(float baseAlpha);
};//class end

class ParticleFireworks:public Particle{//class start
public:
	ParticleFireworks();
	float explosionPower;//greater than 1 for larger effects
	virtual void init(float startLife,float startDecay,float radius,float aResist,
				float x,float y,float z,
				float vox,float voy,float voz,
				float aox,float aoy,float aoz,
				float startColor[3],
				float xPow);
	void update(float particleOrigin[3],float vo[3]);
	void displayPointFireworkParticle(float baseAlpha);
	void displaySquareFireworkParticle(float baseAlpha);
};//class end

class ParticleBeam:public ParticleFireworks{//class start
public:
	ParticleBeam();
	void update();
	void displayPointBeamParticle(float baseAlpha);
	void displaySquareBeamParticle(float baseAlpha);
};//class end

#endif