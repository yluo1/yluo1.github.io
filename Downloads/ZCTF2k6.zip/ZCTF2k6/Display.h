#ifndef DISPLAYY
#define DISPLAYY

#include "ccnst.h"
#include <String.h>
#include "GLUT/glut.h"
#include <Math.h>
#include "Mouse.h"
#include "Matrix.h"


class Display{
public:
	
	static int winX,winY;//Window Sizes
	static int defaultWinX,defaultWinY;
	static int winPerspectiveAngle;//Camera Perspective
	static float winCamX,winCamY,winCamZ;//Camera Positions
	static float winPCamX,winPCamY,winPCamZ;//Pointer Positions
	static float winCameraMode1Pos[3];
	static float winNormAngle;//camera angle about its own normal axis
	static float winXAxisAngle,winYAxisAngle;//Describe Camera Pointer angles
	static float winZoom;
	static float winCamSpeed;///0-1 (also a percent change)
	static float winInc;
	static float winCamNorm[3];
	static float winUpY[3];//track the upward camera vector
	static float winMinCut,winMaxCut;
	static float winCamDistFromTarget;
	static float winCameraDistFromTargetFactor;
	static float winDisplayXFactor,winDisplayYFactor;//ratio of winX/1024 and winY/768

	static float tWinZoom;//target variables ie. increment winCamX up to tWinCamX
	static float tWinCamX,tWinCamY,tWinCamZ;
	static float tWinNormAngle;
	static float tWinCamDistFromTarget;

	static float clearColor[3];

	static GLfloat fogColor[4];
	static GLfloat fogStart;
	static GLfloat fogEnd;
	static GLfloat fogDensity;

	static GLfloat defaultAmbientLight[];
	static GLfloat defaultDiffuseLight[];
	static GLfloat defaultSpecularLight[];
	static GLfloat defaultLightPos[];
	
	static GLfloat defaultMaterialSpecular[];
	static GLfloat defaultMaterialDiffuse[];
	static GLfloat defaultMaterialAmbient[];
	
	static bool statsOn;
	static bool wireFrameOnOff;
	static bool normDisplayOnOff;
	static bool enableHeadLight;
	static bool enableFog;
	static bool fullScreenOnOff;
	static bool zoomOnOff;
	static bool displayListsOnOff;
	static bool vertexArraysOnOff;
	static short cameraViewMode;//0 for first, 1 for third
	static bool specMode;

	static GLUquadric* genericSphere;
	static GLUquadric* genericCylinder;


	static char *stringStatList[MAXMESSAGES];
	static int stringStatPositions[MAXMESSAGES][2];
	static float stringStatColors[MAXMESSAGES][4];
	static int intStatList[MAXMESSAGES];
	static int intStatPositions[MAXMESSAGES][2];



	//////////////////////////////functions

	static void init();//one time set
	static void initModelView();//For inGame
	static void initOrthoView();//For game menus
	static void setOrthographicProjection();
	static void resetPerspectiveProjection();

	static void drawString(char *c,int x,int y,void *font);
	static void drawNumber(int n,int x,int y,void *font);
	static void drawQuad(float x1,float y1,float z1,
					   float x2,float y2,float z2,
					   float x3,float y3,float z3,
					   float x4,float y4,float z4,
					   float nx,float ny,float nz);
	static void drawTriangle(float x1,float y1,float z1,
					   float x2,float y2,float z2,
					   float x3,float y3,float z3,
					   float nx,float ny,float nz);
	static void drawPolygon(float xyzCord[][3],short nSides,float nx,float ny, float nz);
	static void drawPolygonMap(float xyzCord[][3],short nSides,float normCord[][3]);
	static void drawCylinder(float x,float y,float z,
						   float rot,float rx,float ry,float rz,
						   float baseRad,float topRad,float height,
						   float nSlice,float nStack);
	static void drawCone(float x,float y,float z,
						 float rot,float rx,float ry,float rz,
						 GLdouble baseRad, GLdouble height,
                  GLint slices, GLint stacks);

	static void drawTeapot(float x,float y,float z,
						   float rot,float rx,float ry,float rz);
						   
	static void drawTorus(float x,float y,float z,
						   float rot,float rx,float ry,float rz,
						   float inner, float outer,
						   float nSides,float nSlices);
	static void drawSphere(float x,float y,float z,
		float radius, float slices, float stacks);
		
	static bool particleDisplayListInitialized;
	static GLuint particleDisplayList;
	static void drawParticle(float size);
			
	static void displayModelStats(float frameRate);


	static void updateModelCamera();
	static void updateMousePointer();
	static void changeScreenSize(int x,int y);
	static void setBasicMaterials();
	static void setHeadLighting();
	static void setNormalLighting();
	static void setNormalFog();
	static void goFullScreen(bool enableFullScreen);
};

#endif