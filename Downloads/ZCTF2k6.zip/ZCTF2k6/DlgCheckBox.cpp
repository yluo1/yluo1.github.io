/*
DlgCheckBox class: checkbox class inherits Dlg class. Contains variables that tracks "is checked" and
the last checked state of box. 

Last Moded: 5/15/06
*/
#include "Dlg.h"

DlgCheckBox::DlgCheckBox(){//function start
}//function end

void DlgCheckBox::display(){//function start
	if(initialized){//display if initialized

		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		if(isChecked) glColor4f(color[0],color[1],color[2],color[3]);
		else glColor4f(color[0],color[1],color[2],0);

		glBegin(GL_QUADS);
		glVertex2i(posCorners[0][0],posCorners[0][1]);
	    glVertex2i(posCorners[1][0],posCorners[1][1]);
		glVertex2i(posCorners[2][0],posCorners[2][1]);
	    glVertex2i(posCorners[3][0],posCorners[3][1]);
		glEnd();

		glColor4f(.5+.5*color[0],.5+.5*color[1],.5+.5*color[2],.5+.5*color[3]);
		glLineWidth(2);
		glBegin(GL_LINE_STRIP);
		glVertex2i(posCorners[0][0],posCorners[0][1]);
	    glVertex2i(posCorners[1][0],posCorners[1][1]);
		glVertex2i(posCorners[2][0],posCorners[2][1]);
	    glVertex2i(posCorners[3][0],posCorners[3][1]);
		glVertex2i(posCorners[0][0],posCorners[0][1]);
		glEnd();
		glLineWidth(1);
	}
}//function end

void DlgCheckBox::init(int x,int y,int *length,int *height,float colors[4],bool initialCheckState){//function start
	posX=x;
	posY=y;
	sizeX=length;
	sizeY=height;
	for(int a=0;a<4;++a) color[a]=baseColor[a]=colors[a];
	initialized=true;
	mouseOver=false;
	mouseButtonState=1;
	isChecked=lastCheckedState=initialCheckState;

}//function end

void DlgCheckBox::update(){//function start
	if(initialized){//update if initialized
		
		posCorners[0][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[0][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[1][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[1][1]=(int)(posY*Display::winDisplayYFactor);
		posCorners[2][0]=(int)(posX*Display::winDisplayXFactor+*sizeX*Display::winDisplayXFactor);
		posCorners[2][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		posCorners[3][0]=(int)(posX*Display::winDisplayXFactor);
		posCorners[3][1]=(int)(posY*Display::winDisplayYFactor+*sizeY*Display::winDisplayYFactor);
		
		lastMouseButtonState=mouseButtonState;
		mouseButtonState=1;
		
		int x=Mouse::x;
		int y=Mouse::y;
		if(x>=posCorners[0][0]&&x<=posCorners[1][0]&&y>=posCorners[0][1]&&y<=posCorners[3][1]){
			mouseOver=true;
		}else mouseOver=false;
	
		lastCheckedState=isChecked;
		if(mouseOver){//if mouse is over, update button state
			mouseButtonState=Mouse::mouseState;
			if(mouseButtonState==0){//if clicked, toggle check box
				if(lastMouseButtonState!=mouseButtonState) isChecked=!isChecked;	
			}
		}
		
	}
}//function end

