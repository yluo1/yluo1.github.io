/*
ParticleSystem class: ParticleSystem class contains various particle variables for display and tracks individual
system life.

Last Modded: 5/15/06

*/
#include "ParticleSystem.h"

ParticleSystem::ParticleSystem(){

}


void ParticleSystem::initElectronSystem(int nParticles,float origin[3],float baseColor[3],float mDist,float orbitDist,float life){//function start

	maxParticles[PARTICLE_TYPE_ELECTRONS]=nParticles;
	particleTypesEnabled[PARTICLE_TYPE_ELECTRONS]=true;
	
	particleOrigin[0]=origin[0];
	particleOrigin[1]=origin[1];
	particleOrigin[2]=origin[2];

	systemLife[PARTICLE_TYPE_ELECTRONS]=life;
	for(int a=0;a<nParticles;++a){//init fireworks particles
		float color[3]={baseColor[0]*(((rand()%250)+750)/1000.0f),
						baseColor[1]*(((rand()%250)+750)/1000.0f),
						baseColor[2]*(((rand()%250)+750)/1000.0f)};

		electronParticles[a].init(100,1.0f,.0025,mDist,
			color);
	}

}//function end

void ParticleSystem::initFireworkSystem(int nParticles,float origin[3],float baseColor[3],float mDist,float life){//function start

	maxParticles[PARTICLE_TYPE_FIREWORKS]=nParticles;
	particleTypesEnabled[PARTICLE_TYPE_FIREWORKS]=true;
	
	particleOrigin[0]=origin[0];
	particleOrigin[1]=origin[1];
	particleOrigin[2]=origin[2];

	systemLife[PARTICLE_TYPE_FIREWORKS]=life;
	for(int a=0;a<nParticles;++a){//init fireworks particles
		float color[3]={baseColor[0]*(((rand()%500)+500)/1000.0f),
						baseColor[1]*(((rand()%500)+500)/1000.0f),
						baseColor[2]*(((rand()%500)+500)/1000.0f)};

		fireworksParticles[a].init(life,1.0f,.005,.1,
			0,0,0,
			((rand()%1000)-500)/100000.0f,((rand()%1000)-500)/100000.0f,((rand()%1000)-500)/100000.0f,
			0,0,0,
			color,
			1);
	}

}//function end

void ParticleSystem::initBeamSystem(int nParticles,float origin[3],float target[3],float baseColor[3],float mDist,float life,float *targetCoord){//function start

	maxParticles[PARTICLE_TYPE_BEAM]=nParticles;
	particleTypesEnabled[PARTICLE_TYPE_BEAM]=true;
	
	particleOrigin[0]=origin[0];
	particleOrigin[1]=origin[1];
	particleOrigin[2]=origin[2];

	systemLife[PARTICLE_TYPE_BEAM]=life;
	float vec[3]={target[0]-origin[0],target[1]-origin[1],target[2]-origin[2]};//vector from origin to target
	Matrix::MatrixVecNormalize(vec);
	vec[0]*=mDist;
	vec[1]*=mDist;
	vec[2]*=mDist;
	
	*targetCoord=origin[0]+vec[0];
	*(targetCoord+1)=origin[1]+vec[1];
	*(targetCoord+2)=origin[2]+vec[2];

	for(int a=0;a<nParticles;++a){//init fireworks particles
		float color[3]={baseColor[0]*(((rand()%300)+800)/1000.0f),
						baseColor[1]*(((rand()%300)+800)/1000.0f),
						baseColor[2]*(((rand()%300)+800)/1000.0f)};
		float interval=(rand()%100000)/100000.0f;

		beamParticles[a].init(life,1.0f,.005,.75,
			origin[0]+vec[0]*interval,origin[1]+vec[1]*interval,origin[2]+vec[2]*interval,
			myrandomposneg()*(rand()%1000)*.000001,myrandomposneg()*(rand()%1000)*.000001,myrandomposneg()*(rand()%1000)*.000001,
			0,0,0,
			color,
			1);
		beamParticles[a].isAlive=true;
	}
}//function end

void ParticleSystem::update(float origin[3],float vo[3]){//function start
	//update particle origin
	for(int b=0;b<10;++b){
		if(particleTypesEnabled[b]){
			//run through system life
			systemLife[b]-=(systemLife[b]>0);
			if(systemLife[b]==0){
				particleTypesEnabled[b]=false;
			}

			//update particles if system exists
			for(int a=0;a<maxParticles[b];++a){
				if(b==PARTICLE_TYPE_FIREWORKS) fireworksParticles[a].update(origin,vo);
				else if(b==PARTICLE_TYPE_ELECTRONS) electronParticles[a].update();
				else if(b==PARTICLE_TYPE_BEAM) beamParticles[a].update();
			}
		}
	}
}//function end

void ParticleSystem::display(float origin[3],float baseAlpha){//function start
	//draw particles

	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glBindTexture(GL_TEXTURE_2D, ExternalFiles::defaultTextureIds[3]);

	particleOrigin[0]=origin[0];
	particleOrigin[1]=origin[1];
	particleOrigin[2]=origin[2];

	for(int b=0;b<10;++b){
		if(particleTypesEnabled[b]){

			for(int a=0;a<maxParticles[b];++a){
				if(b==PARTICLE_TYPE_FIREWORKS){
					fireworksParticles[a].displaySquareFireworkParticle(baseAlpha);
				}else if(b==PARTICLE_TYPE_ELECTRONS){
					glPushMatrix();
					glTranslatef(particleOrigin[0],particleOrigin[1],particleOrigin[2]);

					electronParticles[a].displaySquareElectronParticle(baseAlpha/2);
					glPopMatrix();

				}else if(b==PARTICLE_TYPE_BEAM){
					beamParticles[a].displaySquareBeamParticle(1.0f);
				}
			}
			
		}
	}

}//function end

void ParticleSystem::reset(){
	for(int a=0;a<10;++a){
		particleTypesEnabled[a]=false;
		maxParticles[a]=0;
	}
}