/*
ParticleBeam class: Class inherits particle and particleFireworks class. Contains different implementation
for display.

Last Modded: 5/15/06

*/
#include "Particle.h"

ParticleBeam::ParticleBeam(){//dummy constructor

}//contructor end

void ParticleBeam::update(){//function start
	if(isAlive){
		for(int a=0;a<3;++a){
			pos[a]+=vel[a];
			vel[a]+=acel[a];
			acel[a]=-vel[a]*airResist;
		}
		life-=decayRate;
		if(life<=0){
			life=0;
			isAlive=false;
		}
	}
}//function end


void ParticleBeam::displaySquareBeamParticle(float baseAlpha){//function start
	if(isAlive){
		float modelview[16];
		int i,j;

		glPushMatrix();
		glTranslatef(pos[0],pos[1],pos[2]);

		glGetFloatv(GL_MODELVIEW_MATRIX,modelview);

		for(i=0;i<3;i++) {
			for(j=0;j<3;j++){
				if(i==j) modelview[i*4+j]=1.0;
				else modelview[i*4+j]=0.0;
			}
		}
		glLoadMatrixf(modelview);

		
		float alpha=life/iLife;
		glColor4f(color[0],
				  color[1],
				  color[2],
				  alpha*baseAlpha);

		Display::drawParticle(size);
	
		glPopMatrix();
	}
}//function end

void ParticleBeam::displayPointBeamParticle(float baseAlpha){//function start
	if(isAlive){
		float alpha=life/iLife;
		glColor4f(color[0],
				  color[1],
				  color[2],
				  alpha*baseAlpha);
		glVertex3f(pos[0],pos[1],pos[2]);
		//no normals
	}
}//function end

