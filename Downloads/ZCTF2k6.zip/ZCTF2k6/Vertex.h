#ifndef VERTEXX

#define VERTEXX

#include <stdlib.h>

#include "ccnst.h"
#include "Display.h"
#include "Matrix.h"

#define MAXEDGESPERVERTEX 40
#define MAXTRIGTEXCOORDS MAXEDGESPERVERTEX*3

////////////////////////////////////////////////

class Vertex{//class start
	public:
	float edges[MAXEDGESPERVERTEX][4]; //track roomId, position
	short totalEdges;//total number of edges
	float posX,posY,posZ;//world position of vertex
	float normX,normY,normZ;//normals
	float texEdgeCoordTrig[MAXTRIGTEXCOORDS][4];//side1,side2, xy texCord of vertex
	short totalTexCoords;
	short id;//reference in array
	bool active;
	bool controlPt;

	/////functions

	Vertex();//constructor
	void init(float x,float y,float z,int vertexId);
	void setPos(float x,float y,float z);
	void addEdge(int ed,float edgePosX,float edgePosY,float edgePosZ);//add edge between current vertex and vec
	void addTexCoordTrig(int ed1,int ed2,float pos[2]);//add texture cordinate for linking triangle
	void removeEdge(int ed);
	void calcNorm();
	void display();
	void displayNormals();
	void reset();//reset all variables in vertex
};//class end

#endif