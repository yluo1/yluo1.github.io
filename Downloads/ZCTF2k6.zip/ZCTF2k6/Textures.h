#ifndef TEXTURESS

#define TEXTURESS

#include <stdio.h>
#include <stdlib.h>
#include <String.h>

#include "Display.h"
#include "ccnst.h"
#include "GLUT/glut.h"


class Textures{//class start
public:
	static float brightness;
	static float contrast;
	static float threshold;
	static float zoom;

	GLubyte	*imageData;		// Image Data (Up To 32 Bits)
	GLuint	bpp;			// Image Color Depth In Bits Per Pixel.
	GLuint	width;			// Image Width
	GLuint	height;			// Image Height
	GLuint	texID;			// Texture ID Used To Select A Texture
	
	GLuint padding;			//extra bytes to add at end

	GLubyte rgbArrayDef[1024][1024][3];

	Textures();
	void LoadTGA(char *filename);
	void LoadBMP(char *filename);
	void drawRGBArray(int x,int y);
//	void threshold(GLubyte src[1000][1000][3],GLubyte );
};//class end

#endif