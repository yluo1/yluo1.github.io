/*
Keyboard class: Track, process, and update keys pressed on the keyboard. Store information
in public static arrays for reference. All variables and functions are public static

Last Modded: 5/15/06
*/
#include "Keyboard.h"

bool Keyboard::normalKeyArray[256];
bool Keyboard::specialKeyArray[256];


void Keyboard::update(int key,bool val){//function start
//update key pressed/released and value
	specialKeyArray[key]=val;
}//function end

void Keyboard::update(unsigned char key,bool val){//function start

	normalKeyArray[key]=val;
	if(key>='a'&&key<='z') normalKeyArray[key+('A'-'a')]=val;
	if(key>='A'&&key<='Z') normalKeyArray[key-('A'-'a')]=val;
}//function end

void Keyboard::processDefaultKeys(){//function start

	if(Keyboard::normalKeyArray[27]==1) exit(0);//exit on esc
/*	if(Keyboard::specialKeyArray[GLUT_KEY_F2]){
		Mouse::changeMouseMovementMode((Mouse::mouseMovementMode+1)%2);
		if(Mouse::mouseMovementMode==0) Mouse::sensitivity=2.5;
		else if(Mouse::mouseMovementMode==1) Mouse::sensitivity=.1;
		Keyboard::specialKeyArray[GLUT_KEY_F2]=false;
	}*/
	if(Keyboard::specialKeyArray[GLUT_KEY_F3]){
		Display::cameraViewMode=(Display::cameraViewMode+1)%2;
		Keyboard::specialKeyArray[GLUT_KEY_F3]=false;	
	}
}//function end