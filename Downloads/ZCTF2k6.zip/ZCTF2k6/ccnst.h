/*
ccnst class: Contains global constant variables

*/
#ifndef CCNSTH
#define CCNSTH

////////////////////////////////////////////////Libraries
#include <Math.h>


////////////////////////////////////////////////Constants

//mac only
//#include <Carbon/Carbon.h>

#define GAMEMODE false

#define MAXAR 10000
//maximum framerate
#define GAMESPEED 75

//particle constants
#define MAXFIREWORKSPARTICLES 100
#define MAXELECTRONPARTICLES 15
#define MAXBEAMPARTICLES 175

//float rounding bound
#define FLOATROUND .000001

#define MAXMESSAGES 100

#define MAXSOUNDS 10

//game speed, iteratve every SPEED amount of milliseconds
#define PI 3.1415926
#define EMATH 2.71828183 

//quick approximation of pi
#define RAD PI/180.0

//Particle class constants
#define PARTICLE_TYPE_ENERGY_BALL 0
#define PARTICLE_TYPE_BEAM 1
#define PARTICLE_TYPE_FIREWORKS 2
#define PARTICLE_TYPE_ELECTRONS 3

//quick functions that math.h doesn't have
#define myabs(a) ((a>0)?(a):(-a))
//return abs

#define mymax(a,b) (((a)>(b))?(a):(b))
//return the max between a,b
#define mymaxabs(a,b) (((myabs(a))>(myabs(b)))?(a):(b))
//return max abs between a,b
#define myposzero(a) ((a>0)?(a):(0))
 //return a if pos, else 0
#define mymin(a,b) (((a)<(b))?(a):(b))
 //return min between a,b
#define myposneg(a) ((a>0)?(a>0):-(a<0))
//is the number positive or negative, 1 for pos, -1 for neg
#define myrandomposneg() (rand()%2==0?(1):(-1))

#endif