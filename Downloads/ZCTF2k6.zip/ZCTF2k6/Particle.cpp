/*
Particle class:
Generic particle class obeying euler physics

Last Modded: 5/11/06
*/
#include "Particle.h"

Particle::Particle(){//dummy constructor

}//contructor end



void Particle::init(float startLife,float startDecay,float radius,
				float x,float y,float z,
				float vox,float voy,float voz,
				float aox,float aoy,float aoz,
				float startColor[3]){//function start
	//set initials		
	life=iLife=startLife;
	decayRate=startDecay;
	isAlive=true;
	pos[0]=iPos[0]=x;
	pos[1]=iPos[1]=y;
	pos[2]=iPos[2]=z;
	vel[0]=iVel[0]=vox;
	vel[1]=iVel[1]=voy;
	vel[2]=iVel[2]=voz;
	acel[0]=iAcel[0]=aox;
	acel[1]=iAcel[1]=aoy;
	acel[2]=iAcel[2]=aoz;
	color[0]=iColor[0]=startColor[0];
	color[1]=iColor[1]=startColor[1];
	color[2]=iColor[2]=startColor[2];
	size=radius;

}//function end
				
void Particle::update(float particleOrigin[3]){//function start
//run the basic euler physics

	if(isAlive){
		for(int a=0;a<3;++a){
			pos[a]+=vel[a];
			vel[a]+=acel[a];
		}
		life-=decayRate;
		if(life<=0){
			life=0;
			isAlive=false;
		}
	}else{//reset particle
		isAlive=true;
		life=iLife;
		for(int b=0;b<3;++b){
			pos[b]=iPos[b]+particleOrigin[b];
			vel[b]=iVel[b];
			acel[b]=iAcel[b];
			color[b]=iColor[b];
		}
	}
}//function end

void Particle::displaySquareParticle(float baseAlpha){//function start
	if(isAlive){
		glColor4f(color[0],color[1],color[2],life/iLife*baseAlpha);
		glBegin(GL_TRIANGLE_STRIP);
		glVertex3f(pos[0]+size,pos[1]-size,pos[2]);
		glVertex3f(pos[0]+size,pos[1]+size,pos[2]);
		glVertex3f(pos[0]-size,pos[1]-size,pos[2]);
		glVertex3f(pos[0]-size,pos[1]+size,pos[2]);
		glEnd();
		//no normals
	}
}//function end

void Particle::displayPointParticle(float baseAlpha){//function start
	if(isAlive){
		glColor4f(color[0],color[1],color[2],life/iLife*baseAlpha);
		glVertex3f(pos[0],pos[1],pos[2]);
		//no normals
	}
}//function end

