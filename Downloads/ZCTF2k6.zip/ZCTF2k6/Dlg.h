#ifndef DLGG
#define DLGG

#include "GLUT/glut.h"
#include "ExternalFiles.h"
#include "Mouse.h"
#include "Keyboard.h"
#include "String.h"

class Dlg{//class start
public:
	int posX,posY;//dlg top left coord
	int *sizeX,*sizeY;//size of object
	int posCorners[4][2];//corner coords
	float color[4], baseColor[4];//color and default colors
	bool initialized;
	bool mouseOver;//true if mouse is over object
	int mouseButtonState;//0 if pressed, 1 if not
	
	Dlg();
	virtual void display();
	virtual void init(int x,int y,int *length,int *height,float colors[4]);
	virtual void update();

};//class end

class DlgPane:public Dlg{//class start
	public:
	int textureId;//texture ID 
	float baseAlpha;

	DlgPane();
	void display();
	void init(int x,int y,int *length,int *height,float colors[4],int texId,float minAlpha);
	void update();
};//class end

class DlgInputBox:public Dlg{//class start
	public:
	char *text;
	int len;
	int maxTextLength;
	bool hasPriority;
	int currentCharPosition;
	bool cursorFlash;


	DlgInputBox();
	void display();
	void init(int x,int y,int *length,int *height,float colors[4],int maxTextLen,char *initialText);
	void update();
	bool textToNumber(int *dest);
};//class end

class DlgTextBox:public Dlg{//class start
	public:
	char *text;//character pointer to display
	int posArrows[6][2];//arrows of coord
	int charStart;//starting character to display
	int nCharPerLine;//number of characters per line to display
	int nLines;//number of lines to display
	int len;//length of text
	
	DlgTextBox();
	void display();
	void init(int x,int y,int *length,int *height,float colors[4],char *initialText);
	void update();
};//class end

class DlgCheckBox:public Dlg{//class start
public:
	bool isChecked;
	bool lastCheckedState;

	int lastMouseButtonState;

	DlgCheckBox();
	void display();
	void init(int x,int y,int *length,int *height,float colors[4],bool initialCheckState);
	void update();
};//class end

#endif