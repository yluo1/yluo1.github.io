/*
GameCTFObject class: Interface class

*/
#include "GameCTFObject.h"

GameCTFObject::GameCTFObject(){
}


void GameCTFObject::display(){
	
}
void GameCTFObject::reset(){
	
}

void GameCTFObject::init(){
}