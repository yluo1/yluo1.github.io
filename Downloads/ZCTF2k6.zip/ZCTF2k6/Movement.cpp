/*
Movement class: 
Contains basic camera movement functions along 3 dimensions. 

All variables and functions are public static
Last Modded 5/16/06
*/
#include "Movement.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////Movement Functions/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
///////////////////Movement functions in 3d first person/////////////////////
/////////////////////////////////////////////////////////////////////////////

void Movement::CameraFirstStrafeLeft(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-Display::tWinCamX,-Display::tWinCamY,-Display::tWinCamZ,pt);
	if(Display::winXAxisAngle>90&&Display::winXAxisAngle<270) 
		Matrix::MatrixRotateYAxis(PI/2.0,pt);
	else Matrix::MatrixRotateYAxis(-PI/2.0,pt);

	float normPt=sqrt(pt[0]*pt[0]+pt[2]*pt[2]);

	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(-Display::winInc*(pt[0]/normPt),
		0,
		-Display::winInc*(pt[2]/normPt),vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end
void Movement::CameraFirstStrafeRight(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-Display::tWinCamX,-Display::tWinCamY,-Display::tWinCamZ,pt);
	if(Display::winXAxisAngle>90&&Display::winXAxisAngle<270) 
		Matrix::MatrixRotateYAxis(-PI/2.0,pt);
	else Matrix::MatrixRotateYAxis(PI/2.0,pt);

	float normPt=sqrt(pt[0]*pt[0]+pt[2]*pt[2]);
	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(-Display::winInc*(pt[0]/normPt),
		0,
		-Display::winInc*(pt[2]/normPt),vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end
void Movement::CameraFirstForewards(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-Display::tWinCamX,-Display::tWinCamY,-Display::tWinCamZ,pt);
	float normPt=sqrt(pt[0]*pt[0]+pt[1]*pt[1]+pt[2]*pt[2]);
	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(Display::winInc*(pt[0]/normPt),
		Display::winInc*(pt[1]/normPt),
		Display::winInc*(pt[2]/normPt),vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end

void Movement::CameraFirstBackwards(){//function start
	//determine direction of pointer
	float pt[4]={Display::winPCamX,Display::winPCamY,Display::winPCamZ,1};
	Matrix::MatrixTranslate(-Display::tWinCamX,-Display::tWinCamY,-Display::tWinCamZ,pt);
	float normPt=sqrt(pt[0]*pt[0]+pt[1]*pt[1]+pt[2]*pt[2]);
	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(-Display::winInc*(pt[0]/normPt),
		-Display::winInc*(pt[1]/normPt),
		-Display::winInc*(pt[2]/normPt),vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end

void Movement::CameraFirstStrafeUp(){//function start
//move up in y direction

	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(0,
		Display::winInc,
		0,vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end

void Movement::CameraFirstStrafeDown(){//function start
//move up in y direction

	float vec[4]={Display::tWinCamX,Display::tWinCamY,Display::tWinCamZ,1};
	Matrix::MatrixTranslate(0,
		-Display::winInc,
		0,vec);
	//update cords
	Display::tWinCamX=vec[0];
	Display::tWinCamY=vec[1];
	Display::tWinCamZ=vec[2];
}//function end

void Movement::CameraFirstZoomIn(){//function start
	Display::tWinZoom-=Display::winInc;
	if(Display::tWinZoom<-2) Display::tWinZoom=-2;
}//function end

void Movement::CameraFirstZoomOut(){//function start
	Display::tWinZoom+=Display::winInc;
	if(Display::tWinZoom>1) Display::tWinZoom=1;
}//function end


////////////////////////////////////////////////////////////////////////////////////
///////////////////////Update ///////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

void Movement::CameraFirstUpdate(){////function start
//update first person view camera
	if(Keyboard::specialKeyArray[GLUT_KEY_LEFT]) CameraFirstStrafeLeft();
	if(Keyboard::specialKeyArray[GLUT_KEY_UP]) CameraFirstForewards();
	if(Keyboard::specialKeyArray[GLUT_KEY_DOWN]) CameraFirstBackwards();
	if(Keyboard::specialKeyArray[GLUT_KEY_RIGHT]) CameraFirstStrafeRight();


	if(Keyboard::normalKeyArray[(int)'a']||Keyboard::normalKeyArray[(int)'A'])  CameraFirstStrafeLeft();
	if(Keyboard::normalKeyArray[(int)'w']||Keyboard::normalKeyArray[(int)'W'])  CameraFirstForewards();
	if(Keyboard::normalKeyArray[(int)'s']||Keyboard::normalKeyArray[(int)'S'])  CameraFirstBackwards();
	if(Keyboard::normalKeyArray[(int)'d']||Keyboard::normalKeyArray[(int)'D'])  CameraFirstStrafeRight();

	if(Keyboard::normalKeyArray[(int)' ']) CameraFirstStrafeUp();
	if(Keyboard::normalKeyArray[(int)'c']) CameraFirstStrafeDown();
	if(Keyboard::normalKeyArray[(int)'C']) CameraFirstStrafeDown();

	if(Keyboard::normalKeyArray[(int)'+'])  CameraFirstZoomIn();
	if(Keyboard::normalKeyArray[(int)'-'])  CameraFirstZoomOut();


}//function end