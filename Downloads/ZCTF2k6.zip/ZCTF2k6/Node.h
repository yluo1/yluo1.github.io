#ifndef NODEE

#define NODEE
#include "ccnst.h"
#include "Display.h"
#include "GLUT/glut.h"

#define MAXNODEEDGES 10

////////////////////////////////////////////////

class Node{//class start
	public:
	int edges[MAXNODEEDGES][2];//the corrensponding node ID, the edgeId

	int totalEdges;//total number of edges
	float posX,posY,posZ;//world position of node
	bool active;//node is active/inactive
	int nodeId;
	float radius;

	Node();//constructor
	void init(float x,float y,float z,int id);
	void setPos(float x,float y,float z);
	int addEdge(int targetNode);//add edge between current node and targetNode:
	void reset();//reset/clear node
	void toogleNode();
	void display();
};//class end

#endif