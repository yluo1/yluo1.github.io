/*
Node Class: 
Crates a positional node. Contains  position, reference in larger array,
and presence in node list.

Last Moded: 5/11/06
*/
#include "Node.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////Node Functions////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

Node::Node(){//function start
	nodeId=-1;
	active=false;
}//function end

void Node::init(float x,float y,float z,int id){//function start
	//init node to a location
	posX=x;
	posY=y;
	posZ=z;
	nodeId=id;
	active=true;
}//function end

void Node::setPos(float x,float y,float z){//function start
	posX=x;
	posY=y;
	posZ=z;
}//function end

int Node::addEdge(int targetNode){//function start
	//add edge between current node and target node
	//return the edgeID in current room
	int a;

	for(a=0;a<totalEdges;++a){//check for redudancies between nodes
		if(edges[a][0]==targetNode) return -1;
	}
		
	edges[totalEdges][0]=targetNode;
	++totalEdges;
	return totalEdges-1;
}//function end

void Node::display(){//function start
	//draw node
	if(active) Display::drawSphere(posX,posY,posZ,.1,10,10);
}//function end

void Node::toogleNode(){//function start
	active=!active;
}//function end
void Node::reset(){//function start
	//clear everything in node
	int a;
	posX=posY=posZ=0;
	totalEdges=0;
	for(a=0;a<MAXNODEEDGES;++a){
		edges[a][0]=edges[a][1]=-1;
	}
	active=false;
	nodeId=-1;

}//function end