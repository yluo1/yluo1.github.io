/*
PolygonT class. Class contains variables for vertex coordinates and normals along with overall polygon normal,
normal direction, polygon distance from origin, textureCoordinates, vertex colors, and if it is ccw.

Functions relate to collision detection.

Last Modded: 5/15/06
*/
#include "PolygonT.h"


PolygonT::PolygonT(){//constructor start

}//constructor end

void PolygonT::setPosition(float verticies[3][3],float relativeNormalPoint[3]){//function start
	//set vertex Coords of polygon
	int a,b;
	for(a=0;a<3;++a){
		for(b=0;b<3;++b){
			vertexCoords[a][b]=verticies[a][b];
			vertexCoords[a][b]=verticies[a][b];
			vertexCoords[a][b]=verticies[a][b];
		}
	}
	polyNormalsFixed=false;
	//calculate the normals
	calcNormals();
	polyDistance=Matrix::MatrixDotProduct(polyNormal,vertexCoords[0]);

	fixPolyNormalRelativity(relativeNormalPoint);

	//calc if normal vectors are pos/neg
	for(a=0;a<3;++a){
		if(polyNormal[a]>0) polyNormalPosnegs[a]=1;
		else if(polyNormal[a]<0) polyNormalPosnegs[a]=-1;
		else polyNormalPosnegs[a]=0;
	}

	//calculate plane distance
}//function end

void PolygonT::calcNormals(){//function start
//calculate polyNormal
	float vec1[3]={vertexCoords[2][0]-vertexCoords[0][0],vertexCoords[2][1]-vertexCoords[0][1],vertexCoords[2][2]-vertexCoords[0][2]};
	float vec2[3]={vertexCoords[1][0]-vertexCoords[0][0],vertexCoords[1][1]-vertexCoords[0][1],vertexCoords[1][2]-vertexCoords[0][2]};
	Matrix::MatrixVecCrossProduct(vec1,vec2);
	Matrix::MatrixVecNormalize(vec2);
	polyNormal[0]=vec2[0];
	polyNormal[1]=vec2[1];
	polyNormal[2]=vec2[2];

}//function end

void PolygonT::fixPolyNormalRelativity(float pt[3]){//function start
	//see if poly normal is facing towards or against pt
	float pdist=polyPointDistance(pt);
	float nextPoint[3]={pt[0]+polyNormal[0]*(1000),
						pt[1]+polyNormal[1]*(1000),
						pt[2]+polyNormal[2]*(1000)};
	
	if(polySides(pt)!=polySides(nextPoint)){
		polyNormal[0]*=-1;
		polyNormal[1]*=-1;
		polyNormal[2]*=-1;
		polyDistance=Matrix::MatrixDotProduct(polyNormal,vertexCoords[0]);
		polyNormalsFixed=true;
	}
}//function end

void PolygonT::display(){//function start
	//display polygons
	//glColor4f(polyColors[0],polyColors[1],polyColors[2],polyColors[3]);
	for(int b=0;b<3;++b){
		glColor4f(vertexColors[b][0],vertexColors[b][1],vertexColors[b][2],vertexColors[b][3]);
		glTexCoord2f(texCoords[b][0],texCoords[b][1]);
		glNormal3f(polyNormal[0],polyNormal[1],polyNormal[2]);
		glVertex3f(vertexCoords[b][0],vertexCoords[b][1],vertexCoords[b][2]);
	}
}//function end

void PolygonT::displayNormals(){//function start
	glBegin(GL_LINES);
	glColor4f(polyColors[0],polyColors[1],polyColors[2],polyColors[3]);
	glVertex3f((vertexCoords[0][0]+vertexCoords[1][0]+vertexCoords[2][0])/3.0f,
			   (vertexCoords[0][1]+vertexCoords[1][1]+vertexCoords[2][2])/3.0f,
			   (vertexCoords[0][2]+vertexCoords[1][2]+vertexCoords[2][1])/3.0f);
	glVertex3f((vertexCoords[0][0]+vertexCoords[1][0]+vertexCoords[2][0])/3.0f+polyNormal[0]/10.0f,
			   (vertexCoords[0][1]+vertexCoords[1][1]+vertexCoords[2][2])/3.0f+polyNormal[1]/10.0f,
			   (vertexCoords[0][2]+vertexCoords[1][2]+vertexCoords[2][1])/3.0f+polyNormal[2]/10.0f);
	
	glEnd();
}//function end

int PolygonT::polySides(float currentPoint[3]){//function start
	//check what side of the plane is a point on
	float a=Matrix::MatrixDotProduct(polyNormal,currentPoint)-polyDistance;
	if (a>=-FLOATROUND&&a<=FLOATROUND) return 2;//on the plane
	else if(a>0) return 0;
	else if(a<0) return 1;

	return 3;
}//function end

bool PolygonT::polyCollide(float currentPoint[3],float nextPoint[3]){//function start
	//collision detection between points and planes
	if(polySides(currentPoint)!=polySides(nextPoint)){
		//current to destination positions have intersected a plane
		float ray[3]={nextPoint[0]-currentPoint[0],nextPoint[1]-currentPoint[1],nextPoint[2]-currentPoint[2]};
		float t=-(Matrix::MatrixDotProduct(polyNormal,currentPoint)-polyDistance)/Matrix::MatrixDotProduct(polyNormal,ray);
		float intersect[3]={currentPoint[0]+ray[0]*t,currentPoint[1]+ray[1]*t,currentPoint[2]+ray[2]*t};

		//given the intersect, check if it lies within the polygon
		return polyIn(intersect);
	}
	return false;//has not collided
}//function end

bool PolygonT::polyCollide(float currentPoint[3],float nextPoint[3],float intersect[3]){//function start
	//collision detection between points and planes: put intersection point in intersect
	if(polySides(currentPoint)!=polySides(nextPoint)){
		//current to destination positions have intersected a plane
		float ray[3]={nextPoint[0]-currentPoint[0],nextPoint[1]-currentPoint[1],nextPoint[2]-currentPoint[2]};
		float t=-(Matrix::MatrixDotProduct(polyNormal,currentPoint)-polyDistance)/Matrix::MatrixDotProduct(polyNormal,ray);
		intersect[0]=currentPoint[0]+ray[0]*t;
		intersect[1]=currentPoint[1]+ray[1]*t;
		intersect[2]=currentPoint[2]+ray[2]*t;

		//given the intersect, check if it lies within the polygon
		return polyIn(intersect);
	}
	return false;//has not collided
}//function end


bool PolygonT::polyIn(float point[3]){//function start
	//check if point lies within polygon
	for(int a=0;a<3;++a){
		float vec1[3]={point[0]-vertexCoords[a][0],point[1]-vertexCoords[a][1],point[2]-vertexCoords[a][2]};
		float vec2[3]={vertexCoords[(a+1)%3][0]-vertexCoords[a][0],vertexCoords[(a+1)%3][1]-vertexCoords[a][1],vertexCoords[(a+1)%3][2]-vertexCoords[a][2]};
		//note that the calculated normal correlates to vec1 and vec2 order

		Matrix::MatrixVecCrossProduct(vec1,vec2);
		int b;
		if(!polyNormalsFixed){
			for(b=0;b<3;++b){
				if(polyNormalPosnegs[b]==1&&vec2[b]<-FLOATROUND) break;
				else if(polyNormalPosnegs[b]==-1&&vec2[b]>FLOATROUND) break;
				else if(polyNormalPosnegs[b]==0&&(vec2[b]>FLOATROUND||vec2[b]<-FLOATROUND)) break;
			}
		}else{
			for(b=0;b<3;++b){
				if(polyNormalPosnegs[b]==-1&&vec2[b]<-FLOATROUND) break;
				else if(polyNormalPosnegs[b]==1&&vec2[b]>FLOATROUND) break;
				else if(polyNormalPosnegs[b]==0&&(vec2[b]>FLOATROUND||vec2[b]<-FLOATROUND)) break;
			}
		}
		if(b<3) return false;//has not collided
	}
	
	return true;//has collided
}//function end

float PolygonT::polyPointDistance(float currentPoint[3]){//function start
	float w[3]={vertexCoords[0][0]-currentPoint[0],vertexCoords[0][1]-currentPoint[1],vertexCoords[0][2]-currentPoint[2]};
	return Matrix::MatrixDotProduct(polyNormal,w)/Matrix::MatrixMagnitude(polyNormal);
}//function end