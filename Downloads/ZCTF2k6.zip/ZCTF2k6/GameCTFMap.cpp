/*
GameCTFMap class: Creates a Map object as a blueprint for Room objects. Room objects
contain verticies, quads, and shapes for display.

Last Modded: 5/15/06
*/
#include "GameCTFMap.h"

GameCTFMap::GameCTFMap(){//constructor start
	gameMapTotalRooms=0;
}//constructor end

void GameCTFMap::GameCTFMapGenerate(int totalRow,int totalCols,int totalDepths,int complexity,
		float maxPhysicalSizeR,float maxPhysicalSizeC,float maxPhysicalSizeD,
		int triangleSplice,int mazeMethod,
		float wallRadius,float wallDistortion,float vertexDistortion,
		int maxDisplayDepth){//function start
	//create the CTF maze map
	int a;
	/////////////clear map and maplists
	reset();
	displayDepth=maxDisplayDepth;

	////////////make the map
	gameMap.mapMaze(totalRow,totalCols,totalDepths,complexity,mazeMethod,maxPhysicalSizeC,maxPhysicalSizeR,maxPhysicalSizeD,wallRadius,wallDistortion);
	printf("mapMaze done, totalNodes=%d\n",gameMap.mapMaxNodes);

	gameMap.mapMaze6WayNodeToVertices();
	printf("mapMaze6WayNodeToVertices done, total vertices=%d\n",gameMap.totalVertices);

	for(a=0;a<triangleSplice;++a){//splice existing traigles to create effects
		gameMap.mapMazeSpliceVertices();
		printf("mapMazeSpliceVertices done, total vertices=%d\n",gameMap.totalVertices);
	}
	GameCTFDistortVertices(wallRadius,vertexDistortion);

	GameCTFRoomsGenerate();
	printf("GameCTFRoomsGenerate done\n");
	

	gameMap.deleteVertices();
	hasMapGenerated=true;
}//function end

void GameCTFMap::GameCTFMakeDisplayLists(int nTeams,int teamIds[],float teamColors[][3],bool memSaveOn){//function start
//create/store displaylists 
	int a,b;

	////////////////////////////make bigmap displaylist
	gameMapDisplayListBigMap=glGenLists(1);
	glNewList(gameMapDisplayListBigMap,GL_COMPILE);
//	GameCTFDisplayWireFrame();
	GameCTFDisplayTriangles();
	glEndList();
	printf("map bigmap displaylist done\n");

	if(memSaveOn){
		////////////////////////////make partialmap displaylist
		gameMapDisplayListPartialMap=glGenLists(gameMapTotalRooms);
		printf("partial polys\n");
		for(a=0;a<gameMapTotalRooms;++a){
			glNewList(gameMapDisplayListPartialMap+a,GL_COMPILE);
			if(gameMap.mapNodes[a].active){
				b=GameCTFDisplayPartial(a);
				printf("%d ",b);
			}
			glEndList();
		}
		printf("\n");
		printf("map partialmap displaylist done\n");
	}

	///////////////////////////draw minimap
	gameMapDisplayListMinimap=glGenLists(1);
	glNewList(gameMapDisplayListMinimap,GL_COMPILE);
	GameCTFDisplayMinimap(0,nTeams,teamIds,teamColors,-1,-1);
	glEndList();
	printf("map minimap displaylist done\n");

}//function end

void GameCTFMap::GameCTFDisplayMinimap(int depth,int nTeams,int teamIds[], float teamColors[][3],int currentTeam,int currentNode){//function start
//create linestrip based minimap
	int a,b;
	if(depth==0){//initial call
		GameCTFDisplayMinimapTracker=new bool[gameMap.mapMaxNodes];
		for(a=0;a<gameMap.mapMaxNodes;++a) GameCTFDisplayMinimapTracker[a]=false;
		glLineWidth(2);
		for(a=0;a<nTeams;++a){
			for(b=0;b<gameMap.mapMaxNodes;++b){
				if(!GameCTFDisplayMinimapTracker[b]&&gameRooms[b].teamId==teamIds[a]&&gameRooms[b].active){
					glColor4f(teamColors[a][0]/2,teamColors[a][1]/2,teamColors[a][2]/2,.2f);
					glBegin(GL_LINE_STRIP);
					glVertex3f(gameMap.mapNodes[b].posX,gameMap.mapNodes[b].posY,gameMap.mapNodes[b].posZ);
					GameCTFDisplayMinimap(depth+1,nTeams,teamIds,teamColors,teamIds[a],b);
					glEnd();
					break;
				}
			}
		}
		glLineWidth(1);
		delete [] GameCTFDisplayMinimapTracker;
	}else{//recursion
		bool firstRun=true;
		GameCTFDisplayMinimapTracker[currentNode]=true;
	
		for(a=0;a<gameMap.mapNodes[currentNode].totalEdges;++a){
			b=gameMap.mapNodes[currentNode].edges[a][0];
			if(firstRun==false){
				glEnd();
				glBegin(GL_LINE_STRIP);
				glVertex3f(gameMap.mapNodes[currentNode].posX,gameMap.mapNodes[currentNode].posY,gameMap.mapNodes[currentNode].posZ);
			}
			glVertex3f(gameMap.mapNodes[b].posX,gameMap.mapNodes[b].posY,gameMap.mapNodes[b].posZ);
			firstRun=false;
			if(!GameCTFDisplayMinimapTracker[b]){
				if(gameRooms[b].teamId==currentTeam){
					GameCTFDisplayMinimap(depth+1,nTeams,teamIds,teamColors,currentTeam,b);	
				}
			}
		}
	}
}//function end

void GameCTFMap::GameCTFDistortVertices(float radius,float percent){//function start
//distort verticies by a percent of 1 unit
	int a,b;
	float c;
	if(percent==0) return;
	for(a=0;a<gameMap.totalVertices;++a){
		b=rand()%2;
		if(b==0) c=(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		else c=-(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		gameMap.mapVertices[a].posX+=c;
	
		b=rand()%2;
		if(b==0)c=(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		else c=-(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		gameMap.mapVertices[a].posY+=c;
		
		b=rand()%2;
		if(b==0) c=(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		else c=-(rand()%((int)(radius*percent*10000)))/(radius*10000.0);
		gameMap.mapVertices[a].posZ+=c;
			
	}
}//function end

void GameCTFMap::GameCTFRoomsGenerate(){//function start
	//make rooms, assign triangles to rooms
	int a,b,c,d,e,f;

	for(a=0;a<gameMap.totalVertices;++a){//look through all vertices
		if(gameMap.mapVertices[a].active){//vertex does exist
			int currentRoom=gameMap.vertexGroups[a];
			if(currentRoom>=gameMapTotalRooms) gameMapTotalRooms=currentRoom+1;
			//find 2 vertices that link to form triangle
			for(b=0;b<gameMap.mapVertices[a].totalEdges;++b){
				d=(int)gameMap.mapVertices[a].edges[b][0];//test vertex1
				for(c=b+1;c<gameMap.mapVertices[a].totalEdges;++c){
					e=(int)gameMap.mapVertices[a].edges[c][0];//test vertex2
					if(d>a&&e>a){//unvisited vertices
						if(gameMap.mapVertices[a].controlPt||gameMap.mapVertices[d].controlPt||gameMap.mapVertices[e].controlPt){
							for(f=0;f<gameMap.mapVertices[e].totalEdges;++f){
								if(gameMap.mapVertices[e].edges[f][0]==d){//vertex1 vertex2 connect
									float pt[3]={gameMap.mapNodes[currentRoom].posX,gameMap.mapNodes[currentRoom].posY,gameMap.mapNodes[currentRoom].posZ};
									gameRooms[currentRoom].addPoly(gameMap.mapVertices[a],gameMap.mapVertices[d],gameMap.mapVertices[e],pt);
									++totalPolygons;
								}
							}
						}
					}
				}
			}
		}
	}
	printf("GameCTFRoomsGenerate done, polycount=%d\n",totalPolygons);

}//function end

void GameCTFMap::GameCTFMapAssignBoundaries(int nTeams,int teamIds[], float teamColors[][3]){//function start
	//make rooms with teamIds and team colors
	int a,b,c,d,e,f;
	bool *trker1=new bool[gameMap.mapMaxNodes];//track node visited status
	int *trker2=new int[gameMap.mapMaxNodes];//track next positions
	int *trker3=new int[gameMap.mapMaxNodes];//track depth
	int *trker4=new int[gameMap.mapMaxNodes];//track teamids
	int cTrk=0;
	int starterSeed=0;
	short seedArray[10];
	short lastNodeAdded;

	//seed first pt
	for(a=0;a<gameMap.mapMaxNodes;++a) if(gameMap.mapNodes[a].active) break;
	if(a!=gameMap.mapMaxNodes)
		seedArray[starterSeed]=a;
	else{
		printf("GameCTFMap GameCTFMapAssignBoundaries too few active nodes due to prune");
		getchar();
		exit(0);
	}
	++starterSeed;

	for(f=0;f<=nTeams;++f){
		//clear initials
		for(a=0;a<gameMap.mapMaxNodes;++a){
			trker1[a]=false;
			trker2[a]=trker3[a]=trker4[a]=0;
		}
		cTrk=0;
		for(e=0;e<starterSeed;++e){//seed flag points
			trker2[cTrk]=seedArray[e];
			trker1[seedArray[e]]=true;
			trker3[cTrk]=0;
			trker4[cTrk]=teamIds[e];
			++cTrk;
		}
		//assign color and ids
		for(a=0;a<cTrk;++a){
			b=trker2[a];

			if(f==nTeams){//set teamids for rooms
				gameRooms[b].teamId=trker4[a];
			}
			for(c=0;c<gameMap.mapNodes[b].totalEdges;++c){
				d=gameMap.mapNodes[b].edges[c][0];
				if(!trker1[d]){
					trker1[d]=true;
					trker2[cTrk]=d;
					trker3[cTrk]=trker3[a]+1;
					trker4[cTrk]=trker4[a];
					++cTrk;
					lastNodeAdded=d;
				}
			}
		}
		if(f<nTeams-1){
			seedArray[starterSeed]=lastNodeAdded;
			++starterSeed;
		}
	}

	//set seeded rooms as flag rooms
	for(a=0;a<starterSeed;++a) flagRooms[a]=seedArray[a];

	//assign colors for rooms
	for(a=0;a<gameMap.mapMaxNodes;++a){
		if(gameMap.mapNodes[a].active){//node is active
			for(b=0;b<gameRooms[a].polyCount;++b){//run through all triangles
				float trigVertexColors[3][3];
				for(c=0;c<3;++c){//run through every vertex of triangle
					//determine which node is vertex closer to
					float minDist=Matrix::MatrixNonsqrtDist(gameRooms[a].poly[b].vertexCoords[c][0],
															gameRooms[a].poly[b].vertexCoords[c][1],
															gameRooms[a].poly[b].vertexCoords[c][2],
															gameMap.mapNodes[a].posX,
															gameMap.mapNodes[a].posY,
															gameMap.mapNodes[a].posZ);//track distance
					f=a;//track closest node
					float ff;
					for(d=0;d<gameMap.mapNodes[a].totalEdges;++d){//run
						e=gameMap.mapNodes[a].edges[d][0];
						ff=Matrix::MatrixNonsqrtDist(gameRooms[a].poly[b].vertexCoords[c][0],
													 gameRooms[a].poly[b].vertexCoords[c][1],
													 gameRooms[a].poly[b].vertexCoords[c][2],
													 gameMap.mapNodes[e].posX,
													 gameMap.mapNodes[e].posY,
												 	 gameMap.mapNodes[e].posZ);
						if(ff<minDist){
							minDist=ff;
							f=e;
						}
					}
					trigVertexColors[c][0]=teamColors[gameRooms[f].teamId][0];
					trigVertexColors[c][1]=teamColors[gameRooms[f].teamId][1];
					trigVertexColors[c][2]=teamColors[gameRooms[f].teamId][2];
				}
				//average vertex colors
				float avgColor[3]={0,0,0};
				for(c=0;c<3;++c) {
					avgColor[0]+=trigVertexColors[c][0];
					avgColor[1]+=trigVertexColors[c][1];
					avgColor[2]+=trigVertexColors[c][2];
				}
				avgColor[0]/=3.0f;
				avgColor[1]/=3.0f;
				avgColor[2]/=3.0f;
				//set poly color
				gameRooms[a].poly[b].polyColors[0]+=(avgColor[0]-gameRooms[a].poly[b].polyColors[0])*.55;
				gameRooms[a].poly[b].polyColors[1]+=(avgColor[1]-gameRooms[a].poly[b].polyColors[1])*.55;
				gameRooms[a].poly[b].polyColors[2]+=(avgColor[2]-gameRooms[a].poly[b].polyColors[2])*.55;
				for(int i=0;i<3;++i){//ser vertex colors
					for(int j=0;j<3;++j){
						gameRooms[a].poly[b].vertexColors[i][j]=gameRooms[a].poly[b].polyColors[j];
					}
				}
			}
		}
	}

	printf("GameCTFMapAssignBoundaries: cTrk=%d\n",cTrk);
	delete [] trker1;
	delete [] trker2;
	delete [] trker3;
	delete [] trker4;
}//function end

void GameCTFMap::GameCTFMapFinalColorPass(){//function start
	//final adjustment to colors for smoother blend
	//search for shared verticies in current and adjacent rooms and average colors
	int a,b,c,d,e,f,h;

	bool ***trash;
	trash=new bool **[gameMapTotalRooms];
	for(a=0;a<gameMapTotalRooms;++a){
		trash[a]=new bool *[gameRooms[a].polyCount];
		for(b=0;b<gameRooms[a].polyCount;++b){
			trash[a][b]=new bool[3];
			for(c=0;c<3;++c) trash[a][b][c]=false;
		}

	}

	for(a=0;a<gameMapTotalRooms;++a){
		if(gameRooms[a].active){
			for(b=0;b<gameRooms[a].polyCount;++b){
							
				for(c=0;c<3;++c){//run through the 3 vertices in poly
					if(!trash[a][b][c]){
		
						//set current point
						float ptPos[3]={gameRooms[a].poly[b].vertexCoords[c][0],
										gameRooms[a].poly[b].vertexCoords[c][1],
										gameRooms[a].poly[b].vertexCoords[c][2]};
						float ptColor[4]={	gameRooms[a].poly[b].vertexColors[c][0],
											gameRooms[a].poly[b].vertexColors[c][1],
											gameRooms[a].poly[b].vertexColors[c][2],
											gameRooms[a].poly[b].vertexColors[c][3]};
		
						int similarPoints=0;
						//set and seed pt list
						int ptList[100][3];//room/poly/vertex
						ptList[similarPoints][0]=a;
						ptList[similarPoints][1]=b;
						ptList[similarPoints][2]=c;
						trash[a][b][c]=true;
						++similarPoints;
		
						//search all rooms again for similar rooms
						for(h=0;h<gameMapTotalRooms;++h){
							if(gameRooms[h].active){
								for(d=0;d<gameRooms[h].polyCount;++d){
									for(e=0;e<3;++e){//run through the 3 vertices in poly
										if(!trash[h][d][e]){
											if(Matrix::MatrixCompare(ptPos,gameRooms[h].poly[d].vertexCoords[e],3)){
												//vertex matches
												ptList[similarPoints][0]=h;
												ptList[similarPoints][1]=d;
												ptList[similarPoints][2]=e;
												trash[h][d][e]=true;
												for(f=0;f<4;++f) ptColor[f]+=gameRooms[h].poly[d].vertexColors[e][f];
												++similarPoints;
											}
										}
									}
								}
							}
						}
						
						//update 
						//average colors
						for(d=0;d<4;++d) ptColor[d]/=(float)similarPoints;
						for(d=0;d<similarPoints;++d){//set pts
							for(e=0;e<4;++e){
								gameRooms[ptList[d][0]].poly[ptList[d][1]].vertexColors[ptList[d][2]][e]=ptColor[e];
							}
						}

					}
				}
			}
		}
	}


	for(a=0;a<gameMapTotalRooms;++a){
		for(b=0;b<gameRooms[a].polyCount;++b){
			delete [] trash[a][b];
		}
		delete [] trash[a];

	}	
	delete [] trash;

	

}//function end

void GameCTFMap::GameCTFDisplayWireFrame(){//function start
//display wireframe mode
	if(Display::wireFrameOnOff) gameMap.displayVertices();//draw wireframe
}//function end

void GameCTFMap::GameCTFDisplayNodes(){//function start
//display nodes
	for(int a=0;a<gameMap.mapMaxNodes;++a) gameMap.mapNodes[a].display();//draw nodes
}//function end


void GameCTFMap::GameCTFDisplayTriangles(){//function start
	glBegin(GL_TRIANGLES);
	for(int a=0;a<gameMapTotalRooms;++a){
		if(gameRooms[a].active)
			gameRooms[a].displayPolys();
	}
	glEnd();

}//function end

void GameCTFMap::GameCTFDisplayTrianglesNormals(){//function start
	for(int a=0;a<gameMapTotalRooms;++a){
		if(gameRooms[a].active) gameRooms[a].displayNormals();
	}
}//function end


int GameCTFMap::GameCTFDisplayPartial(int currentNode){//function start
	//draw room and adjacent rooms until displayDepth is reached, return number of polys drawn
	int polyCount=0;
	if(hasMapGenerated){
		int a,b,c,d;
		bool GameCTFDisplayTracker[MAXROOMS];
		short tempTrk[MAXROOMS];
		short tempTrk2[MAXROOMS];
		short currentTrk=0;
		glBegin(GL_TRIANGLES);
		//reset tracker
		for(a=0;a<gameMapTotalRooms;++a) GameCTFDisplayTracker[a]=false;
		
		//seed current node
		tempTrk[currentTrk]=currentNode;//store node id
		tempTrk2[currentTrk]=0;//store depth
		GameCTFDisplayTracker[currentTrk]=true;
		++currentTrk;

		for(a=0;a<currentTrk;++a){//loop through queue
			b=tempTrk[a];
			gameRooms[b].displayPolys();
			polyCount+=gameRooms[b].polyCount;
			if(tempTrk2[a]<displayDepth){
				for(c=0;c<gameMap.mapNodes[b].totalEdges;++c){
					d=gameMap.mapNodes[b].edges[c][0];
					if(!GameCTFDisplayTracker[d]){//unvisited node
						tempTrk[currentTrk]=d;
						tempTrk2[currentTrk]=tempTrk2[a]+1;
						GameCTFDisplayTracker[d]=true;
						++currentTrk;
					}
				}
			}
		}
		glEnd();
	//	glDisable(GL_TEXTURE_2D);
		//for(a=1;a<gameMapTotalRooms;++a) gameRooms[a].displayNormals();
	}
	return polyCount;
}//function end


int GameCTFMap::nearestNode(float x,float y,float z){//function start
	//find closest node to camera and return nodeid
	int a,b=-1;
	float f,minF=100000.0f;

	for(a=0;a<gameMapTotalRooms;++a){
		//compare node position to current player position
		if(gameMap.mapNodes[a].active){
			float dist[3]={x-gameMap.mapNodes[a].posX,y-gameMap.mapNodes[a].posY,z-gameMap.mapNodes[a].posZ};
			f=dist[0]*dist[0]+dist[1]*dist[1]+dist[2]*dist[2];
			if(f<minF){
				minF=f;
				b=a;
			}
		}
	}
	return b;
}//function end

int GameCTFMap::nearestAdjacentNode(float x,float y,float z, int currentNode){//function start
	//find closest adjacent node to camera from currentNode inclusive and return nodeid
	int a,b=currentNode;
	float f,minF;

	float homeDist[3]={x-gameMap.mapNodes[currentNode].posX,
						y-gameMap.mapNodes[currentNode].posY,
						z-gameMap.mapNodes[currentNode].posZ};

	minF=homeDist[0]*homeDist[0]+homeDist[1]*homeDist[1]+homeDist[2]*homeDist[2];

	for(a=0;a<gameMap.mapNodes[currentNode].totalEdges;++a){
		int c=gameMap.mapNodes[currentNode].edges[a][0];
		//compare node position to current player position
		if(gameMap.mapNodes[c].active){
			float dist[3]={x-gameMap.mapNodes[c].posX,
						   y-gameMap.mapNodes[c].posY,
						   z-gameMap.mapNodes[c].posZ};
			f=dist[0]*dist[0]+dist[1]*dist[1]+dist[2]*dist[2];
			if(f<minF){
				minF=f;
				b=c;
			}
		}
	}
	return b;
	
}//function end

void GameCTFMap::reset(){//function start
	//clear everything
	int a;

	for(a=0;a<MAXROOMS;++a) gameRooms[a].reset();
	glDeleteLists(gameMapDisplayListBigMap,1);
	glDeleteLists(gameMapDisplayListPartialMap,gameMapTotalRooms);
	glDeleteLists(gameMapDisplayListMinimap,1);
	gameMapTotalRooms=0;
	gameMap.reset();
	totalPolygons=0;
	hasMapGenerated=false;

}//function end
