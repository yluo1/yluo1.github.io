#ifndef SOUNDD
#define SOUNDD

#include <stdlib.h>
#include <stdio.h>


#include "al.h"
#include "alut.h"
#include "ccnst.h"

class Sound{//class start
public:
	//source and buffer data
	ALuint buffer;
	ALuint source;

	// position and velocity of sounds
	ALfloat sourcePos[3];
	ALfloat sourceVel[3];

	/////functions
	Sound();

	static void init();

	void load(char *name);//load the data
	void setListenerValues();//set listener values
	void remove();//remove data from ram
	void play(bool loop);
	void stop();


};//class end

#endif