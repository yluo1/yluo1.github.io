#ifndef KEYBOARDD
#define KEYBOARDD

#include <stdio.h>
#include <stdlib.h>
#include "ccnst.h"
#include "Display.h"
#include "GLUT/glut.h"
////////////////////////////////////////////////

class Keyboard{//start of Keyboard class
	public:
	static bool normalKeyArray[256];//ascii key values 0=not pressed, 1=pressed
	static bool specialKeyArray[256];//0=not pressed, 1=pressed

	/*
		0,1,2,3 = left up down right
	
	*/
	static void update(int key,bool val);
	static void update(unsigned char key,bool val);
	static void processDefaultKeys();
};//end of Keyboard class

#endif