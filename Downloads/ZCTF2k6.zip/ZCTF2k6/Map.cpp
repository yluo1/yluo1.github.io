/*
Map class: 
Represent an enviornment with nodes and edges. Contains functions for construting
random mazes. Vertex data supplied for higher level models.

Last Updated: 5/11/06
*/
#include "Map.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////Map Variables//////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//default 6 directions in a cube map
int Map::dirs[6][3]={{0,1,0},
					{0,0,1},
					{1,0,0},
					{-1,0,0},
					{0,0,-1},
					{0,-1,0}};//reference directions
//default 8 directions in a cube map
int Map::cubeDirs[8][3]={{-1,1,-1},
						{-1,-1,-1},
						{1,-1,-1},
						{1,1,-1},
						{-1,1,1},
						{-1,-1,1},
						{1,-1,1},
						{1,1,1}};//reference directions

//defulat texture corner coords
float Map::texCorners[4][2]={{0,0},{1,0},{1,1},{0,1}};					
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////Map Functions//////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Map::Map(){//start of constructor
	mapComplexity=0;
	mapMaxNodes=0;
	totalVertices=0;
	mapDimX=0;
	mapDimY=0;
	mapDimZ=0;
}//end of constructor

void Map::mapMaze(int mDimX,int mDimY,int mDimZ,
				  int complexity,int ways,
				  float maxPhysicalSizeR,float maxPhysicalSizeC,float maxPhysicalSizeD,
				  float wallRad,float wallDistortion){//function start
	//make a maze

	
	srand(time(NULL));   
	//init maze attributes
	mapDimX=mDimX+2;
	mapDimY=mDimY+2;
	mapDimZ=mDimZ+2;
	mapMaxNodes=0;
	mapComplexity=complexity;
	mapSizeR=maxPhysicalSizeR;
	mapSizeC=maxPhysicalSizeC;
	mapSizeD=maxPhysicalSizeD;
	mapWallRadius=wallRad;
	mapWallDistortion=wallDistortion;

	for(int a=0;a<mapDimY;++a){
		for(int b=0;b<mapDimX;++b){
			for(int c=0;c<mapDimZ;++c){
				for(int d=0;d<7;++d) mapMaze6WayMap[a][b][c][d]=-1;
			}
		}
	}

	//select type of map to generate
	if(ways==6) mapMaze6Way();
	else mapMaze6Way();
}//end of makeMap function

void Map::mapMaze6Way(){//function start
	//outlining map making function
	mapMaxNodes=1;
	mapMaze6WayRecur(1,1,1);//make 6 way maze
	printf("mapMaze6WayRecur done\n");

	//force links into maze
	for(int a=0;a<mapComplexity;++a) mapMaze6WayForceEdges(abs(rand()%(mapDimX-2))+1,abs(rand()%(mapDimY-2))+1,abs(rand()%(mapDimZ-2))+1);
	printf("mapMaze6WayForceEdges done\n");

	mapMazeToNode();//convert into nodes
	printf("mapMazeToNode done\n");

	if(!((mapDimX==3&&mapDimY==3)||(mapDimX==3&&mapDimZ==3)||(mapDimY==3&&mapDimZ==3)))
		mapMazeNodePrune(1);

	printf("mapMazeNodePrune done, nodeCount=%d\n",mapMaxNodes);

//	mapNodeCompress();
//	printf("mapNodeCompress done,nodeCount=%d\n",mapMaxNodes);
}//function end

void Map::mapMazeNodePrune(int threshold){//function start
	//remove dead end nodes
	int a,b,c,d,e,f,g=0;

	do{
		e=0;
		for(a=0;a<mapMaxNodes;++a){
			if(mapNodes[a].totalEdges<=threshold&&mapNodes[a].totalEdges>0){
				//bad node found
				e=1;
				mapNodes[a].active=false;//inactivate node
				++g;
				for(d=0;d<mapNodes[a].totalEdges;++d){//subtract 1 from all connecting nodes
					b=mapNodes[a].edges[d][0];//b points to all connecting nodes of bad node
					for(c=0;c<mapNodes[b].totalEdges;++c){
						if(mapNodes[b].edges[c][0]==a) break;//break pt found
					}
					for(c=c+1;c<mapNodes[b].totalEdges;++c){//slide edges list back one
						for(f=0;f<2;++f) mapNodes[b].edges[c-1][f]=mapNodes[b].edges[c][f];
					}
					--mapNodes[b].totalEdges;
					if(mapNodes[b].totalEdges==0) mapNodes[b].reset();
				}
				mapNodes[a].reset();
			}
		}
	}while(e==1);
	printf("mapMazeNodePrune removed %d nodes\n",g);

}//function end

void Map::mapNodeCompress(){//function start
	int a,b,c;
	for(a=1;a<mapMaxNodes;++a){
		if(!mapNodes[a].active){
			for(b=a+1;b<mapMaxNodes;++b){
				if(mapNodes[b].active){//match found
					mapNodes[a].init(mapNodes[b].posX,mapNodes[b].posY,mapNodes[b].posZ,a);
					mapNodes[a].totalEdges=mapNodes[b].totalEdges;
					for(c=0;c<mapNodes[b].totalEdges;++c){
						mapNodes[a].edges[c][0]=mapNodes[b].edges[c][0];
						mapNodes[a].edges[c][1]=mapNodes[b].edges[c][1];
						mapNodes[mapNodes[b].edges[c][0]].edges[mapNodes[b].edges[c][1]][0]=a;
					}
					mapNodes[b].reset();
					int d,e,f,g;
					for(d=0;d<mapDimX;++d){
						for(e=0;e<mapDimY;++e){
							for(f=0;f<mapDimZ;++f){
								for(g=0;g<7;++g){
									if(mapMaze6WayMap[e][d][f][g]==a) mapMaze6WayMap[e][d][f][g]=-1;
								}
							}
						}
					}
					for(d=0;d<mapDimX;++d){
						for(e=0;e<mapDimY;++e){
							for(f=0;f<mapDimZ;++f){
								for(g=0;g<7;++g){
									if(mapMaze6WayMap[e][d][f][g]==b) mapMaze6WayMap[e][d][f][g]=a;
								}
							}
						}
					}
					break;
				}
			}
			if(b==mapMaxNodes){
				mapMaxNodes=a;
				break;
			}
		}
	}
}//function end

void Map::mapMaze6WayForceEdges(int x,int y,int z){//function start
	int a,b,c,d;
	
	a=abs(rand()%6);
	b=dirs[a][0];//x shift
	c=dirs[a][1];//y shift
	d=dirs[a][2];//z shift
	if(!(x+b<=0||y+c<=0||z+d<=0||x+b>=mapDimX-1||y+c>=mapDimY-1||z+d>=mapDimZ-1)){
		//check if position is within bounds
		if(mapMaze6WayMap[y][x][z][a+1]==-1){//check if position link does not exist
			mapMaze6WayMap[y][x][z][a+1]=mapMaze6WayMap[y+c][x+b][z+d][0];
			mapMaze6WayMap[y+c][x+b][z+d][6-a]=mapMaze6WayMap[y][x][z][0];
		}
	}	
}//function end


void Map::mapMaze6WayRecur(int x,int y,int z){//function start
	//create 6way gridbased maze
	int a,b,c,d,e;
	if(mapMaze6WayMap[y][x][z][0]==-1){//check if position was visited
		//give position an ID
		mapMaze6WayMap[y][x][z][0]=mapMaxNodes;
		++mapMaxNodes;
	}

	for(d=0;d<128;++d){
		a=abs(rand()%6);
		b=dirs[a][0];//x shift
		c=dirs[a][1];//y shift
		e=dirs[a][2];//z shift
		if(!(x+b<=0||y+c<=0||z+e<=0||x+b>=mapDimX-1||y+c>=mapDimY-1||z+e>=mapDimZ-1)){
			//check if next position is within bounds
			if(mapMaze6WayMap[y+c][x+b][z+e][0]==-1){//check if position was visited
				//make links between positions
				mapMaze6WayMap[y][x][z][a+1]=mapMaxNodes;
				mapMaze6WayMap[y+c][x+b][z+e][0]=mapMaxNodes;
				++mapMaxNodes;
				mapMaze6WayMap[y+c][x+b][z+e][6-a]=mapMaze6WayMap[y][x][z][0];

				mapMaze6WayRecur(x+b,y+c,z+e);//call again at new position
			}
		}
	}
}//function end

void Map::mapMaze6WayNodeToVertices(){//function start
	//convert mapmaze with node placements into vertices
	bool* nodeTracker;
	nodeTracker=new bool[MAXAR];
	int a,b,c,d,e,f;
	float rad=mapWallRadius;
	for(a=0;a<MAXAR;++a) nodeTracker[a]=false;

	for(a=1;a<mapDimX-1;++a){
		for(b=1;b<mapDimY-1;++b){
			for(c=1;c<mapDimZ-1;++c){
				d=mapMaze6WayMap[b][a][c][0];
				if(d!=-1){
					if(nodeTracker[d]==false){
						if(mapNodes[d].active==true){
							//valid node found
							nodeTracker[d]=true;
							//make vertices
							rad=mapWallRadius+myrandomposneg()*((rand()%1000)/1000.0f)*mapWallDistortion*mapWallRadius;
							for(e=0;e<8;++e){
								mapVertices[d*8+e].init(mapNodes[d].posX+cubeDirs[e][0]*rad,
														mapNodes[d].posY+cubeDirs[e][1]*rad,
														mapNodes[d].posZ+cubeDirs[e][2]*rad,
														d*8+e);
								vertexGroups[d*8+e]=d;
								mapNodes[d].radius=rad;
								if(d*8+e>=totalVertices){
									totalVertices=d*8+e+1;
								}
							}
							//connect vertices for node square
							mapVerticesBi(d*8+0,d*8+4);
							mapVerticesBi(d*8+0,d*8+1);
							mapVerticesBi(d*8+0,d*8+3);
							mapVerticesBi(d*8+6,d*8+7);
							mapVerticesBi(d*8+6,d*8+2);
							mapVerticesBi(d*8+6,d*8+5);
							mapVerticesBi(d*8+5,d*8+4);
							mapVerticesBi(d*8+5,d*8+1);
							mapVerticesBi(d*8+1,d*8+2);
							mapVerticesBi(d*8+2,d*8+3);
							mapVerticesBi(d*8+7,d*8+4);
							mapVerticesBi(d*8+7,d*8+3);
							//connect texture cordinates
							}
					}
				}
			}
		}
	}
	for(a=0;a<MAXAR;++a) nodeTracker[a]=false;

	for(a=1;a<mapDimX-1;++a){
		for(b=1;b<mapDimY-1;++b){
			for(c=1;c<mapDimZ-1;++c){
				d=mapMaze6WayMap[b][a][c][0];
				if(d!=-1){
					if(nodeTracker[d]==false){
						if(mapNodes[d].active==true){
							//valid node found
							nodeTracker[d]=true;

							for(e=0;e<6;++e){
								f=mapMaze6WayMap[b][a][c][e+1];
								if(f!=-1&&mapNodes[f].active){
									switch(e){
									case 0:
										mapVerticesBi(d*8+0,f*8+1);
										mapVerticesBi(d*8+0,f*8+2);
										mapVerticesBi(d*8+3,f*8+2);
										mapVerticesBi(d*8+3,f*8+6);
										mapVerticesBi(d*8+4,f*8+5);
										mapVerticesBi(d*8+4,f*8+1);
										mapVerticesBi(d*8+7,f*8+6);
										mapVerticesBi(d*8+7,f*8+5);
										mapVertexTextureCoordAdd(d*8+0,f*8+2,d*8+3,texCorners[0],texCorners[2],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+0,f*8+2,f*8+1,texCorners[0],texCorners[2],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+3,f*8+6,d*8+7,texCorners[0],texCorners[2],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+3,f*8+6,f*8+2,texCorners[0],texCorners[2],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+4,f*8+1,d*8+0,texCorners[1],texCorners[3],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+4,f*8+1,f*8+5,texCorners[1],texCorners[3],texCorners[2]);
										mapVertexTextureCoordAdd(d*8+7,f*8+5,d*8+4,texCorners[1],texCorners[3],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+7,f*8+5,f*8+6,texCorners[1],texCorners[3],texCorners[2]);
									
										break;
									case 1:
										mapVerticesBi(d*8+4,f*8+0);
										mapVerticesBi(d*8+4,f*8+3);
										mapVerticesBi(d*8+7,f*8+3);
										mapVerticesBi(d*8+7,f*8+2);
										mapVerticesBi(d*8+6,f*8+2);
										mapVerticesBi(d*8+6,f*8+1);
										mapVerticesBi(d*8+5,f*8+1);
										mapVerticesBi(d*8+5,f*8+0);
										mapVertexTextureCoordAdd(d*8+4,f*8+3,d*8+7,texCorners[0],texCorners[2],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+4,f*8+3,f*8+0,texCorners[0],texCorners[2],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+7,f*8+2,d*8+6,texCorners[2],texCorners[0],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+7,f*8+2,f*8+3,texCorners[2],texCorners[0],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+6,f*8+1,d*8+5,texCorners[2],texCorners[0],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+6,f*8+1,f*8+2,texCorners[2],texCorners[0],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+5,f*8+0,d*8+4,texCorners[1],texCorners[3],texCorners[2]);
										mapVertexTextureCoordAdd(d*8+5,f*8+0,f*8+1,texCorners[1],texCorners[3],texCorners[0]);
										break;
									case 2:
										mapVerticesBi(d*8+7,f*8+4);
										mapVerticesBi(d*8+7,f*8+5);
										mapVerticesBi(d*8+6,f*8+5);
										mapVerticesBi(d*8+6,f*8+1);
										mapVerticesBi(d*8+2,f*8+1);
										mapVerticesBi(d*8+2,f*8+0);
										mapVerticesBi(d*8+3,f*8+0);
										mapVerticesBi(d*8+3,f*8+4);
										mapVertexTextureCoordAdd(d*8+7,f*8+5,d*8+6,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+7,f*8+5,f*8+4,texCorners[3],texCorners[1],texCorners[2]);
										mapVertexTextureCoordAdd(d*8+6,f*8+1,d*8+2,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+6,f*8+1,f*8+5,texCorners[3],texCorners[1],texCorners[2]);
										mapVertexTextureCoordAdd(d*8+2,f*8+0,d*8+3,texCorners[0],texCorners[2],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+2,f*8+0,f*8+1,texCorners[0],texCorners[2],texCorners[1]);
										mapVertexTextureCoordAdd(d*8+3,f*8+4,d*8+7,texCorners[0],texCorners[2],texCorners[3]);
										mapVertexTextureCoordAdd(d*8+3,f*8+4,f*8+0,texCorners[0],texCorners[2],texCorners[1]);
										break;
									};
								}else{
									switch(e){
									case 0:
										mapVerticesBi(d*8+0,d*8+7);
										mapVertexTextureCoordAdd(d*8+0,d*8+7,d*8+3,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+0,d*8+7,d*8+4,texCorners[3],texCorners[1],texCorners[2]);		
										break;
									case 1:
										mapVerticesBi(d*8+4,d*8+6);
										mapVertexTextureCoordAdd(d*8+4,d*8+6,d*8+5,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+4,d*8+6,d*8+7,texCorners[3],texCorners[1],texCorners[2]);					
										break;
									case 2:
										mapVerticesBi(d*8+3,d*8+6);
										mapVertexTextureCoordAdd(d*8+3,d*8+6,d*8+7,texCorners[1],texCorners[3],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+3,d*8+6,d*8+2,texCorners[1],texCorners[3],texCorners[2]);					
										break;
									case 3:
										mapVerticesBi(d*8+1,d*8+4);
										mapVertexTextureCoordAdd(d*8+1,d*8+4,d*8+0,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+1,d*8+4,d*8+5,texCorners[3],texCorners[1],texCorners[2]);		
										break;
									case 4:
										mapVerticesBi(d*8+1,d*8+3);
										mapVertexTextureCoordAdd(d*8+1,d*8+3,d*8+0,texCorners[3],texCorners[1],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+1,d*8+3,d*8+2,texCorners[3],texCorners[1],texCorners[2]);			
										break;
									case 5:
										mapVerticesBi(d*8+2,d*8+5);
										mapVertexTextureCoordAdd(d*8+2,d*8+5,d*8+6,texCorners[1],texCorners[3],texCorners[0]);
										mapVertexTextureCoordAdd(d*8+2,d*8+5,d*8+1,texCorners[1],texCorners[3],texCorners[2]);			
										break;
									};
								}
							}
						}
					}
				}
			}
		}
	}
	delete [] nodeTracker;
}//function end

void Map::mapMazeSpliceVertices(){//function start
	//split triangles into 3 triangles using centroids

	bool *spliceTracker=new bool[MAXVERTICES];
	short spliceGo[MAXVERTICES][3];
	float ed1TexCoord[2],ed2TexCoord[2],aTexCoord[2];


	int a,b,c,d,e,f,g,h,i;
	for(a=0;a<MAXVERTICES;++a){
		spliceTracker[a]=false;
		for(b=0;b<3;++b) spliceGo[a][b]=-1;
	}

	for(a=0;a<totalVertices;++a){
		if(mapVertices[a].active){
			for(c=0;c<mapVertices[a].totalEdges;++c){
				int ed1=(int)mapVertices[a].edges[c][0];
				for(b=c+1;b<mapVertices[a].totalEdges;++b){
					int ed2=(int)mapVertices[a].edges[b][0];
					if(ed1>a&&ed2>a){//check only points after it and not recently created
						if(mapVertices[ed1].controlPt||mapVertices[ed2].controlPt||mapVertices[a].controlPt){
							for(d=0;d<mapVertices[ed1].totalEdges;++d){//look though edges of ed1 for matching of ed2
								if(mapVertices[ed1].edges[d][0]==ed2){//edges are connected,match found
									//find next open vertex
									for(e=0;e<MAXVERTICES;++e){
										if(!mapVertices[e].active){
											//open vertex found so make and connect
											spliceTracker[e]=true;//update the splice tracker
											float centroid[3]={(mapVertices[ed1].posX+mapVertices[ed2].posX+mapVertices[a].posX)/3,
																(mapVertices[ed1].posY+mapVertices[ed2].posY+mapVertices[a].posY)/3,
																(mapVertices[ed1].posZ+mapVertices[ed2].posZ+mapVertices[a].posZ)/3};							
											
											mapVertices[e].init(centroid[0],centroid[1],centroid[2],e);
											vertexGroups[e]=vertexGroups[a];

											spliceGo[e][0]=a;
											spliceGo[e][1]=ed1;
											spliceGo[e][2]=ed2;

											//////////get centroid tex coordinate
											for(g=0;g<mapVertices[ed1].totalTexCoords;++g){
												h=0;
												for(i=0;i<2;++i){
													if(mapVertices[ed1].texEdgeCoordTrig[g][i]==a||mapVertices[ed1].texEdgeCoordTrig[g][i]==ed2) ++h;
												}
												if(h==2){//a hit!
													ed1TexCoord[0]=mapVertices[ed1].texEdgeCoordTrig[g][2];
													ed1TexCoord[1]=mapVertices[ed1].texEdgeCoordTrig[g][3];
													break;
												}
											}
											for(g=0;g<mapVertices[ed2].totalTexCoords;++g){
												h=0;
												for(i=0;i<2;++i){
													if(mapVertices[ed2].texEdgeCoordTrig[g][i]==a||mapVertices[ed2].texEdgeCoordTrig[g][i]==ed1) ++h;
												}
												if(h==2){//a hit!
													ed2TexCoord[0]=mapVertices[ed2].texEdgeCoordTrig[g][2];
													ed2TexCoord[1]=mapVertices[ed2].texEdgeCoordTrig[g][3];
													break;
												}
											}
											for(g=0;g<mapVertices[a].totalTexCoords;++g){
												h=0;
												for(i=0;i<2;++i){
													if(mapVertices[a].texEdgeCoordTrig[g][i]==ed1||mapVertices[a].texEdgeCoordTrig[g][i]==ed2) ++h;
												}
												if(h==2){//a hit!
													aTexCoord[0]=mapVertices[a].texEdgeCoordTrig[g][2];
													aTexCoord[1]=mapVertices[a].texEdgeCoordTrig[g][3];
													break;
												}
											}
											float texCentroid[2]={(ed1TexCoord[0]+ed2TexCoord[0]+aTexCoord[0])/3.0f,(ed1TexCoord[1]+ed2TexCoord[1]+aTexCoord[1])/3.0f,};
											mapVertices[e].addTexCoordTrig(ed1,ed2,texCentroid);
											mapVertices[e].addTexCoordTrig(a,ed1,texCentroid);
											mapVertices[e].addTexCoordTrig(a,ed2,texCentroid);
											mapVertices[ed1].addTexCoordTrig(ed2,e,ed1TexCoord);
											mapVertices[ed1].addTexCoordTrig(a,e,ed1TexCoord);
											mapVertices[ed2].addTexCoordTrig(ed1,e,ed2TexCoord);
											mapVertices[ed2].addTexCoordTrig(a,e,ed2TexCoord);
											mapVertices[a].addTexCoordTrig(ed2,e,aTexCoord);
											mapVertices[a].addTexCoordTrig(ed1,e,aTexCoord);
											break;
										}
									}
									if(e==MAXVERTICES){
										printf("Error:Map:mapMazeSpliceVertices:Too few vertices\n");
										getchar();
										exit(0);
									}
									break;
								}
							}
						}
					}
				}
			}
		}
	}

	for(a=0,f=0;a<MAXVERTICES;++a){
		if(spliceTracker[a]){
			mapVerticesBi(a,spliceGo[a][0]);//connect edges to centroid pt
			mapVerticesBi(a,spliceGo[a][1]);
			mapVerticesBi(a,spliceGo[a][2]);
			mapVertices[spliceGo[a][0]].controlPt=false;
			mapVertices[spliceGo[a][1]].controlPt=false;
			mapVertices[spliceGo[a][2]].controlPt=false;
			if(a>=totalVertices) totalVertices=a+1;
			++f;
		}
	}
	delete [] spliceTracker;
	printf("Added %d vertices\n",f);
}//function end

void Map::mapMazeToNode(){//function start
	//convert array of map cordinates into Nodes and connect
	int a,b,c,d,e,f;
	for(a=1;a<mapDimY-1;++a){//y
		for(b=1;b<mapDimX-1;++b){//x
			for(f=1;f<mapDimZ-1;++f){//z
				d=mapMaze6WayMap[a][b][f][0];//determine id
				if(d!=-1){//check if position exists
					mapNodes[d].init(b*(mapSizeC/mapDimX)-((mapDimX-2)*(mapSizeC/mapDimX)/2),
								a*(mapSizeR/mapDimY)-((mapDimY-2)*(mapSizeR/mapDimY)/2),
								f*(mapSizeD/mapDimZ)-((mapDimZ-2)*(mapSizeD/mapDimZ)/2),
								d);
				}
			}
		}
	}
	for(a=1;a<mapDimY-1;++a){//y
		for(b=1;b<mapDimX-1;++b){//x
			for(f=1;f<mapDimZ-1;++f){//z
				d=mapMaze6WayMap[a][b][f][0];//determine id
				if(d!=-1){//check if position exists
					for(c=1;c<7;++c){
						e=mapMaze6WayMap[a][b][f][c];
						if(e!=-1){//check if next position exists
							//connect nodes
							mapNodesBi(d,e);
						}
					}
				}
			}
					
		}
	}	
}//function end

void Map::mapNodesBi(int n1,int n2){//function start
	//connect 2 Nodes bidirectional
	int a=mapNodes[n1].addEdge(n2);
	int b=mapNodes[n2].addEdge(n1);
			
	if(a>=0&&b>=0){
		mapNodes[n1].edges[a][1]=b;
		mapNodes[n2].edges[b][1]=a;
	}
}//function end

void Map::mapVertexTextureCoordAdd(int n1,int n2,int n3,float pos1[2],float pos2[2],float pos3[2]){//function start
	//add texture coordinate between existing vertices. pos1 to n1 connected to n2, vice ver
	mapVertices[n1].addTexCoordTrig(n2,n3,pos1);
	mapVertices[n2].addTexCoordTrig(n1,n3,pos2);
	mapVertices[n3].addTexCoordTrig(n1,n2,pos3);
}//function end
		

void Map::mapVerticesBi(int n1,int n2){//function start
	mapVertices[n1].addEdge(n2,
		mapVertices[n2].posX,mapVertices[n2].posY,mapVertices[n2].posZ);
	mapVertices[n2].addEdge(n1,
		mapVertices[n1].posX,mapVertices[n1].posY,mapVertices[n1].posZ);
}//function end

void Map::mapVerticesRemoveEdge(int n1,int n2){//function start
	//remove edge between n1 and n2
	mapVertices[n1].removeEdge(n2);
	mapVertices[n2].removeEdge(n1);
}//function end


void Map::display(){//start of display function
	int a,b;
	for(a=0;a<mapMaxNodes;++a){
		//draw node
		if(mapNodes[a].active){
			mapNodes[a].display();
			//draw edges
			glColor4f(1,0,1,1);
			glBegin(GL_LINES);
			for(b=0;b<mapNodes[a].totalEdges;++b){
				if(mapNodes[mapNodes[a].edges[b][0]].active){
					glVertex3f(mapNodes[a].posX,mapNodes[a].posY,mapNodes[a].posZ);
					glVertex3f(mapNodes[mapNodes[a].edges[b][0]].posX,
							mapNodes[mapNodes[a].edges[b][0]].posY,
							mapNodes[mapNodes[a].edges[b][0]].posZ);
				}
			}
			glEnd();
		}
	}

}//function end

void Map::displayVertices(){
	int a;
	for(a=0;a<totalVertices;++a){
		if(mapVertices[a].active==true){
			glColor4f(.75,.75,1,1);
			mapVertices[a].display();
			if(Display::normDisplayOnOff) mapVertices[a].displayNormals();
		}
	}
}

void Map::reset(){//function start
	//clear everything in Map and Nodes
	int i;
	for(i=0;i<MAXAR;++i){
		mapNodes[i].reset();

	}
	deleteVertices();
	mapVertices=new Vertex[MAXVERTICES];
	vertexGroups=new short[MAXVERTICES];
	for(i=0;i<MAXVERTICES;++i){
		mapVertices[i].reset();
		vertexGroups[i]=-1;
	}
	
	mapMaxNodes=0;
	mapDimX=mapDimY=mapDimZ=0;
	totalVertices=0;
}//end of reset function

void Map::deleteVertices(){//function start
	if(mapVertices!=NULL) delete [] mapVertices;
	if(vertexGroups!=NULL) delete [] vertexGroups;
	totalVertices=0;
}