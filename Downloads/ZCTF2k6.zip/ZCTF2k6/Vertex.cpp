/*
Vertex Class: Creates a vertex object. Stores position, norm vector, and references to 
adjacent verticies.

Last Modded: 5/15/06
*/
#include "Vertex.h"

Vertex::Vertex(){//start of Node Constructor
	active=false;
	controlPt=false;
}//end of function

void Vertex::init(float x,float y,float z,int vertexId){//function start
	//init function position and id
	posX=x;
	posY=y;
	posZ=z;
	id=vertexId;
	active=true;
	controlPt=true;
	totalEdges=0;
}//function end

void Vertex::setPos(float x,float y,float z){//function start
	//set position of vertex
	posX=x;
	posY=y;
	posZ=z;
}//function end

void Vertex::addEdge(int ed,float edgePosX,float edgePosY,float edgePosZ){//function start
	int a;
	for(a=0;a<totalEdges;++a){//don't add same edge twice
		if(edges[a][0]==ed) return;
	}
	edges[totalEdges][0]=ed;
	edges[totalEdges][1]=edgePosX;
	edges[totalEdges][2]=edgePosY;
	edges[totalEdges][3]=edgePosZ;
	++totalEdges;
	calcNorm();
}//function end

void Vertex::addTexCoordTrig(int ed1,int ed2,float pos[2]){//function start
	//add texture coordinate pos current vertex by trig config
	int a,b,c;
	for(a=0;a<totalTexCoords;++a){//don't add same texcoord twice
		c=0;
		for(b=0;b<2;++b){
			if(texEdgeCoordTrig[a][b]==ed1||texEdgeCoordTrig[a][b]==ed2) ++c;
		}
		if(c==2) return;
	}
	texEdgeCoordTrig[totalTexCoords][0]=ed1;
	texEdgeCoordTrig[totalTexCoords][1]=ed2;
	texEdgeCoordTrig[totalTexCoords][2]=pos[0];
	texEdgeCoordTrig[totalTexCoords][3]=pos[1];
	++totalTexCoords;
	
	if(totalTexCoords>=MAXTRIGTEXCOORDS){
		printf("addTexCoorTrig:error:exceed texcord triangles");
		getchar();
		exit(0);
	}

}//function end

void Vertex::removeEdge(int ed){//function start
	//remove edge connecting to ed
	int a,b,c;
	for(a=0;a<totalEdges;++a){
		if(edges[a][0]==ed){
			for(b=a+1;b<totalEdges;++b){
				for(c=0;c<4;++c) edges[b-1][c]=edges[b][c];
			}
			--totalEdges;
			break;
		}
	}
}//function end

void Vertex::display(){
//display vertex via sphere
	if(active=true){
		int a;
	//	Display::drawSphere(posX,posY,posZ,.01,3,3);
		glBegin(GL_LINES);
		for(a=0;a<totalEdges;++a){
			glVertex3f(posX,posY,posZ);
			glVertex3f(edges[a][1],edges[a][2],edges[a][3]);

		}
		glEnd();
	}
}

void Vertex::displayNormals(){//function start
	glLineWidth(4);
	glColor3f(1.0f,.5f,.5f);
	glBegin(GL_LINES);
		glVertex3f(posX,posY,posZ);
		glVertex3f(posX+normX/10,posY+normY/10,posZ+normZ/10);
	glEnd();
	glLineWidth(1);
}//function end

void Vertex::calcNorm(){//function start
//calculate normals of vertices averaging adjacent edges
	int a,b,c;
	float sumNorm[3];
	for(a=0;a<3;++a) sumNorm[a]=0;

	if(totalEdges==0) return;
	else if(totalEdges==2) b=1;
	else b=totalEdges;

	for(a=0;a<b;++a){
		c=(a+1)%totalEdges;
		float vec1[3]={edges[a][1]-posX,edges[a][2]-posY,edges[a][3]-posZ};
		float vec2[3]={edges[c][1]-posX,edges[c][2]-posY,edges[c][3]-posZ};	
		
		Matrix::MatrixVecNormalize(vec1);
		Matrix::MatrixVecNormalize(vec2);

		float vec3[3]={posX,posY,posZ};
		float vec4[3]={edges[a][1],edges[a][2],edges[a][3]};
		float vec5[3]={edges[c][1],edges[c][2],edges[c][3]};

		if(Matrix::Matrix3VerticesCCW(vec3,vec4,vec5)==1){
			Matrix::MatrixVecCrossProduct(vec1,vec2);
		}else{
			Matrix::MatrixVecCrossProduct(vec2,vec1);
			for(c=0;c<3;++c) vec2[c]=vec1[c];
		}
		Matrix::MatrixVecNormalize(vec2);

		sumNorm[0]+=vec2[0];
		sumNorm[1]+=vec2[1];
		sumNorm[2]+=vec2[2];
	}
	Matrix::MatrixVecNormalize(sumNorm);
	normX=sumNorm[0];
	normY=sumNorm[1];
	normZ=sumNorm[2];
}//function end

void Vertex::reset(){//function start
//reset vertex to defaults
	int a;
	for(a=0;a<totalEdges;++a){
		edges[a][0]=0;
		edges[a][1]=0;
		edges[a][2]=0;
		edges[a][3]=0;
	}
	posX=0;
	posY=0;
	posZ=0;
	totalEdges=0;
	active=false;
	controlPt=false;
	totalTexCoords=0;
}//function end

