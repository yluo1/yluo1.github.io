/*
GameCTFRoom class: Creates a object that stores all verticies of shapes within bounds
of room. Cordinate system is based on global cartesian system.

Last Modded: 5/15/06
*/
#include "GameCTFRoom.h"

GameCTFRoom::GameCTFRoom(){
	active=false;
}

void GameCTFRoom::displayPolys(){//function start
	if(active){
		for(int a=0;a<polyCount;++a) poly[a].display();
	}
}//function end

void GameCTFRoom::displayNormals(){//function start
	//draw normals for each polygon
	if(active){
		int a,b;
		glColor4f(1.0f,1.0f,1.0f,1.0f);
		glBegin(GL_LINES);
		for(a=0;a<polyCount;++a){
			float centroid[3]={0,0,0};
			for(b=0;b<3;++b){
				centroid[0]+=poly[a].vertexCoords[b][0];
				centroid[1]+=poly[a].vertexCoords[b][1];
				centroid[2]+=poly[a].vertexCoords[b][2];
			}
			centroid[0]/=3.0f;
			centroid[1]/=3.0f;
			centroid[2]/=3.0f;

			glVertex3f(centroid[0],centroid[1],centroid[2]);
			glVertex3f(centroid[0]+poly[a].polyNormal[0]/20,
					   centroid[1]+poly[a].polyNormal[1]/20,
					   centroid[2]+poly[a].polyNormal[2]/20);
		}
		glEnd();
	}
}//function end

void GameCTFRoom::addPoly(Vertex aVertex,Vertex bVertex, Vertex cVertex,float relativeNormalPoint[3]){//function start
	//add a polygon to room
	float vec1[3]={bVertex.posX-aVertex.posX,bVertex.posY-aVertex.posY,bVertex.posZ-aVertex.posZ};
	float vec2[3]={cVertex.posX-aVertex.posX,cVertex.posY-aVertex.posY,cVertex.posZ-aVertex.posZ};
	
	float vec3[3]={aVertex.posX,aVertex.posY,aVertex.posZ};
	float vec4[3]={bVertex.posX,bVertex.posY,bVertex.posZ};
	float vec5[3]={cVertex.posX,cVertex.posY,cVertex.posZ};

	//set poly positions
	float polyPoints[3][3]={{aVertex.posX,aVertex.posY,aVertex.posZ},
							{bVertex.posX,bVertex.posY,bVertex.posZ},
							{cVertex.posX,cVertex.posY,cVertex.posZ}};
	poly[polyCount].setPosition(polyPoints,relativeNormalPoint);

	////calculate normal with respect to relativeNormalPoint
	Matrix::MatrixVecNormalize(vec1);
	Matrix::MatrixVecNormalize(vec2);
	
	if(Matrix::Matrix3VerticesCCW(vec3,vec4,vec5)==1) poly[polyCount].isCCW=true;
	else poly[polyCount].isCCW=false;

	Matrix::MatrixVecCrossProduct(vec1,vec2);
	Matrix::MatrixVecNormalize(vec2);

	int i,j;
	for(i=0;i<3;++i){
		for(j=0;j<3;++j){
			poly[polyCount].vertexNormals[i][j]=vec2[j];
		}
	}

	//set baseline colors
	for(i=0;i<3;++i) poly[polyCount].polyColors[i]=.5f+fabs(vec2[i])/10.0f;
	poly[polyCount].polyColors[3]=1.0f;
	//set vertex colors
	for(i=0;i<3;++i){
		for(j=0;j<4;++j) poly[polyCount].vertexColors[i][j]=poly[polyCount].polyColors[j];
	}
	
	//find/add trig texture cordinates
	int a,b,c;

	for(a=0;a<aVertex.totalTexCoords;++a){
		c=0;
		for(b=0;b<2;++b){
			if(aVertex.texEdgeCoordTrig[a][b]==bVertex.id||aVertex.texEdgeCoordTrig[a][b]==cVertex.id)
				++c;	
		}
		if(c==2){
			poly[polyCount].texCoords[0][0]=aVertex.texEdgeCoordTrig[a][2];
			poly[polyCount].texCoords[0][1]=aVertex.texEdgeCoordTrig[a][3];
			break;
		}
	}
	for(a=0;a<bVertex.totalTexCoords;++a){
		c=0;
		for(b=0;b<2;++b){
			if(bVertex.texEdgeCoordTrig[a][b]==aVertex.id||bVertex.texEdgeCoordTrig[a][b]==cVertex.id)
				++c;	
		}
		if(c==2){
			poly[polyCount].texCoords[1][0]=bVertex.texEdgeCoordTrig[a][2];
			poly[polyCount].texCoords[1][1]=bVertex.texEdgeCoordTrig[a][3];
			break;
		}
	}
	for(a=0;a<cVertex.totalTexCoords;++a){
		c=0;
		for(b=0;b<2;++b){
			if(cVertex.texEdgeCoordTrig[a][b]==aVertex.id||cVertex.texEdgeCoordTrig[a][b]==bVertex.id)
				++c;	
		}
		if(c==2){
			poly[polyCount].texCoords[2][0]=cVertex.texEdgeCoordTrig[a][2];
			poly[polyCount].texCoords[2][1]=cVertex.texEdgeCoordTrig[a][3];
			break;
		}
	}


	++polyCount;
	active=true;

	if(polyCount>=MAXROOMPOLYS){
		printf("Error:GameCTFRoom:addTriangle:TooManyPolygons\n");
		getchar();
		exit(0);
	}
}//function end

void GameCTFRoom::reset(){//function start
	//reset room
	polyCount=0;
	active=false;
}//function end