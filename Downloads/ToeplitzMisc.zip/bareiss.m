%function [x, logdet] = bareiss(mt ,b)
%   Input:
%       mt: 1xN vector of square symmetric toeplitz matrix
%       b:  NxM vectors of RHS
%   Output:
%       x: nxm solution vector
%   Functionality:
%       Solves Mx=b for symmetric toeplitz M and multiple RHS via in-place 
%       column based Bareiss LU. Ux=d via back-regen, d is transformed b
%       
%Author:        Yuancheng Luo.  Date: 2/2012
%Documentation: Yuancheng Luo,  2/2012
%References: Old and new algorithms for Toeplitz systems, R.P. Brent,

function [x, logdet] = bareiss(mt,b)

%Get dimensions, assume square system
N = length(mt);
mt = reshape(mt, 1, N);
M = size(b, 2);

%Initialize first columns
ApR = reshape(mt, N,1);
ApC=ApR;
AnR=ApR;
AnC=ApR;

mn = zeros(1, N-1);
mp = zeros(1, N-1);

x = zeros(N, M);

bpC = b;
bnC = b;

logdet = 0;
for i=1:N-1
    logdet = logdet + log(AnC(1));

	%Upper
	mn(i) = AnR(i+1)/mt(1);
    AnC(1:N-i) = AnC(1:N-i) - mn(i)*ApR(i+1:N);
    AnR(i+1:N) = AnR(i+1:N) - mn(i)*ApC(1:N-i);

    %Lower
    mp(i) = ApR(i+1)/AnC(1);
    ApC(1:N-i) = ApC(1:N-i) - mp(i)*AnR(i+1:N);
    ApR(i+1:N) = ApR(i+1:N) - mp(i)*AnC(1:N-i);
    
	%Upper
    bnC(i+1:N, :) = bnC(i+1:N, :) - mn(i) * bpC(1:N-i, :);
    %Lower
    bpC(1:N-i, :) = bpC(1:N-i, :) - mp(i) * bnC(i+1:N, :);
end
logdet = logdet + log(AnC(1));


%Regenerate U from AnC and solve for x
for i = N-1 : -1 : 1 
    x(i+1,:) = (bnC(i+1,:) - (AnC(2: N-i)' * x(i+2 : N, :)) )/ AnC(1);

    ApR(i+1:N) = ApR(i+1:N) + mp(i)*AnC(1:N-i);
    ApC(1:N-i) = ApC(1:N-i) + mp(i)*AnR(i+1:N);
    
    AnR(i+1:N) = AnR(i+1:N) + mn(i)*ApC(1:N-i);
    AnC(1:N-i) = AnC(1:N-i) + mn(i)*ApR(i+1:N);
end
x(1,:) = (bnC(1,:) - (mt(2 : N) * x(2 : N,:)) )/ AnC(1);

% toeplitz(mt) \ b
% sum(sum(abs(toeplitz(mt) * x - b)))


