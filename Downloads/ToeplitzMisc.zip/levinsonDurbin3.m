%function [sol] = levinsonDurbin3(u, v, b)
%   Input:
%       u: 1xn vector of square toeplitz matrix M's first row
%       v: 1xn vector of square toeplitz matrix M's first column
%           u(1)=v(1)
%       b: 1xn vector of known values in Mx=b
%   Output:
%       sol: 1xn vector solution of Mx=b
%   Functionality:
%       Solves (computes x) the square toeplitz matrix system Mx=b using the
%       levinson-durbin recursion. Optimized column-oriented version of
%       levinsonDurbin2.m and levinsonDurbin.m
%
%Author:        Yuancheng Luo.  Date: 12/2009
%Documentation: Yuancheng Luo,  12/2009
%References:

function [sol] = levinsonDurbin3(u, v, b)

n = length(u);

%initialize forward and backward vectors
fVec = 1/u(1);
bVec = fVec(1);

%initialize solution
sol = b(1)/u(1);

v = fliplr(v);                                %flip v for to conform to matrix vector ops

for i=2:n
   %Compute forward, backward errors
   errF = v(n-i+1:n-1) * fVec;              %Compute forward error
   errX = v(n-i+1:n-1) * sol;               %Compute previous solution's error
   errB = u(2:i) * bVec;                    %Compute backward error
   
   fVecP = fVec;                            %Store previous forward vector
   d = 1/(1-errB*errF);
   fVec = d*[fVec; 0]-(errF*d)*[0; bVec];   %Compute forward vector
   bVec = d*[0; bVec]-(errB*d)*[fVecP; 0];  %Compute backward vector
   
   sol = [sol; 0] + (b(i)-errX)*bVec;       %Update solution

   pause;
   
end

sol=sol';
