%function [x, logdet] = bareiss_U(mt ,b)
%   Input:
%       mt: 1xN vector of square symmetric toeplitz matrix
%       b:  NxM vectors of RHS
%   Output:
%       x: nxm solution vector
%   Functionality:
%       Solves Mx=b for symmetric toeplitz M and multiple RHS via 
%       column based Bareiss LU with U storage (more parallel).
%       
%Author:        Yuancheng Luo.  Date: 2/2012
%Documentation: Yuancheng Luo,  2/2012
%References: Old and new algorithms for Toeplitz systems, R.P. Brent,

function [x, logdet] = bareiss_U(mt,b)

%Get dimensions, assume square system
N = length(mt);
mt = reshape(mt, 1, N);
M = size(b, 2);

%Initialize first columns
ApR = reshape(mt, N,1);
ApC=ApR;
AnR=ApR;
AnC=ApR;

x = zeros(N, M);

bpC = b;
bnC = b;

U = zeros(N,N);

logdet = 0;
for i=1:N-1
    logdet = logdet + log(AnC(1));

	%Upper
	U(i:N, i) = AnC(1:N-i+1);
    mn = AnR(i+1)/mt(1);
    AnC(1:N-i) = AnC(1:N-i) - mn*ApR(i+1:N);
    AnR(i+1:N) = AnR(i+1:N) - mn*ApC(1:N-i);

    %Lower
    mp = ApR(i+1)/AnC(1);
    ApC(1:N-i) = ApC(1:N-i) - mp*AnR(i+1:N);
    ApR(i+1:N) = ApR(i+1:N) - mp*AnC(1:N-i);

    %Upper
    bnC(i+1:N, :) = bnC(i+1:N, :) - mn * bpC(1:N-i, :);
    %Lower
    bpC(1:N-i, :) = bpC(1:N-i, :) - mp * bnC(i+1:N, :);
end
logdet = logdet + log(AnC(1));
U(N,N) = AnC(1);
U = U';

%Solve for x
for i = N : -1 : 2
    x(i,:) = (bnC(i,:) - x(i,:)) / U(i, i);
    x(1: i-1, :) = x(1: i-1, :) + U(1: i-1, i) * x(i,:);
end
x(1,:) = (bnC(1,:) - x(1,:)) / U(1, 1);

% U \ bnC 
% sum(sum(abs(toeplitz(mt) * x - b)))


